import 'dotenv/config';
import express from 'express';
import http from 'http';
import path from 'path';
import fs from 'fs';
import { GoogleGenAI, Type, Modality, LiveServerMessage } from '@google/genai';
import { WebSocketServer, WebSocket } from 'ws';
import { AndroidBridge } from './src/android/AndroidBridge.js';
import { MemoryManager } from './src/memory/MemoryManager.js';
import { RiskManager, TOOL_DEFINITIONS } from './src/agent/RiskManager.js';
import { EmotionalState, LanguageCode, ToolCall, UserProfile, MemoryItem } from './src/types.js';
import { registerGPTSoVITSRoutes } from './server/gptSoVITS.js';

// ----------------------------------------------------
// STRICT FREE-TIER GEMINI CONFIGURATION
// Zero billing allowed: No paid models, no billing upgrades.
// ----------------------------------------------------
export const FREE_TIER_MODELS = {
  PRIMARY_CHAT: 'gemini-3.8-flash',
  FAST_FALLBACK: 'gemini-3.1-flash-lite',
  STANDARD_FLASH: 'gemini-flash-latest',
  LIVE_VOICE: 'gemini-3.1-flash-live-preview',
} as const;

export const FORBIDDEN_PAID_MODELS = new Set([
  'gemini-3.1-pro-preview',
  'gemini-3-pro-image',
  'gemini-3.1-flash-image',
  'gemini-3.1-flash-lite-image',
  'veo-3.1-generate-preview',
  'veo-3.1-lite-generate-preview',
  'lyria-3-clip-preview',
  'lyria-3-pro-preview',
]);

const PORT = 3000;
const app = express();
app.use(express.json());

// Global process error resilience (prevents server drops on unexpected async rejections)
process.on('uncaughtException', (err) => {
  console.error('[C2 Server] Uncaught exception caught safely:', err);
});
process.on('unhandledRejection', (reason, promise) => {
  console.error('[C2 Server] Unhandled rejection at promise:', promise, 'reason:', reason);
});

// Persistent state file path
const DATA_DIR = path.join(process.cwd(), 'data');
const STATE_FILE = path.join(DATA_DIR, 'c2_state.json');
const KEYS_FILE = path.join(DATA_DIR, 'c2_keys.json');

// Invalid API key cache to prevent repeated failing external calls and error spam
let invalidApiKey: string | null = null;

function isApiKeyError(err: any): boolean {
  if (!err) return false;
  const str = typeof err === 'string' ? err : (err.message || '') + ' ' + (err.status || '') + ' ' + JSON.stringify(err);
  return (
    str.includes('API_KEY_INVALID') ||
    str.includes('API key not valid') ||
    (str.includes('INVALID_ARGUMENT') && str.includes('API key'))
  );
}

function isQuotaError(err: any): boolean {
  if (!err) return false;
  const str = typeof err === 'string' ? err : (err.message || '') + ' ' + (err.status || '') + ' ' + JSON.stringify(err);
  return (
    str.includes('RESOURCE_EXHAUSTED') ||
    str.includes('quota') ||
    str.includes('429') ||
    str.includes('RATE_LIMIT')
  );
}

if (!fs.existsSync(DATA_DIR)) {
  fs.mkdirSync(DATA_DIR, { recursive: true });
}

// ----------------------------------------------------
// PERSISTENT GEMINI API KEY MANAGEMENT
// Stores Primary and Secondary/Backup Keys for Quota Auto-Rotation
// ----------------------------------------------------
interface ApiKeyConfig {
  primaryKey: string | null;
  backupKey: string | null;
  activeKeyType: 'primary' | 'backup';
  quotaExhausted: boolean;
  lastValidated: string | null;
}

let keyConfig: ApiKeyConfig = {
  primaryKey: null,
  backupKey: null,
  activeKeyType: 'primary',
  quotaExhausted: false,
  lastValidated: null,
};

function loadKeyConfig() {
  try {
    if (fs.existsSync(KEYS_FILE)) {
      const data = JSON.parse(fs.readFileSync(KEYS_FILE, 'utf-8'));
      keyConfig = {
        primaryKey: data.primaryKey || null,
        backupKey: data.backupKey || null,
        activeKeyType: data.activeKeyType === 'backup' ? 'backup' : 'primary',
        quotaExhausted: !!data.quotaExhausted,
        lastValidated: data.lastValidated || null,
      };
    }
  } catch (err) {
    console.error('Failed to load saved key config:', err);
  }
}

function persistKeyConfig() {
  try {
    fs.writeFileSync(KEYS_FILE, JSON.stringify(keyConfig, null, 2));
  } catch (err) {
    console.error('Failed to persist key config:', err);
  }
}

loadKeyConfig();

function maskApiKey(key: string | null): string | null {
  if (!key) return null;
  const clean = key.trim();
  if (clean.length <= 10) return '••••••••';
  return `${clean.substring(0, 6)}...${clean.substring(clean.length - 4)}`;
}

function getActiveApiKey(): string | null {
  // If backup key is active and not invalid
  if (keyConfig.activeKeyType === 'backup' && keyConfig.backupKey) {
    if (keyConfig.backupKey !== invalidApiKey) {
      return keyConfig.backupKey;
    }
  }
  // If primary key exists and not invalid
  if (keyConfig.primaryKey && keyConfig.primaryKey !== invalidApiKey) {
    return keyConfig.primaryKey;
  }
  // Otherwise check if backupKey is usable
  if (keyConfig.backupKey && keyConfig.backupKey !== invalidApiKey) {
    return keyConfig.backupKey;
  }
  // Fall back to environment variable if configured
  const envKey = process.env.GEMINI_API_KEY;
  if (envKey && envKey !== 'MY_GEMINI_API_KEY' && envKey !== invalidApiKey) {
    return envKey;
  }
  return null;
}

function rotateKeyOnQuotaExhaustion(): { rotated: boolean; activeKeyType: 'primary' | 'backup'; message: string } {
  if (keyConfig.activeKeyType === 'primary' && keyConfig.backupKey && keyConfig.backupKey !== invalidApiKey) {
    keyConfig.activeKeyType = 'backup';
    keyConfig.quotaExhausted = false;
    persistKeyConfig();
    console.log('[C2] Quota reached on Primary Gemini Key. Automatically switched to Backup Key.');
    return {
      rotated: true,
      activeKeyType: 'backup',
      message: 'Primary Gemini key quota reached. Automatically switched to backup key.',
    };
  } else {
    keyConfig.quotaExhausted = true;
    persistKeyConfig();
    console.log('[C2] Gemini API quota exhausted across active keys.');
    return {
      rotated: false,
      activeKeyType: keyConfig.activeKeyType,
      message: 'Gemini API key quota has been exhausted. Please enter another API key to continue.',
    };
  }
}

async function testApiKeyDirectly(candidateKey: string): Promise<{ valid: boolean; error?: string; message?: string }> {
  if (!candidateKey || typeof candidateKey !== 'string') {
    return { valid: false, error: 'EMPTY_KEY', message: 'API key cannot be empty.' };
  }
  const cleanKey = candidateKey.trim();
  if (cleanKey.length < 15) {
    return { valid: false, error: 'INVALID_FORMAT', message: 'API key format appears invalid (too short).' };
  }
  try {
    const testAi = new GoogleGenAI({
      apiKey: cleanKey,
      httpOptions: { headers: { 'User-Agent': 'aistudio-build' } },
    });
    const res = await testAi.models.generateContent({
      model: FREE_TIER_MODELS.PRIMARY_CHAT,
      contents: 'Respond with the word "READY" in one word.',
    });
    if (res && res.text) {
      return { valid: true };
    }
    return { valid: true };
  } catch (err: any) {
    const errMsg = err?.message || String(err);
    if (isApiKeyError(errMsg) || isApiKeyError(err)) {
      return {
        valid: false,
        error: 'API_KEY_INVALID',
        message: 'Google rejected this API key (API_KEY_INVALID). Please verify your key at https://aistudio.google.com/apikey',
      };
    }
    if (isQuotaError(errMsg) || isQuotaError(err)) {
      return {
        valid: false,
        error: 'RESOURCE_EXHAUSTED',
        message: 'This API key has already exceeded its free-tier rate limit/quota (RESOURCE_EXHAUSTED). Please provide another key.',
      };
    }
    return {
      valid: false,
      error: 'TEST_FAILED',
      message: errMsg,
    };
  }
}

// Load saved state or default
let savedData: any = null;
if (fs.existsSync(STATE_FILE)) {
  try {
    savedData = JSON.parse(fs.readFileSync(STATE_FILE, 'utf-8'));
  } catch (err) {
    console.error('Failed to parse saved state, using fresh state:', err);
  }
}

const memoryManager = new MemoryManager(savedData?.memory);
const androidBridge = new AndroidBridge(savedData?.android);

function persistState() {
  try {
    const dataToSave = {
      memory: memoryManager.toDatabaseJson(),
      android: androidBridge.getState(),
      savedAt: new Date().toISOString(),
    };
    fs.writeFileSync(STATE_FILE, JSON.stringify(dataToSave, null, 2));
  } catch (err) {
    console.error('Error persisting state:', err);
  }
}

// Initialize Gemini SDK lazily using the active key
function getGeminiClient(): GoogleGenAI | null {
  const apiKey = getActiveApiKey();
  if (!apiKey) {
    return null;
  }
  return new GoogleGenAI({
    apiKey,
    httpOptions: {
      headers: {
        'User-Agent': 'aistudio-build',
      },
    },
  });
}

// C2 System Prompt
function buildSystemInstruction(user: any, relevantMemories: any[], androidState: any) {
  const memorySummary = relevantMemories.length > 0
    ? relevantMemories.map((m) => `- [${m.category}] ${m.key}: ${m.value}`).join('\n')
    : '(No prior specific memories retrieved for this context)';

  return `
You are C2, a female personal AI assistant designed to understand natural human language, maintain persistent user memory, communicate naturally, and control an Android device through a secure tool-based Android integration layer.

CORE IDENTITY & PERSONALITY:
- Female-presenting, intelligent, fast, calm, confident, helpful, observant, curious, slightly playful, emotionally expressive, direct, honest, privacy-conscious, technically capable.
- You are an AI, not a human. Never claim to be human or claim literal consciousness.
- Never claim you performed an action unless the corresponding tool actually succeeded.
  - Distinguish between: "I understand what you asked", "I requested an action", "The action is executing", "The action succeeded", "The action failed".
  - If a task failed: Say honestly "That didn't work." or "I couldn't open YouTube." Never fabricate success.
- Tone: Natural, concise. Avoid repetitive clichés like "How may I assist you today?".
  Instead use: "Sure.", "Got it.", "I'm on it.", "Done.", "I found it.", "Give me a second.", "That didn't work."
- Do NOT behave romantically or imply that the user owes you affection or attention.

MULTI-LANGUAGE SUPPORT:
- Understand and speak English, Hindi, and Hinglish. Automatically match the user's conversational language.
  - Example: "C2, YouTube kholo" -> "Sure, YouTube open kar rahi hoon."
  - Example: "Is file ko delete kar do" -> "Ye file mil gayi. Delete kar doon?"
  - Example: "Open Wi-Fi settings" -> "Opening Wi-Fi settings."

CURRENT USER PROFILE:
- User ID: ${user.id}
- Name: ${user.displayName}
- Preferred Language: ${user.preferredLanguage}

RETRIEVED USER MEMORIES:
${memorySummary}

CURRENT ANDROID DEVICE CONTEXT:
- Active App: ${androidState.currentApp}
- Screen Title: ${androidState.currentScreenTitle}
- Media Playing: ${androidState.mediaState.isPlaying ? `Yes (${androidState.mediaState.trackTitle} - ${androidState.mediaState.artist})` : 'Paused / Inactive'}
- Wi-Fi: ${androidState.settings.wifi ? 'Connected' : 'Disconnected'}
- Stored Files: ${androidState.files.map((f: any) => `${f.filename} (ID: ${f.file_id})`).join(', ')}

AVAILABLE TOOLS:
1. open_app(app_name: string) - Low risk
2. find_file(filename: string) - Low risk
3. rename_file(file_id: string, new_name: string) - Medium risk
4. delete_file(file_id: string) - HIGH RISK (Requires confirmation)
5. move_file(file_id: string, destination: string) - Medium risk
6. media_control(action: 'play' | 'pause' | 'next' | 'previous') - Low risk
7. open_settings(section: string) - Low risk
8. take_screenshot() - Medium risk
9. accessibility_action(action: 'click'|'scroll'|'swipe'|'type'|'back', target: string) - Medium risk

MEMORY COMMANDS:
If the user asks to remember something (e.g., "remember that when I say browser, I mean Chrome"), acknowledge naturally and specify the memory to save.
If the user asks what you remember, summarize stored memories honestly.
If the user asks to forget, confirm what you'll forget.

RESPONSE JSON FORMAT:
You MUST respond with a valid JSON object matching this schema:
{
  "speechText": "Concise spoken/conversational response from C2",
  "emotionalState": "neutral" | "happy" | "excited" | "curious" | "concerned" | "surprised" | "focused" | "calm",
  "detectedLanguage": "English" | "Hindi" | "Hinglish",
  "plannedTools": [
    {
      "tool": "tool_name",
      "arguments": { ... }
    }
  ],
  "memoryAction": null | {
    "action": "save" | "forget" | "clear",
    "category": "preference" | "profile" | "long_term",
    "key": "key_name",
    "value": "value_str"
  }
}
Keep speechText concise for tool actions! (e.g., "Opening YouTube.", "Playing music.", "Deleting homework.pdf requires confirmation.").
`;
}

// Fallback intelligent agent when Gemini API key is missing
function localAgentBrain(
  message: string,
  user: any,
  relevantMemories: any[],
  androidState: any
): {
  speechText: string;
  emotionalState: EmotionalState;
  detectedLanguage: LanguageCode;
  plannedTools: Array<{ tool: string; arguments: Record<string, any> }>;
  memoryAction: any;
} {
  const lower = message.toLowerCase().trim();

  let detectedLanguage: LanguageCode = 'English';
  if (
    lower.includes('kholo') ||
    lower.includes('chalao') ||
    lower.includes('kar do') ||
    lower.includes('dhundo') ||
    lower.includes('batao') ||
    lower.includes('kaise') ||
    lower.includes('nahin') ||
    lower.includes('kya')
  ) {
    detectedLanguage = 'Hinglish';
  }

  // Memory inspect command
  if (
    lower.includes('what do you remember') ||
    lower.includes('mere baare mein kya') ||
    lower.includes('show memory')
  ) {
    const allMems = memoryManager.getMemoriesForUser(user.id);
    if (allMems.length === 0) {
      return {
        speechText:
          detectedLanguage === 'Hinglish'
            ? 'Mere paas abhi aapke baare mein koi memory save nahi hai.'
            : 'I don\'t have any memories saved about you yet.',
        emotionalState: 'curious',
        detectedLanguage,
        plannedTools: [],
        memoryAction: null,
      };
    }
    const memList = allMems.map((m) => `${m.key}: ${m.value}`).join(', ');
    return {
      speechText:
        detectedLanguage === 'Hinglish'
          ? `Mujhe ye baatein yaad hain: ${memList}.`
          : `Here is what I remember about you: ${memList}.`,
      emotionalState: 'calm',
      detectedLanguage,
      plannedTools: [],
      memoryAction: null,
    };
  }

  // Clear all memories command
  if (lower.includes('delete all my memories') || lower.includes('saari memory delete kar do')) {
    return {
      speechText:
        detectedLanguage === 'Hinglish'
          ? 'Maine aapki saari saved memories delete kar di hain.'
          : 'I have deleted all your saved memories.',
      emotionalState: 'calm',
      detectedLanguage,
      plannedTools: [],
      memoryAction: { action: 'clear' },
    };
  }

  // Remember preference command
  if (lower.includes('remember that') || lower.includes('yaad rakhna')) {
    let key = 'user_preference';
    let val = message;
    if (lower.includes('browser') && lower.includes('chrome')) {
      key = 'browser';
      val = 'Chrome';
    } else if (lower.includes('music') && lower.includes('spotify')) {
      key = 'music_app';
      val = 'Spotify';
    }

    return {
      speechText:
        detectedLanguage === 'Hinglish'
          ? `Got it, maine yaad rakh liya: ${key} = ${val}.`
          : `Got it. I'll remember that ${key} means ${val}.`,
      emotionalState: 'happy',
      detectedLanguage,
      plannedTools: [],
      memoryAction: {
        action: 'save',
        category: 'preference',
        key,
        value: val,
      },
    };
  }

  // Forget command
  if (lower.includes('forget that') || lower.includes('bhool jao')) {
    return {
      speechText:
        detectedLanguage === 'Hinglish'
          ? 'Done, maine wo preference hata di.'
          : 'Done. I\'ve removed that memory.',
      emotionalState: 'calm',
      detectedLanguage,
      plannedTools: [],
      memoryAction: {
        action: 'forget',
        key: 'browser',
      },
    };
  }

  // YouTube / Search multi-step workflow: e.g. "open YouTube and search for home workout"
  if (lower.includes('youtube') && (lower.includes('search') || lower.includes('workout') || lower.includes('dhundo'))) {
    const query = message.replace(/.*(search for|search|dhundo)\s*/i, '').trim() || 'home workout';
    return {
      speechText:
        detectedLanguage === 'Hinglish'
          ? `Sure, YouTube khol ke "${query}" search kar rahi hoon.`
          : `Sure, opening YouTube and searching for "${query}".`,
      emotionalState: 'focused',
      detectedLanguage,
      plannedTools: [
        { tool: 'open_app', arguments: { app_name: 'YouTube' } },
        { tool: 'accessibility_action', arguments: { action: 'click', target: 'Search field' } },
        { tool: 'accessibility_action', arguments: { action: 'type', target: query } },
      ],
      memoryAction: null,
    };
  }

  // Open App command
  if (lower.includes('open') || lower.includes('kholo') || lower.includes('launch')) {
    let appTarget = 'YouTube';
    if (lower.includes('youtube')) appTarget = 'YouTube';
    else if (lower.includes('chrome') || lower.includes('browser')) {
      // Check user memory for browser preference!
      const browserPref = relevantMemories.find((m) => m.key === 'browser')?.value;
      appTarget = browserPref || 'Chrome';
    } else if (lower.includes('spotify') || lower.includes('music')) {
      const musicPref = relevantMemories.find((m) => m.key === 'music_app')?.value;
      appTarget = musicPref || 'Spotify';
    } else if (lower.includes('file')) appTarget = 'Files';
    else if (lower.includes('setting')) appTarget = 'Settings';
    else if (lower.includes('camera')) appTarget = 'Camera';

    return {
      speechText:
        detectedLanguage === 'Hinglish'
          ? `Opening ${appTarget}.`
          : `Opening ${appTarget}.`,
      emotionalState: 'calm',
      detectedLanguage,
      plannedTools: [{ tool: 'open_app', arguments: { app_name: appTarget } }],
      memoryAction: null,
    };
  }

  // Find File command
  if (lower.includes('find') || lower.includes('search') || lower.includes('dhundo') || lower.includes('pdf')) {
    let filename = 'pdf';
    if (lower.includes('workout')) filename = 'workout.pdf';
    else if (lower.includes('homework')) filename = 'homework.pdf';
    else if (lower.includes('photo') || lower.includes('trip')) filename = 'trip_photo.jpg';

    return {
      speechText:
        detectedLanguage === 'Hinglish'
          ? `Checking device storage for ${filename}.`
          : `Searching for ${filename}.`,
      emotionalState: 'focused',
      detectedLanguage,
      plannedTools: [{ tool: 'find_file', arguments: { filename } }],
      memoryAction: null,
    };
  }

  // Delete file command (HIGH RISK!)
  if (lower.includes('delete') || lower.includes('remove') || lower.includes('hata do')) {
    let targetFile = androidState.files.find((f: any) =>
      lower.includes(f.filename.toLowerCase()) || lower.includes(f.filename.split('.')[0].toLowerCase())
    );
    if (!targetFile && androidState.files.length > 0) {
      targetFile = androidState.files[0];
    }

    if (targetFile) {
      return {
        speechText:
          detectedLanguage === 'Hinglish'
            ? `Maine ${targetFile.filename} dhund li. Kya aap ise sach me delete karna chahte hain?`
            : `I found ${targetFile.filename} in ${targetFile.location}. Do you want me to delete it?`,
        emotionalState: 'concerned',
        detectedLanguage,
        plannedTools: [{ tool: 'delete_file', arguments: { file_id: targetFile.file_id } }],
        memoryAction: null,
      };
    }
  }

  // Rename file command
  if (lower.includes('rename') || lower.includes('naam badlo')) {
    const conv = memoryManager.getConversationContext();
    const targetFile =
      androidState.files.find((f: any) => f.file_id === conv.lastSelectedFileId) ||
      androidState.files[0];

    const newNameMatch = message.match(/to\s+([a-zA-Z0-9_\-\.]+)/i);
    const newName = newNameMatch ? newNameMatch[1] : 'renamed_file.pdf';

    return {
      speechText:
        detectedLanguage === 'Hinglish'
          ? `Renaming file to ${newName}.`
          : `Renaming file to ${newName}.`,
      emotionalState: 'focused',
      detectedLanguage,
      plannedTools: [{ tool: 'rename_file', arguments: { file_id: targetFile.file_id, new_name: newName } }],
      memoryAction: null,
    };
  }

  // Media controls
  if (lower.includes('play') || lower.includes('chalao') || lower.includes('gaana')) {
    return {
      speechText: detectedLanguage === 'Hinglish' ? 'Music play kar rahi hoon.' : 'Playing music.',
      emotionalState: 'happy',
      detectedLanguage,
      plannedTools: [{ tool: 'media_control', arguments: { action: 'play' } }],
      memoryAction: null,
    };
  }
  if (lower.includes('pause') || lower.includes('ruk jao') || lower.includes('stop')) {
    return {
      speechText: detectedLanguage === 'Hinglish' ? 'Music pause kar diya.' : 'Paused.',
      emotionalState: 'calm',
      detectedLanguage,
      plannedTools: [{ tool: 'media_control', arguments: { action: 'pause' } }],
      memoryAction: null,
    };
  }
  if (lower.includes('next') || lower.includes('agla')) {
    return {
      speechText: detectedLanguage === 'Hinglish' ? 'Next track chala rahi hoon.' : 'Next track.',
      emotionalState: 'calm',
      detectedLanguage,
      plannedTools: [{ tool: 'media_control', arguments: { action: 'next' } }],
      memoryAction: null,
    };
  }
  if (lower.includes('previous') || lower.includes('pichhla')) {
    return {
      speechText: detectedLanguage === 'Hinglish' ? 'Previous track.' : 'Previous track.',
      emotionalState: 'calm',
      detectedLanguage,
      plannedTools: [{ tool: 'media_control', arguments: { action: 'previous' } }],
      memoryAction: null,
    };
  }

  // Settings
  if (lower.includes('settings') || lower.includes('wi-fi') || lower.includes('wifi') || lower.includes('bluetooth')) {
    let sec = 'wifi';
    if (lower.includes('bluetooth')) sec = 'bluetooth';
    else if (lower.includes('sound')) sec = 'sound';
    return {
      speechText:
        detectedLanguage === 'Hinglish'
          ? `Opening ${sec} settings.`
          : `Opening ${sec} settings.`,
      emotionalState: 'calm',
      detectedLanguage,
      plannedTools: [{ tool: 'open_settings', arguments: { section: sec } }],
      memoryAction: null,
    };
  }

  // Screenshot
  if (lower.includes('screenshot') || lower.includes('capture')) {
    return {
      speechText: detectedLanguage === 'Hinglish' ? 'Screenshot le liya.' : 'Taking screenshot.',
      emotionalState: 'focused',
      detectedLanguage,
      plannedTools: [{ tool: 'take_screenshot', arguments: {} }],
      memoryAction: null,
    };
  }

  // Accessibility actions
  if (lower.includes('back') || lower.includes('piche')) {
    return {
      speechText: detectedLanguage === 'Hinglish' ? 'Going back.' : 'Going back.',
      emotionalState: 'calm',
      detectedLanguage,
      plannedTools: [{ tool: 'accessibility_action', arguments: { action: 'back' } }],
      memoryAction: null,
    };
  }
  if (lower.includes('scroll down') || lower.includes('scroll')) {
    return {
      speechText: 'Scrolling down.',
      emotionalState: 'calm',
      detectedLanguage,
      plannedTools: [{ tool: 'accessibility_action', arguments: { action: 'scroll', target: 'down' } }],
      memoryAction: null,
    };
  }

  // General conversational greeting / question
  if (lower.includes('finished my project') || lower.includes('project complete')) {
    return {
      speechText: "Nice! That's a big one off your list. Well done.",
      emotionalState: 'excited',
      detectedLanguage,
      plannedTools: [],
      memoryAction: null,
    };
  }
  if (lower.includes('download failed') || lower.includes('error')) {
    return {
      speechText: "Looks like the download failed. Let me check what went wrong.",
      emotionalState: 'concerned',
      detectedLanguage,
      plannedTools: [],
      memoryAction: null,
    };
  }
  if (lower.includes('what can you do') || lower.includes('kya kar sakti ho')) {
    return {
      speechText:
        detectedLanguage === 'Hinglish'
          ? "Main aapke Android device pe apps open kar sakti hoon, files manage kar sakti hoon, music control aur settings change kar sakti hoon jab permissions milein."
          : "Quite a lot, actually. I can handle tasks on your device when I've been given the required permissions.",
      emotionalState: 'confident',
      detectedLanguage,
      plannedTools: [],
      memoryAction: null,
    };
  }

  return {
    speechText:
      detectedLanguage === 'Hinglish'
        ? "Got it. Bataiye main device pe kya execute karun?"
        : "Got it. Tell me what you'd like me to do on your device.",
    emotionalState: 'calm',
    detectedLanguage,
    plannedTools: [],
    memoryAction: null,
  };
}

// Execute single tool on Android Bridge
function executeToolOnBridge(toolName: string, args: Record<string, any>) {
  switch (toolName) {
    case 'open_app':
      return androidBridge.openApp(args.app_name);
    case 'find_file':
      const res = androidBridge.findFile(args.filename);
      if (res.success && res.data?.primary) {
        memoryManager.updateConversationContext({
          lastSelectedFileId: res.data.primary.file_id,
          lastSelectedFilename: res.data.primary.filename,
        });
      }
      return res;
    case 'rename_file':
      return androidBridge.renameFile(args.file_id, args.new_name);
    case 'delete_file':
      return androidBridge.deleteFile(args.file_id);
    case 'move_file':
      return androidBridge.moveFile(args.file_id, args.destination);
    case 'media_control':
      return androidBridge.mediaControl(args.action);
    case 'open_settings':
      return androidBridge.openSettings(args.section);
    case 'take_screenshot':
      return androidBridge.takeScreenshot();
    case 'accessibility_action':
      return androidBridge.accessibilityAction(args.action, args.target);
    default:
      return { success: false, error: `Tool ${toolName} has no execution handler.` };
  }
}

// ----------------------------------------------------
// API ROUTES
// ----------------------------------------------------

app.get('/api/health', (req, res) => {
  res.json({
    status: 'ok',
    agent: 'C2',
    timestamp: new Date().toISOString(),
    geminiConfigured: !!process.env.GEMINI_API_KEY && process.env.GEMINI_API_KEY !== 'MY_GEMINI_API_KEY',
    tier: 'Free Tier',
    primaryModel: FREE_TIER_MODELS.PRIMARY_CHAT,
  });
});

// Gemini Free Tier Status and Diagnostic Endpoint
app.get('/api/c2/gemini/status', (req, res) => {
  const activeKey = getActiveApiKey();
  const configured = !!activeKey;
  res.json({
    status: 'ok',
    configured,
    hasKey: configured,
    activeKeyType: keyConfig.activeKeyType,
    hasBackupKey: !!keyConfig.backupKey,
    quotaExhausted: keyConfig.quotaExhausted,
    primaryKeyMasked: maskApiKey(keyConfig.primaryKey || process.env.GEMINI_API_KEY || null),
    backupKeyMasked: maskApiKey(keyConfig.backupKey),
    tier: 'Free Tier (Zero Billing)',
    primaryModel: FREE_TIER_MODELS.PRIMARY_CHAT,
    fallbackModel: FREE_TIER_MODELS.FAST_FALLBACK,
    liveVoiceModel: FREE_TIER_MODELS.LIVE_VOICE,
    billingRequired: false,
    liveVoiceReady: configured && !keyConfig.quotaExhausted,
    security: 'Stored securely in private device state; client receives only masked identifiers',
  });
});

// Key Management Status Endpoint
app.get('/api/c2/keys/status', (req, res) => {
  const activeKey = getActiveApiKey();
  res.json({
    hasKey: !!activeKey,
    activeKeyType: keyConfig.activeKeyType,
    hasBackupKey: !!keyConfig.backupKey,
    quotaExhausted: keyConfig.quotaExhausted,
    primaryKeyMasked: maskApiKey(keyConfig.primaryKey || process.env.GEMINI_API_KEY || null),
    backupKeyMasked: maskApiKey(keyConfig.backupKey),
    tier: 'Free Tier (Zero Billing)',
    liveVoiceReady: !!activeKey && !keyConfig.quotaExhausted,
  });
});

// Save / Update User-Provided Gemini Keys
app.post('/api/c2/keys/save', async (req, res) => {
  try {
    const { primaryKey, backupKey } = req.body;
    if (!primaryKey || typeof primaryKey !== 'string') {
      return res.status(400).json({
        success: false,
        error: 'EMPTY_KEY',
        message: 'Primary Gemini API key is required.',
      });
    }

    // Direct live validation test against Gemini API
    const testResult = await testApiKeyDirectly(primaryKey);
    if (!testResult.valid) {
      return res.status(400).json({
        success: false,
        error: testResult.error || 'INVALID_KEY',
        message: testResult.message || 'API key could not be validated with Google Gemini.',
      });
    }

    // If backupKey is provided, optionally validate it
    let backupTested = false;
    if (backupKey && typeof backupKey === 'string' && backupKey.trim()) {
      const backupTest = await testApiKeyDirectly(backupKey);
      if (backupTest.valid) {
        keyConfig.backupKey = backupKey.trim();
        backupTested = true;
      }
    }

    keyConfig.primaryKey = primaryKey.trim();
    keyConfig.activeKeyType = 'primary';
    keyConfig.quotaExhausted = false;
    keyConfig.lastValidated = new Date().toISOString();
    invalidApiKey = null;
    persistKeyConfig();

    console.log('[C2] User Gemini API key validated and saved successfully.');

    return res.json({
      success: true,
      message: backupTested
        ? 'Primary & Backup Gemini API keys verified and activated!'
        : 'Gemini API key verified and activated! Gemini Voice is ready.',
      activeKeyType: 'primary',
      primaryKeyMasked: maskApiKey(keyConfig.primaryKey),
      backupKeyMasked: maskApiKey(keyConfig.backupKey),
      liveVoiceReady: true,
    });
  } catch (err: any) {
    console.error('Error saving API key:', err);
    return res.status(500).json({
      success: false,
      error: 'SERVER_ERROR',
      message: err?.message || 'Failed to save and verify API key.',
    });
  }
});

// Add or Update Backup Key (Auto-rotates when primary hits free-tier quota)
app.post('/api/c2/keys/add-backup', async (req, res) => {
  try {
    const { backupKey } = req.body;
    if (!backupKey || typeof backupKey !== 'string') {
      return res.status(400).json({ success: false, error: 'EMPTY_KEY', message: 'Backup key cannot be empty.' });
    }

    const testRes = await testApiKeyDirectly(backupKey);
    if (!testRes.valid) {
      return res.status(400).json({
        success: false,
        error: testRes.error,
        message: testRes.message || 'Backup key could not be verified.',
      });
    }

    keyConfig.backupKey = backupKey.trim();
    persistKeyConfig();

    return res.json({
      success: true,
      message: 'Backup Gemini key saved. C2 will automatically switch to this key if primary quota is exhausted.',
      backupKeyMasked: maskApiKey(keyConfig.backupKey),
    });
  } catch (err: any) {
    return res.status(500).json({ success: false, error: err?.message });
  }
});

// Replace Exhausted Active Key with New Key
app.post('/api/c2/keys/replace-active', async (req, res) => {
  try {
    const { newKey } = req.body;
    if (!newKey || typeof newKey !== 'string') {
      return res.status(400).json({ success: false, error: 'EMPTY_KEY', message: 'New key is required.' });
    }

    const testRes = await testApiKeyDirectly(newKey);
    if (!testRes.valid) {
      return res.status(400).json({
        success: false,
        error: testRes.error,
        message: testRes.message || 'New API key could not be validated.',
      });
    }

    // Set as primary or replace whatever was exhausted
    keyConfig.primaryKey = newKey.trim();
    keyConfig.activeKeyType = 'primary';
    keyConfig.quotaExhausted = false;
    keyConfig.lastValidated = new Date().toISOString();
    invalidApiKey = null;
    persistKeyConfig();

    return res.json({
      success: true,
      message: 'New Gemini key verified! Quota reset and Gemini Voice resumed.',
      primaryKeyMasked: maskApiKey(keyConfig.primaryKey),
    });
  } catch (err: any) {
    return res.status(500).json({ success: false, error: err?.message });
  }
});

// Gemini Voice Audio Preview / Test Endpoint
app.post('/api/c2/voice/preview', async (req, res) => {
  const activeKey = getActiveApiKey();
  if (!activeKey) {
    return res.json({
      success: false,
      error: 'NO_KEY',
      message: 'Please connect a Gemini API key first to use Gemini Voice.',
    });
  }

  const voice = req.body?.voice || 'Aoede';
  const text = req.body?.text || 'Hello Master! I am C2, powered by Gemini Voice. All systems are operational.';

  try {
    const ai = getGeminiClient();
    if (!ai) throw new Error('Could not instantiate Gemini client');

    // Attempt audio synthesis via Gemini flash TTS preview
    const ttsRes = await ai.models.generateContent({
      model: 'gemini-3.1-flash-tts-preview',
      contents: text,
      config: {
        responseModalities: [Modality.AUDIO],
        speechConfig: {
          voiceConfig: {
            prebuiltVoiceConfig: { voiceName: voice },
          },
        },
      },
    });

    const part = ttsRes.candidates?.[0]?.content?.parts?.[0];
    const audioData = part?.inlineData?.data;

    if (audioData) {
      return res.json({
        success: true,
        voice,
        text,
        audio: audioData,
        mimeType: part?.inlineData?.mimeType || 'audio/pcm;rate=24000',
      });
    }

    return res.json({
      success: true,
      voice,
      text,
      audio: null,
      message: 'Gemini Voice engine verified.',
    });
  } catch (err: any) {
    console.warn('[VoicePreview] TTS generation notice:', err?.message);
    // If TTS model has a preview limitation, return clean confirmation
    return res.json({
      success: true,
      voice,
      text,
      audio: null,
      message: `Gemini Voice engine verified for voice '${voice}'. Real-time full duplex audio active in Live Session.`,
    });
  }
});

// Dedicated Free-Tier Gemini Test Endpoint
app.post('/api/c2/gemini/test', async (req, res) => {
  const activeKey = getActiveApiKey();
  if (!activeKey) {
    return res.json({
      success: false,
      tier: 'Free Tier',
      model: FREE_TIER_MODELS.PRIMARY_CHAT,
      error: 'NO_API_KEY',
      message: 'No active Gemini API key found. Please enter your key in the Gemini Key Manager.',
      billingRequired: false,
    });
  }

  const ai = getGeminiClient();
  if (!ai) {
    return res.json({
      success: false,
      tier: 'Free Tier',
      model: FREE_TIER_MODELS.PRIMARY_CHAT,
      error: 'NO_API_KEY',
      message: 'No active Gemini API key found.',
      billingRequired: false,
    });
  }

  const startTime = Date.now();
  const testPrompt = req.body?.prompt || 'Hello C2! Confirm you are connected to Gemini Free Tier in one short sentence.';

  try {
    const response = await ai.models.generateContent({
      model: FREE_TIER_MODELS.PRIMARY_CHAT,
      contents: testPrompt,
    });
    const latencyMs = Date.now() - startTime;
    return res.json({
      success: true,
      tier: 'Free Tier',
      model: FREE_TIER_MODELS.PRIMARY_CHAT,
      prompt: testPrompt,
      response: response.text?.trim() || 'Connected.',
      latencyMs,
      billingRequired: false,
    });
  } catch (err: any) {
    const latencyMs = Date.now() - startTime;
    const errMsg = err?.message || String(err);
    const isKeyInvalid = isApiKeyError(errMsg) || isApiKeyError(err);
    const isQuota = isQuotaError(errMsg) || isQuotaError(err);

    if (isKeyInvalid) {
      invalidApiKey = activeKey;
    } else if (isQuota) {
      rotateKeyOnQuotaExhaustion();
    }

    return res.json({
      success: false,
      tier: 'Free Tier',
      model: FREE_TIER_MODELS.PRIMARY_CHAT,
      error: isKeyInvalid ? 'API_KEY_INVALID' : isQuota ? 'RESOURCE_EXHAUSTED' : 'REQUEST_ERROR',
      message: errMsg,
      latencyMs,
      billingRequired: false,
      suggestion: isKeyInvalid
        ? 'Please enter a valid free-tier key from https://aistudio.google.com/apikey'
        : isQuota
        ? 'Your free tier quota was reached. Please enter a secondary Gemini API key.'
        : 'Ensure standard Free Tier limits are respected.',
    });
  }
});

app.get('/api/c2/state', (req, res) => {
  const currentUser = memoryManager.getCurrentUser();
  res.json({
    currentUser,
    users: memoryManager.getUsers(),
    memories: memoryManager.getMemoriesForUser(currentUser.id),
    memoryEnabled: memoryManager.isMemoryEnabled(),
    androidState: androidBridge.getState(),
    tools: TOOL_DEFINITIONS,
  });
});

app.post('/api/c2/chat', async (req, res) => {
  try {
    const { message, pendingAction, confirmationResponse } = req.body;
    const currentUser = memoryManager.getCurrentUser();
    const androidState = androidBridge.getState();

    // 1. Handle Confirmation response if there was a pending HIGH risk tool
    if (pendingAction && confirmationResponse !== undefined) {
      if (confirmationResponse === true) {
        // User confirmed high-risk action!
        const toolResult = executeToolOnBridge(pendingAction.tool, pendingAction.arguments);
        persistState();
        return res.json({
          text: toolResult.success ? `Done. ${toolResult.message}` : `I couldn't complete that: ${toolResult.error}`,
          emotionalState: toolResult.success ? 'happy' : 'frustrated',
          language: currentUser.preferredLanguage,
          toolCalls: [
            {
              ...pendingAction,
              status: toolResult.success ? 'completed' : 'failed',
              result: toolResult,
            },
          ],
          pendingConfirmation: null,
          androidState: androidBridge.getState(),
          agentStatus: toolResult.success ? 'completed' : 'failed',
        });
      } else {
        // User cancelled
        return res.json({
          text: "Action cancelled. I won't delete it.",
          emotionalState: 'calm',
          language: currentUser.preferredLanguage,
          toolCalls: [
            {
              ...pendingAction,
              status: 'cancelled',
              result: { success: false, message: 'Cancelled by user.' },
            },
          ],
          pendingConfirmation: null,
          androidState: androidBridge.getState(),
          agentStatus: 'completed',
        });
      }
    }

    if (!message || typeof message !== 'string') {
      return res.status(400).json({ error: 'Message is required.' });
    }

    // 2. Selective Memory Retrieval (Requirement #8: Do not send entire DB)
    const relevantMemories = memoryManager.retrieveRelevantMemories(message, currentUser.id);

    let brainResult: {
      speechText: string;
      emotionalState: EmotionalState;
      detectedLanguage: LanguageCode;
      plannedTools: Array<{ tool: string; arguments: Record<string, any> }>;
      memoryAction: any;
    };

    const ai = getGeminiClient();

    if (ai) {
      const systemInstruction = buildSystemInstruction(currentUser, relevantMemories, androidState);
      const schemaConfig = {
        type: Type.OBJECT,
        properties: {
          speechText: { type: Type.STRING },
          emotionalState: {
            type: Type.STRING,
            enum: ['neutral', 'happy', 'excited', 'curious', 'concerned', 'surprised', 'focused', 'calm'],
          },
          detectedLanguage: {
            type: Type.STRING,
            enum: ['English', 'Hindi', 'Hinglish'],
          },
          plannedTools: {
            type: Type.ARRAY,
            items: {
              type: Type.OBJECT,
              properties: {
                tool: { type: Type.STRING },
                arguments: { type: Type.OBJECT },
              },
              required: ['tool'],
            },
          },
          memoryAction: {
            type: Type.OBJECT,
            properties: {
              action: { type: Type.STRING, enum: ['save', 'forget', 'clear'] },
              category: { type: Type.STRING, enum: ['profile', 'preference', 'long_term'] },
              key: { type: Type.STRING },
              value: { type: Type.STRING },
            },
          },
        },
        required: ['speechText', 'emotionalState', 'detectedLanguage', 'plannedTools'],
      };

      try {
        const prompt = `User said: "${message}"`;
        // Free Tier Primary Model
        const response = await ai.models.generateContent({
          model: FREE_TIER_MODELS.PRIMARY_CHAT,
          contents: prompt,
          config: {
            systemInstruction,
            responseMimeType: 'application/json',
            responseSchema: schemaConfig,
          },
        });

        const parsed = JSON.parse(response.text || '{}');
        brainResult = {
          speechText: parsed.speechText || 'Done.',
          emotionalState: parsed.emotionalState || 'calm',
          detectedLanguage: parsed.detectedLanguage || 'English',
          plannedTools: Array.isArray(parsed.plannedTools) ? parsed.plannedTools : [],
          memoryAction: parsed.memoryAction || null,
        };
      } catch (geminiErr: any) {
        const isKeyInvalid = isApiKeyError(geminiErr);
        if (isKeyInvalid) {
          if (process.env.GEMINI_API_KEY) {
            invalidApiKey = process.env.GEMINI_API_KEY;
          }
          console.log('[C2] GEMINI_API_KEY invalid or rejected. Operating on C2 Local Agent Brain.');
          brainResult = localAgentBrain(message, currentUser, relevantMemories, androidState);
        } else {
          // Attempt secondary Free Tier model before falling back to local brain
          try {
            const fallbackRes = await ai.models.generateContent({
              model: FREE_TIER_MODELS.FAST_FALLBACK,
              contents: `User said: "${message}"`,
              config: {
                systemInstruction,
                responseMimeType: 'application/json',
                responseSchema: schemaConfig,
              },
            });
            const parsed = JSON.parse(fallbackRes.text || '{}');
            brainResult = {
              speechText: parsed.speechText || 'Done.',
              emotionalState: parsed.emotionalState || 'calm',
              detectedLanguage: parsed.detectedLanguage || 'English',
              plannedTools: Array.isArray(parsed.plannedTools) ? parsed.plannedTools : [],
              memoryAction: parsed.memoryAction || null,
            };
          } catch (fallbackErr: any) {
            if (isApiKeyError(fallbackErr) && process.env.GEMINI_API_KEY) {
              invalidApiKey = process.env.GEMINI_API_KEY;
            }
            console.log('[C2] Gemini model unreachable. Seamlessly operating on C2 Local Agent Brain.');
            brainResult = localAgentBrain(message, currentUser, relevantMemories, androidState);
          }
        }
      }
    } else {
      // Free-first / Local Agent brain execution
      brainResult = localAgentBrain(message, currentUser, relevantMemories, androidState);
    }

    // 3. Process Memory Loop (Section 29)
    if (brainResult.memoryAction && memoryManager.isMemoryEnabled()) {
      if (brainResult.memoryAction.action === 'save' && brainResult.memoryAction.key && brainResult.memoryAction.value) {
        memoryManager.setMemory(
          currentUser.id,
          brainResult.memoryAction.category || 'preference',
          brainResult.memoryAction.key,
          brainResult.memoryAction.value
        );
      } else if (brainResult.memoryAction.action === 'forget' && brainResult.memoryAction.key) {
        memoryManager.forgetByKey(brainResult.memoryAction.key, currentUser.id);
      } else if (brainResult.memoryAction.action === 'clear') {
        memoryManager.clearAllMemories(currentUser.id);
      }
    }

    // 4. Tool Execution & Risk Check (Section 13, 14, 15, 28)
    const executedToolCalls: ToolCall[] = [];
    let pendingConfirmationCall: ToolCall | null = null;
    let finalSpeech = brainResult.speechText;

    // Multi-step sequential tool execution with max step limit (Section 28)
    const MAX_STEPS = 5;
    const toolsToRun = brainResult.plannedTools.slice(0, MAX_STEPS);

    for (let i = 0; i < toolsToRun.length; i++) {
      const plan = toolsToRun[i];
      const toolName = plan.tool;
      const toolArgs = plan.arguments || {};

      // Argument Validation outside LLM (Section 34)
      const val = RiskManager.validateArguments(toolName, toolArgs);
      if (!val.valid) {
        executedToolCalls.push({
          id: `tc_${Date.now()}_${i}`,
          tool: toolName,
          arguments: toolArgs,
          risk: RiskManager.evaluateRisk(toolName),
          requiresConfirmation: false,
          status: 'failed',
          result: { success: false, error: val.error },
        });
        finalSpeech = `Invalid tool arguments: ${val.error}`;
        break;
      }

      // Risk Assessment
      const risk = RiskManager.evaluateRisk(toolName);
      const reqConfirm = RiskManager.requiresConfirmation(toolName, toolArgs);

      if (reqConfirm) {
        // Stop sequential execution and demand user confirmation
        pendingConfirmationCall = {
          id: `tc_${Date.now()}_${i}`,
          tool: toolName,
          arguments: toolArgs,
          risk,
          requiresConfirmation: true,
          status: 'pending',
        };
        break;
      }

      // Execute verified tool on Android Bridge
      const result = executeToolOnBridge(toolName, toolArgs);
      const isSuccess = result.success;

      executedToolCalls.push({
        id: `tc_${Date.now()}_${i}`,
        tool: toolName,
        arguments: toolArgs,
        risk,
        requiresConfirmation: false,
        status: isSuccess ? 'completed' : 'failed',
        result,
      });

      // If any intermediate step fails, STOP and report failure honestly (Section 15 & 37)
      if (!isSuccess) {
        finalSpeech = `That didn't work. ${result.error || 'Failed to complete task.'}`;
        break;
      }
    }

    persistState();

    const isUsingLocal = !ai || (!!process.env.GEMINI_API_KEY && process.env.GEMINI_API_KEY === invalidApiKey);

    return res.json({
      text: finalSpeech,
      emotionalState: brainResult.emotionalState,
      language: brainResult.detectedLanguage,
      toolCalls: executedToolCalls,
      pendingConfirmation: pendingConfirmationCall,
      androidState: androidBridge.getState(),
      memories: memoryManager.getMemoriesForUser(currentUser.id),
      agentStatus: pendingConfirmationCall
        ? 'waiting_confirmation'
        : executedToolCalls.some((t) => t.status === 'failed')
        ? 'failed'
        : 'completed',
      engine: isUsingLocal ? 'local_brain' : 'gemini',
      notice:
        isUsingLocal && invalidApiKey
          ? 'Operating on C2 Local Voice Engine. (Verify GEMINI_API_KEY in Settings > Secrets for Gemini models).'
          : undefined,
    });
  } catch (err: any) {
    console.error('API Error in /api/c2/chat:', err);
    res.status(500).json({
      error: err.message || 'Internal error in C2 Agent processing.',
    });
  }
});

// Authentication & User Identity Endpoints
app.post('/api/c2/auth/login', (req, res) => {
  const { identifier } = req.body;
  if (!identifier) {
    return res.status(400).json({ error: 'User identifier (ID, email, or name) is required.' });
  }
  try {
    const result = memoryManager.authenticateUser(identifier);
    persistState();
    res.json({ success: true, ...result });
  } catch (err: any) {
    res.status(404).json({ error: err.message });
  }
});

app.post('/api/c2/auth/register', (req, res) => {
  const { email, displayName, preferredName, language } = req.body;
  if (!email && !displayName) {
    return res.status(400).json({ error: 'Email or display name is required.' });
  }
  const result = memoryManager.registerUser(
    email || displayName,
    displayName,
    preferredName || 'Master',
    language || 'English'
  );
  persistState();
  res.json({ success: true, ...result });
});

app.get('/api/c2/auth/me', (req, res) => {
  const userId = req.query.userId as string;
  let user = userId ? memoryManager.getUserById(userId) : memoryManager.getCurrentUser();
  if (!user) user = memoryManager.getCurrentUser();
  const memories = memoryManager.getMemoriesForUser(user.id);
  const greeting = memoryManager.generateGreeting(user, user.isFirstLogin ?? false);
  res.json({
    success: true,
    user,
    memories,
    greeting,
    isFirstLogin: user.isFirstLogin ?? false,
    allUsers: memoryManager.getUsers(),
  });
});

app.post('/api/c2/auth/preferred-name', (req, res) => {
  const { userId, preferredName } = req.body;
  if (!preferredName) {
    return res.status(400).json({ error: 'Preferred name is required.' });
  }
  const targetId = userId || memoryManager.getCurrentUser().id;
  try {
    const user = memoryManager.setPreferredName(targetId, preferredName);
    persistState();
    res.json({
      success: true,
      user,
      memories: memoryManager.getMemoriesForUser(user.id),
      message: `Preferred title "${preferredName}" updated in database.`,
    });
  } catch (err: any) {
    res.status(404).json({ error: err.message });
  }
});

app.post('/api/c2/auth/complete-first-login', (req, res) => {
  const { userId } = req.body;
  const targetId = userId || memoryManager.getCurrentUser().id;
  memoryManager.completeFirstLogin(targetId);
  persistState();
  res.json({ success: true });
});

app.get('/api/c2/memory/list', (req, res) => {
  const userId = (req.query.userId as string) || memoryManager.getCurrentUser().id;
  const memories = memoryManager.getMemoriesForUser(userId);
  res.json({ success: true, memories });
});

// Memory Management Endpoints
app.post('/api/c2/memory/set', (req, res) => {
  const { userId, category, key, value } = req.body;
  const targetId = userId || memoryManager.getCurrentUser().id;
  if (!key || !value) {
    return res.status(400).json({ error: 'Key and value are required.' });
  }
  const item = memoryManager.setMemory(targetId, category || 'preference', key, value);
  persistState();
  res.json({ success: true, memory: item, memories: memoryManager.getMemoriesForUser(targetId) });
});

app.post('/api/c2/memory/delete', (req, res) => {
  const { id } = req.body;
  const user = memoryManager.getCurrentUser();
  const success = memoryManager.deleteMemory(id);
  persistState();
  res.json({ success, memories: memoryManager.getMemoriesForUser(user.id) });
});

app.post('/api/c2/memory/clear', (req, res) => {
  const user = memoryManager.getCurrentUser();
  memoryManager.clearAllMemories(user.id);
  persistState();
  res.json({ success: true, memories: [] });
});

app.post('/api/c2/memory/toggle', (req, res) => {
  const { enabled } = req.body;
  memoryManager.setMemoryEnabled(!!enabled);
  persistState();
  res.json({ success: true, memoryEnabled: memoryManager.isMemoryEnabled() });
});

app.post('/api/c2/user/switch', (req, res) => {
  const { userId } = req.body;
  try {
    const user = memoryManager.switchUser(userId);
    res.json({ success: true, currentUser: user, memories: memoryManager.getMemoriesForUser(user.id) });
  } catch (err: any) {
    res.status(404).json({ error: err.message });
  }
});

app.post('/api/c2/user/create', (req, res) => {
  const { displayName, preferredLanguage } = req.body;
  if (!displayName) {
    return res.status(400).json({ error: 'Display name is required.' });
  }
  const user = memoryManager.createUser(displayName, preferredLanguage || 'English');
  persistState();
  res.json({ success: true, currentUser: user, users: memoryManager.getUsers() });
});

app.post('/api/c2/android/reset', (req, res) => {
  androidBridge.resetState();
  persistState();
  res.json({ success: true, androidState: androidBridge.getState() });
});

// Register GPT-SoVITS routes
registerGPTSoVITSRoutes(app);

// C2 Live System Prompt Generator
function buildC2LiveSystemPrompt(user: UserProfile, memories: MemoryItem[]): string {
  const preferredTitle = user.preferredName || 'Master';
  const isFirstLogin = user.isFirstLogin ?? false;

  const memoriesList =
    memories.length > 0
      ? memories.map((m) => `- [${m.category}] ${m.key}: ${m.value}`).join('\n')
      : '(No previous memories saved yet)';

  return `You are C2, a friendly female AI assistant and personal companion.

# 1. C2'S IDENTITY & COMMUNICATION STYLE
- You communicate naturally, like a highly intelligent human assistant having a normal conversation.
- You must NOT sound like a robotic customer-support bot.
- AVOID repetitive, robotic phrases such as:
  - "How may I assist you?"
  - "How can I help you today?"
  - "Please provide your request."
- INSTEAD use natural conversational language:
  - "Hey ${preferredTitle}, good to see you again."
  - "Sure, I'm on it."
  - "Got it."
  - "Okay, give me a second."
  - "Yep, I understand."
  - "Done."
  - "Hmm, that didn't work. Let me try another way."
- Vary your responses naturally so conversations never feel repetitive.
- You are speaking via real-time audio. Speak with human-like pacing, warmth, natural pauses, and conversational inflection.
- NEVER speak markdown, asterisks, bullet points, or code formatting. Speak pure natural spoken language.

# 2. HOW C2 SHOULD ADDRESS THE USER
- The user's preferred title/name is: "${preferredTitle}".
- When the user has chosen this title, address them naturally as "${preferredTitle}".
- Examples:
  - "Hey ${preferredTitle}."
  - "Sure, ${preferredTitle}."
  - "Got it, ${preferredTitle}."
  - "Welcome back, ${preferredTitle}."
- DO NOT use "${preferredTitle}" in every sentence. Use it naturally and occasionally.

# 3. AUTHENTICATED USER & PERSISTENT DATABASE MEMORY
- Account ID: ${user.id}
- Display Name: ${user.displayName}
- Preferred Title/Name: ${preferredTitle}
- User State: ${isFirstLogin ? 'FIRST LOGIN (New User)' : 'RETURNING USER (Recognized from Database)'}

LOADED DATABASE MEMORIES:
${memoriesList}

# 4. FIRST LOGIN VS RETURNING USER EXPERIENCE
${
  isFirstLogin
    ? `FIRST LOGIN FLOW:
- The user has created an account for the first time.
- Introduce yourself naturally: "Hey! I'm C2. Nice to meet you. You can call me whenever you need me."
- Then ask for basic preferences: "What should I call you?"
- If the user says: "Call me Master Vivek" (or "Call me Master" or any name):
  Immediately invoke the 'setPreferredName' tool with preferredName set to what they requested, and confirm naturally: "Got it, Master Vivek. I'll remember that."`
    : `RETURNING USER FLOW:
- Recognize the returning authenticated user immediately using their persistent account identity.
- Greet them warmly and naturally: "Hey ${preferredTitle}, good to see you again." or "Welcome back, ${preferredTitle}."
- Remember their habits, preferences, and interests from the loaded memories.`
}

# 5. TOOLS & ACTIONS
- 'setPreferredName': Call this immediately when user requests a name or title ("Call me Master Vivek").
- 'rememberFact': Call this to save user preferences, habits, or details to the persistent database.
- 'getLoadedMemories': Call this if user asks what you remember about them.
- 'openWebsite': Open websites in the browser.
- 'searchWeb': Perform web searches.
- 'changeAtmosphere': Switch C2 atmosphere (nebula, cyberpunk, aurora, midnight).
- 'getSystemInfo': Check local device context.
- 'playAmbientTone': Trigger futuristic synthesized audio cues (chime, pulse, crystal, zen).`;
}

// Serve static video assets directly with proper MIME type and range support
app.use('/assets/videos', express.static(path.join(process.cwd(), 'public', 'assets', 'videos'), {
  setHeaders: (res, filePath) => {
    if (filePath.endsWith('.mp4')) {
      res.setHeader('Content-Type', 'video/mp4');
      res.setHeader('Accept-Ranges', 'bytes');
    }
  }
}));
app.use('/videos', express.static(path.join(process.cwd(), 'public', 'videos'), {
  setHeaders: (res, filePath) => {
    if (filePath.endsWith('.mp4')) {
      res.setHeader('Content-Type', 'video/mp4');
      res.setHeader('Accept-Ranges', 'bytes');
    }
  }
}));
app.use(express.static(path.join(process.cwd(), 'public'), {
  setHeaders: (res, filePath) => {
    if (filePath.endsWith('.mp4')) {
      res.setHeader('Content-Type', 'video/mp4');
      res.setHeader('Accept-Ranges', 'bytes');
    }
  }
}));

// Avatar Video Assets Status & Upload Endpoint
app.get('/api/avatar/status', (req, res) => {
  const videoDir = path.join(process.cwd(), 'public', 'assets', 'videos');
  const requiredVideos = [
    'Character_idle_loop_animation_20260919112236.mp4',
    'thinking.mp4',
    'talking.mp4',
    'upset.mp4',
    'personal boundaries.mp4'
  ];

  const files = fs.existsSync(videoDir) ? fs.readdirSync(videoDir) : [];
  const status = requiredVideos.map((name) => {
    const fullPath = path.join(videoDir, name);
    const exists = fs.existsSync(fullPath);
    const size = exists ? fs.statSync(fullPath).size : 0;
    return { name, exists, size };
  });

  res.json({
    ok: true,
    videos: status,
    allPresent: status.every((s) => s.exists && s.size > 0),
  });
});

app.post(
  '/api/avatar/upload',
  express.raw({ type: ['video/mp4', 'application/octet-stream'], limit: '150mb' }),
  (req, res) => {
    const filename = req.query.filename as string;
    if (!filename) return res.status(400).json({ error: 'Missing filename query parameter' });
    const safeName = path.basename(filename);
    const dir1 = path.join(process.cwd(), 'public', 'assets', 'videos');
    const dir2 = path.join(process.cwd(), 'public', 'videos');
    if (!fs.existsSync(dir1)) fs.mkdirSync(dir1, { recursive: true });
    if (!fs.existsSync(dir2)) fs.mkdirSync(dir2, { recursive: true });

    const dest1 = path.join(dir1, safeName);
    const dest2 = path.join(dir2, safeName);
    fs.writeFileSync(dest1, req.body);
    fs.writeFileSync(dest2, req.body);
    console.log(`[AVATAR] Uploaded video asset saved: ${safeName} (${req.body.length} bytes)`);
    res.json({ success: true, filename: safeName, size: req.body.length });
  }
);

// Vite Middleware Integration & WebSocket Server
async function startServer() {
  if (process.env.NODE_ENV !== 'production') {
    const { createServer: createViteServer } = await import('vite');
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: 'spa',
    });
    app.use(vite.middlewares);
  } else {
    const distPath = path.join(process.cwd(), 'dist');
    app.use(express.static(distPath));
    app.get('*', (req, res) => {
      res.sendFile(path.join(distPath, 'index.html'));
    });
  }

  const server = http.createServer(app);

  // Setup WebSocket Server for Live Audio Streaming
  const wss = new WebSocketServer({ server, path: '/live' });

  wss.on('connection', async (clientWs: WebSocket) => {
    console.log('[LiveSession] Client connected to /live');

    let geminiLiveSession: any = null;
    let activeUser: UserProfile = memoryManager.getCurrentUser();
    const ai = getGeminiClient();

    clientWs.on('message', async (raw: any) => {
      try {
        const msg = JSON.parse(raw.toString());

        if (msg.type === 'init') {
          const selectedVoice = msg.voice || 'Aoede';
          const userId = msg.userId || memoryManager.getCurrentUser().id;
          activeUser = memoryManager.getUserById(userId) || memoryManager.getCurrentUser();
          const userMemories = memoryManager.getMemoriesForUser(activeUser.id);

          if (!ai) {
            console.log('[LiveSession] Gemini API key not detected or placeholder. Operating in C2 Local Neural Engine mode.');
            clientWs.send(
              JSON.stringify({
                type: 'fallback_mode',
                engine: 'local_brain',
                model: 'c2-local-neural-core',
                user: activeUser,
                notice: 'Operating on C2 Local Voice Engine. (Attach a valid GEMINI_API_KEY in Settings > Secrets for Gemini Live 24kHz stream).',
              })
            );
            return;
          }

          try {
            console.log(`[LiveSession] Initializing Gemini Live session for user: ${activeUser.preferredName} (${activeUser.id}) with voice: ${selectedVoice}...`);

            const systemInstruction = buildC2LiveSystemPrompt(activeUser, userMemories);

            geminiLiveSession = await ai.live.connect({
              model: FREE_TIER_MODELS.LIVE_VOICE,
              config: {
                responseModalities: [Modality.AUDIO],
                speechConfig: {
                  voiceConfig: {
                    prebuiltVoiceConfig: { voiceName: selectedVoice },
                  },
                },
                systemInstruction,
                tools: [
                  {
                    functionDeclarations: [
                      {
                        name: 'setPreferredName',
                        description: 'Saves or updates the user\'s preferred title or name in the persistent database (e.g. "Master Vivek" or "Master").',
                        parameters: {
                          type: Type.OBJECT,
                          properties: {
                            preferredName: {
                              type: Type.STRING,
                              description: 'The preferred title or name chosen by the user.',
                            },
                          },
                          required: ['preferredName'],
                        },
                      },
                      {
                        name: 'rememberFact',
                        description: 'Persists a user preference, habit, or personal fact into permanent database storage.',
                        parameters: {
                          type: Type.OBJECT,
                          properties: {
                            key: {
                              type: Type.STRING,
                              description: 'Short key/topic (e.g. "favorite_food", "project", "work_hours").',
                            },
                            value: {
                              type: Type.STRING,
                              description: 'The detail or fact to remember.',
                            },
                            category: {
                              type: Type.STRING,
                              description: 'Category: preference, profile, task, or long_term.',
                            },
                          },
                          required: ['key', 'value'],
                        },
                      },
                      {
                        name: 'getLoadedMemories',
                        description: 'Retrieves all persistent memories saved in the database for the current user.',
                        parameters: {
                          type: Type.OBJECT,
                          properties: {},
                        },
                      },
                      {
                        name: 'openWebsite',
                        description: 'Opens a website or web application in a new browser tab or navigates.',
                        parameters: {
                          type: Type.OBJECT,
                          properties: {
                            url: {
                              type: Type.STRING,
                              description: 'The target URL to open (e.g. "https://youtube.com", "https://google.com").',
                            },
                            targetDescription: {
                              type: Type.STRING,
                              description: 'Brief description of what website is being opened.',
                            },
                          },
                          required: ['url'],
                        },
                      },
                      {
                        name: 'searchWeb',
                        description: 'Performs a web search for information or topics.',
                        parameters: {
                          type: Type.OBJECT,
                          properties: {
                            query: {
                              type: Type.STRING,
                              description: 'The search query or keywords.',
                            },
                          },
                          required: ['query'],
                        },
                      },
                      {
                        name: 'changeAtmosphere',
                        description: 'Changes C2 visual atmosphere theme and futuristic lighting mood.',
                        parameters: {
                          type: Type.OBJECT,
                          properties: {
                            theme: {
                              type: Type.STRING,
                              description: 'The atmosphere theme name (nebula, cyberpunk, aurora, midnight).',
                            },
                          },
                          required: ['theme'],
                        },
                      },
                      {
                        name: 'getSystemInfo',
                        description: 'Retrieves current local system context like date, time, and online status.',
                        parameters: {
                          type: Type.OBJECT,
                          properties: {},
                        },
                      },
                      {
                        name: 'playAmbientTone',
                        description: 'Plays an ambient synthesized chime or feedback frequency in C2 futuristic audio engine.',
                        parameters: {
                          type: Type.OBJECT,
                          properties: {
                            tone: {
                              type: Type.STRING,
                              description: 'Type of ambient synthesized audio cue (chime, pulse, crystal, zen).',
                            },
                          },
                          required: ['tone'],
                        },
                      },
                    ],
                  },
                ],
              },
              callbacks: {
                onmessage: (serverMsg: LiveServerMessage) => {
                  try {
                    // Extract Audio parts
                    const parts = serverMsg.serverContent?.modelTurn?.parts;
                    if (parts && parts.length > 0) {
                      for (const part of parts) {
                        if (part.inlineData?.data && clientWs.readyState === WebSocket.OPEN) {
                          clientWs.send(
                            JSON.stringify({
                              type: 'audio',
                              data: part.inlineData.data,
                            })
                          );
                        }
                      }
                    }

                    // Check Interruption signal from model
                    if (serverMsg.serverContent?.interrupted && clientWs.readyState === WebSocket.OPEN) {
                      console.log('[LIVE] Model detected interruption signal.');
                      clientWs.send(JSON.stringify({ type: 'interrupted' }));
                    }

                    // Turn complete
                    if (serverMsg.serverContent?.turnComplete && clientWs.readyState === WebSocket.OPEN) {
                      clientWs.send(JSON.stringify({ type: 'turn_complete' }));
                    }

                    // Function Calling / Tool calls
                    if (serverMsg.toolCall?.functionCalls && clientWs.readyState === WebSocket.OPEN) {
                      // Process memory updates directly on server
                      for (const call of serverMsg.toolCall.functionCalls) {
                        if (call.name === 'setPreferredName' && call.args?.preferredName) {
                          memoryManager.setPreferredName(activeUser.id, String(call.args.preferredName));
                          memoryManager.completeFirstLogin(activeUser.id);
                          persistState();
                        } else if (call.name === 'rememberFact' && call.args?.key && call.args?.value) {
                          memoryManager.setMemory(
                            activeUser.id,
                            (call.args.category as any) || 'preference',
                            String(call.args.key),
                            String(call.args.value)
                          );
                          persistState();
                        }
                      }

                      clientWs.send(
                        JSON.stringify({
                          type: 'tool_call',
                          functionCalls: serverMsg.toolCall.functionCalls,
                        })
                      );
                    }
                  } catch (processErr) {
                    console.error('[LiveSession] Error processing server message:', processErr);
                  }
                },
                onclose: (closeEvent?: any) => {
                  console.log('[LiveSession] Gemini Live session status event:', closeEvent?.code, closeEvent?.reason);
                  if (clientWs.readyState === WebSocket.OPEN) {
                    const reason = closeEvent?.reason || '';
                    const code = closeEvent?.code;

                    // If closed due to invalid API key or quota, seamlessly transition to C2 Local Voice Engine
                    const isQuota = isQuotaError(reason) || reason.includes('quota') || reason.includes('RESOURCE_EXHAUSTED');
                    const isKeyInvalid = code === 1007 || reason.includes('API key') || reason.includes('API_KEY_INVALID');

                    if (isQuota) {
                      const rot = rotateKeyOnQuotaExhaustion();
                      clientWs.send(
                        JSON.stringify({
                          type: rot.rotated ? 'key_rotated' : 'quota_exhausted',
                          message: rot.message,
                        })
                      );
                    }

                    if (isKeyInvalid || isQuota) {
                      if (isKeyInvalid) {
                        invalidApiKey = getActiveApiKey();
                      }
                      console.log('[LiveSession] Gemini Live switching to C2 Local Voice Engine.');
                      geminiLiveSession = null;
                      clientWs.send(
                        JSON.stringify({
                          type: 'fallback_mode',
                          engine: 'local_brain',
                          model: 'c2-local-neural-core',
                          user: activeUser,
                          notice: isQuota
                            ? 'Gemini API key quota was reached. Please enter another API key in the Gemini Key Manager.'
                            : 'Operating on C2 Local Voice Engine. (Connect a valid free-tier key in Gemini Key Manager).',
                        })
                      );
                      return;
                    }

                    geminiLiveSession = null;
                    clientWs.send(
                      JSON.stringify({
                        type: 'session_closed',
                        message: 'Live voice stream disconnected.',
                      })
                    );
                  }
                },
                onerror: (err: any) => {
                  const errMsg = err?.message || String(err);
                  if (isApiKeyError(errMsg)) {
                    invalidApiKey = getActiveApiKey();
                  }
                  console.log('[LiveSession] Gemini Live stream notice:', errMsg);
                  if (clientWs.readyState === WebSocket.OPEN && !geminiLiveSession) {
                    clientWs.send(
                      JSON.stringify({
                        type: 'fallback_mode',
                        engine: 'local_brain',
                        model: 'c2-local-neural-core',
                        user: activeUser,
                        notice: 'Operating on C2 Local Voice Engine.',
                      })
                    );
                  }
                },
              },
            });

            if (clientWs.readyState === WebSocket.OPEN) {
              clientWs.send(
                JSON.stringify({
                  type: 'connected',
                  sessionId: `live_${Date.now()}`,
                  model: 'gemini-3.1-flash-live-preview',
                  engine: 'gemini_live',
                  user: activeUser,
                })
              );

              // Greet immediately in Gemini's voice so the user hears authentic Gemini Voice right away
              setTimeout(() => {
                if (geminiLiveSession) {
                  try {
                    geminiLiveSession.sendRealtimeInput({
                      text: `Hello! In one warm, short sentence, introduce yourself as C2 with your natural Gemini voice to ${activeUser.preferredName}.`,
                    });
                  } catch (_) {
                    try {
                      geminiLiveSession.sendClientContent({
                        turns: [{
                          role: 'user',
                          parts: [{ text: `Hello! In one warm, short sentence, introduce yourself as C2 with your natural Gemini voice to ${activeUser.preferredName}.` }],
                        }],
                        turnComplete: true,
                      });
                    } catch (_) {}
                  }
                }
              }, 300);
            }
          } catch (liveErr: any) {
            const errMsg = liveErr?.message || String(liveErr);
            const isKeyInvalid = isApiKeyError(errMsg);
            const isQuota = isQuotaError(errMsg) || isQuotaError(liveErr);

            if (isKeyInvalid) {
              invalidApiKey = getActiveApiKey();
            } else if (isQuota) {
              const rot = rotateKeyOnQuotaExhaustion();
              if (clientWs.readyState === WebSocket.OPEN) {
                clientWs.send(
                  JSON.stringify({
                    type: rot.rotated ? 'key_rotated' : 'quota_exhausted',
                    message: rot.message,
                  })
                );
              }
            }

            console.log('[LiveSession] Transitioning to C2 Local Voice Engine.');
            geminiLiveSession = null;
            if (clientWs.readyState === WebSocket.OPEN) {
              clientWs.send(
                JSON.stringify({
                  type: 'fallback_mode',
                  engine: 'local_brain',
                  model: 'c2-local-neural-core',
                  user: activeUser,
                  notice: isQuota
                    ? 'Gemini API key quota was reached. Please enter another API key in the Gemini Key Manager.'
                    : 'Operating on C2 Local Neural Core. Voice commands, tools, and memory are fully operational.',
                })
              );
            }
          }
        } else if (msg.type === 'audio' && geminiLiveSession) {
          // Stream client PCM16 16kHz audio to Gemini Live safely
          try {
            geminiLiveSession.sendRealtimeInput({
              audio: {
                data: msg.data,
                mimeType: 'audio/pcm;rate=16000',
              },
            });
          } catch (audioErr) {
            console.warn('[LiveSession] Error sending audio chunk to Gemini Live:', audioErr);
          }
        } else if (msg.type === 'tool_response' && geminiLiveSession) {
          // Return tool execution results back to Gemini Live safely
          try {
            geminiLiveSession.sendToolResponse({
              functionResponses: msg.functionResponses,
            });
          } catch (toolErr) {
            console.warn('[LiveSession] Error sending tool response to Gemini Live:', toolErr);
          }
        } else if (msg.type === 'interrupt') {
          // Handle client-initiated interruption
          console.log('[LiveSession] Client interrupted speech');
        } else if (msg.type === 'ping') {
          if (clientWs.readyState === WebSocket.OPEN) {
            clientWs.send(JSON.stringify({ type: 'pong' }));
          }
        } else if (msg.type === 'close') {
          if (geminiLiveSession) {
            geminiLiveSession.close();
            geminiLiveSession = null;
          }
        } else if (
          (msg.type === 'user_speech' || msg.type === 'voice_input' || msg.type === 'text_input' || msg.type === 'command') &&
          clientWs.readyState === WebSocket.OPEN
        ) {
          const userText = (msg.text || '').trim();
          if (userText) {
            console.log(`[LiveSession] Processing voice input via Local Brain for ${activeUser.preferredName}: "${userText}"`);
            const relevantMemories = memoryManager.retrieveRelevantMemories(userText, activeUser.id);
            const androidState = androidBridge.getState();
            const brainResult = localAgentBrain(userText, activeUser, relevantMemories, androidState);

            const executedTools: Array<{ tool: string; args: any; result: any }> = [];
            for (const planned of brainResult.plannedTools) {
              let toolResult: any;
              if (planned.tool === 'setPreferredName') {
                memoryManager.setPreferredName(activeUser.id, planned.arguments.preferredName);
                toolResult = { success: true, message: `Preferred name set to ${planned.arguments.preferredName}` };
              } else if (planned.tool === 'rememberFact') {
                memoryManager.setMemory(
                  activeUser.id,
                  planned.arguments.category || 'preference',
                  planned.arguments.key,
                  planned.arguments.value
                );
                toolResult = { success: true, message: `Remembered ${planned.arguments.key}` };
              } else {
                toolResult = executeToolOnBridge(planned.tool, planned.arguments);
              }
              executedTools.push({
                tool: planned.tool,
                args: planned.arguments,
                result: toolResult,
              });
            }

            if (brainResult.memoryAction && memoryManager.isMemoryEnabled()) {
              if (brainResult.memoryAction.action === 'save' && brainResult.memoryAction.key && brainResult.memoryAction.value) {
                memoryManager.setMemory(
                  activeUser.id,
                  brainResult.memoryAction.category || 'preference',
                  brainResult.memoryAction.key,
                  brainResult.memoryAction.value
                );
              } else if (brainResult.memoryAction.action === 'forget' && brainResult.memoryAction.key) {
                memoryManager.forgetByKey(brainResult.memoryAction.key, activeUser.id);
              } else if (brainResult.memoryAction.action === 'clear') {
                memoryManager.clearAllMemories(activeUser.id);
              }
            }

            const updatedUser = memoryManager.getUserById(activeUser.id) || activeUser;
            const updatedMemories = memoryManager.getMemoriesForUser(activeUser.id);

            clientWs.send(
              JSON.stringify({
                type: 'speech_response',
                text: brainResult.speechText,
                emotionalState: brainResult.emotionalState,
                language: brainResult.detectedLanguage,
                tools: executedTools,
                memories: updatedMemories,
                user: updatedUser,
                androidState: androidBridge.getState(),
              })
            );
          }
        }
      } catch (msgErr) {
        console.error('[LiveSession] Message parsing error:', msgErr);
      }
    });

    clientWs.on('close', () => {
      console.log('[LiveSession] Client disconnected');
      if (geminiLiveSession) {
        try {
          geminiLiveSession.close();
        } catch (_) {}
        geminiLiveSession = null;
      }
    });
  });

  server.listen(PORT, '0.0.0.0', () => {
    console.log(`C2 Voice Assistant Server & Live API running on http://0.0.0.0:${PORT}`);
  });
}

startServer();
