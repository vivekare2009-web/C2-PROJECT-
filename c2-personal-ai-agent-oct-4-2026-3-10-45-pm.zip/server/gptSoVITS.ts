import path from 'path';
import fs from 'fs';
import type { Request, Response, Express } from 'express';

export interface TTSRequestPayload {
  text: string;
  text_lang?: string;
  ref_audio_path?: string;
  prompt_text?: string;
  prompt_lang?: string;
  emotion?: string;
}

export interface GPTSoVITSConnectionInfo {
  ok: boolean;
  status: 'online' | 'offline' | 'not_configured' | 'error';
  url: string;
  latency?: number;
  error?: string;
  refAudioFound: boolean;
  refAudioPath: string;
}

// Configurable endpoint with persistence support - DORMANT until real URL configured
let activeGptSoVitsUrl = (process.env.GPT_SOVITS_URL || '').trim();
const DEFAULT_PROMPT_TEXT = 'Yeh painting, mujhe yeh wali painting achi lagi. Aisa hai to is painting ko yahan rakhna hi nahi.';
const DEFAULT_PROMPT_LANG = 'hi';

/**
 * Get resolved absolute server path for the reference audio
 */
export function getReferenceAudioPath(): string {
  const primaryPath = path.join(process.cwd(), 'voice', 'euphemiya_reference.wav');
  if (fs.existsSync(primaryPath)) {
    return primaryPath;
  }
  const publicPath = path.join(process.cwd(), 'public', 'voice', 'euphemiya_reference.wav');
  if (fs.existsSync(publicPath)) {
    return publicPath;
  }
  return primaryPath;
}

/**
 * Check if the reference audio file is present
 */
export function isReferenceAudioAvailable(): boolean {
  return fs.existsSync(getReferenceAudioPath());
}

/**
 * Probe the GPT-SoVITS server (only if an explicit URL is provided)
 */
export async function checkGPTSoVITSConnection(customUrl?: string): Promise<GPTSoVITSConnectionInfo> {
  const targetUrl = typeof customUrl === 'string' ? customUrl.trim().replace(/\/+$/, '') : activeGptSoVitsUrl.replace(/\/+$/, '');
  const refPath = getReferenceAudioPath();
  const refFound = fs.existsSync(refPath);

  // If no URL is configured, stay completely dormant - do not connect to 127.0.0.1:9880
  if (!targetUrl) {
    return {
      ok: false,
      status: 'not_configured',
      url: '',
      refAudioFound: refFound,
      refAudioPath: refPath,
    };
  }

  const startTime = Date.now();
  try {
    const controller = new AbortController();
    const timeoutId = setTimeout(() => controller.abort(), 2500);

    // GPT-SoVITS api.py supports GET / or GET /tts
    const probeRes = await fetch(`${targetUrl}/`, {
      method: 'GET',
      signal: controller.signal,
    }).catch(async () => {
      // Secondary probe to /tts
      return await fetch(`${targetUrl}/tts`, {
        method: 'GET',
        signal: controller.signal,
      });
    });

    clearTimeout(timeoutId);
    const latency = Date.now() - startTime;

    if (probeRes.ok || probeRes.status === 400 || probeRes.status === 404 || probeRes.status === 405) {
      return {
        ok: true,
        status: 'online',
        url: targetUrl,
        latency,
        refAudioFound: refFound,
        refAudioPath: refPath,
      };
    }

    return {
      ok: false,
      status: 'error',
      url: targetUrl,
      latency,
      error: `Server returned HTTP status ${probeRes.status}`,
      refAudioFound: refFound,
      refAudioPath: refPath,
    };
  } catch (err: any) {
    const latency = Date.now() - startTime;
    return {
      ok: false,
      status: 'offline',
      url: targetUrl,
      latency,
      error: err?.message || 'Connection refused or timed out',
      refAudioFound: refFound,
      refAudioPath: refPath,
    };
  }
}

/**
 * Synthesize speech through the GPT-SoVITS API
 */
export async function synthesizeWithGPTSoVITS(params: {
  text: string;
  text_lang?: string;
  emotion?: string;
}): Promise<{
  ok: boolean;
  audioBuffer?: Buffer;
  contentType?: string;
  error?: string;
  latency?: number;
}> {
  if (!activeGptSoVitsUrl) {
    return {
      ok: false,
      error: 'GPT-SoVITS endpoint is not configured',
    };
  }

  const targetUrl = activeGptSoVitsUrl.replace(/\/+$/, '');
  const refPath = getReferenceAudioPath();

  if (!fs.existsSync(refPath)) {
    return {
      ok: false,
      error: `Reference audio file not found at: ${refPath}`,
    };
  }

  const payload: TTSRequestPayload = {
    text: params.text,
    text_lang: params.text_lang || 'en',
    ref_audio_path: refPath,
    prompt_text: DEFAULT_PROMPT_TEXT,
    prompt_lang: DEFAULT_PROMPT_LANG,
    emotion: params.emotion || 'neutral',
  };

  const startTime = Date.now();
  try {
    const controller = new AbortController();
    const timeoutId = setTimeout(() => controller.abort(), 18000);

    console.log(`[GPT-SoVITS] Requesting speech synthesis from: ${targetUrl}/tts for "${params.text.substring(0, 40)}..."`);
    const res = await fetch(`${targetUrl}/tts`, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
      },
      body: JSON.stringify(payload),
      signal: controller.signal,
    });

    clearTimeout(timeoutId);
    const latency = Date.now() - startTime;

    if (!res.ok) {
      const errText = await res.text().catch(() => '');
      console.warn(`[GPT-SoVITS] Server error ${res.status}: ${errText}`);
      return {
        ok: false,
        error: `GPT-SoVITS error (${res.status}): ${errText.substring(0, 120)}`,
        latency,
      };
    }

    const arrayBuffer = await res.arrayBuffer();
    const buffer = Buffer.from(arrayBuffer);

    if (buffer.length < 44) {
      return {
        ok: false,
        error: 'Invalid or truncated audio received from GPT-SoVITS',
        latency,
      };
    }

    console.log(`[GPT-SoVITS] Synthesis completed in ${latency}ms, audio size: ${buffer.length} bytes`);
    return {
      ok: true,
      audioBuffer: buffer,
      contentType: 'audio/wav',
      latency,
    };
  } catch (err: any) {
    const latency = Date.now() - startTime;
    console.warn(`[GPT-SoVITS] Synthesis request failed (${latency}ms):`, err?.message);
    return {
      ok: false,
      error: err?.message || 'TTS connection failed',
      latency,
    };
  }
}

/**
 * Register Express endpoints for GPT-SoVITS
 */
export function registerGPTSoVITSRoutes(app: Express) {
  // Check connection status
  app.get('/api/c2/tts/status', async (req: Request, res: Response) => {
    const info = await checkGPTSoVITSConnection();
    res.json(info);
  });

  // Update configuration or target endpoint
  app.post('/api/c2/tts/config', async (req: Request, res: Response) => {
    const { url } = req.body;
    if (typeof url === 'string' && url.trim()) {
      activeGptSoVitsUrl = url.trim();
      console.log(`[GPT-SoVITS] Updated active endpoint to: ${activeGptSoVitsUrl}`);
    }
    const info = await checkGPTSoVITSConnection();
    res.json(info);
  });

  // Synthesize speech endpoint
  app.post('/api/c2/tts/synthesize', async (req: Request, res: Response) => {
    const { text, text_lang, emotion } = req.body;
    if (!text || typeof text !== 'string') {
      res.status(400).json({ error: 'Text is required for speech synthesis' });
      return;
    }

    const result = await synthesizeWithGPTSoVITS({
      text: text.trim(),
      text_lang,
      emotion,
    });

    if (!result.ok || !result.audioBuffer) {
      res.status(502).json({
        error: result.error || 'Speech synthesis failed',
        latency: result.latency,
      });
      return;
    }

    res.set({
      'Content-Type': result.contentType || 'audio/wav',
      'Content-Length': result.audioBuffer.length.toString(),
      'X-TTS-Latency': String(result.latency || 0),
    });
    res.send(result.audioBuffer);
  });

  // Serve the reference audio file
  app.get('/voice/euphemiya_reference.wav', (req: Request, res: Response) => {
    const refPath = getReferenceAudioPath();
    if (fs.existsSync(refPath)) {
      res.sendFile(refPath);
    } else {
      res.status(404).send('Reference audio not found');
    }
  });
}
