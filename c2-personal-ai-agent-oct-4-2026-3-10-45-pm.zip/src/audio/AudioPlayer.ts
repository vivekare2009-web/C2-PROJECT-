/**
 * AudioPlayer
 * Manages Web Audio API AudioContext for:
 * 1. GPT-SoVITS decoded WAV audio playback
 * 2. Gemini Live 24kHz PCM gapless chunk playback
 * Supports instantaneous interruption, waveform analysis, and gapless queuing.
 */

export type SpeakingCallback = (speaking: boolean) => void;
export type OutputLevelCallback = (level: number) => void;

export class AudioPlayer {
  private audioContext: AudioContext | null = null;
  private analyserNode: AnalyserNode | null = null;
  private masterGain: GainNode | null = null;

  private nextStartTime: number = 0;
  private activeSources: Set<AudioBufferSourceNode> = new Set();
  private isSpeaking: boolean = false;
  private animationFrameId: number | null = null;
  private chunkCounter: number = 0;
  private lastLevelReportTime: number = 0;
  private lastReportedLevel: number = 0;

  private onSpeakingChange: SpeakingCallback | null = null;
  private onLevelChange: OutputLevelCallback | null = null;

  constructor() {}

  public setCallbacks(onSpeakingChange: SpeakingCallback, onLevelChange?: OutputLevelCallback) {
    this.onSpeakingChange = onSpeakingChange;
    if (onLevelChange) this.onLevelChange = onLevelChange;
  }

  private initAudioContext(): AudioContext {
    if (!this.audioContext || this.audioContext.state === 'closed') {
      const AudioContextClass = window.AudioContext || (window as any).webkitAudioContext;
      if (!AudioContextClass) {
        throw new Error('Web Audio API is not supported in this browser.');
      }

      try {
        this.audioContext = new AudioContextClass({ sampleRate: 24000 });
      } catch (_) {
        this.audioContext = new AudioContextClass();
      }

      this.masterGain = this.audioContext.createGain();
      this.masterGain.gain.setValueAtTime(1.0, this.audioContext.currentTime);

      this.analyserNode = this.audioContext.createAnalyser();
      this.analyserNode.fftSize = 256;
      this.analyserNode.smoothingTimeConstant = 0.3;

      this.masterGain.connect(this.analyserNode);
      this.analyserNode.connect(this.audioContext.destination);

      this.startLevelLoop();
      console.log(`[AUDIO] AudioPlayer context created at ${this.audioContext.sampleRate}Hz, state: ${this.audioContext.state}`);
    }

    if (this.audioContext.state === 'suspended') {
      this.audioContext.resume().catch((err) => {
        console.warn('[AUDIO] AudioPlayer resume warning:', err);
      });
    }

    return this.audioContext;
  }

  /**
   * Play decoded WAV audio from GPT-SoVITS
   */
  public async playWavAudio(audioData: ArrayBuffer | Blob): Promise<boolean> {
    try {
      const ctx = this.initAudioContext();
      let arrayBuffer: ArrayBuffer;

      if (audioData instanceof Blob) {
        arrayBuffer = await audioData.arrayBuffer();
      } else {
        // Clone array buffer because decodeAudioData detaches the buffer in some browsers
        arrayBuffer = audioData.slice(0);
      }

      if (arrayBuffer.byteLength < 44) {
        console.warn('[AUDIO] Invalid or empty audio buffer passed to playWavAudio');
        return false;
      }

      // Decode audio data asynchronously
      const audioBuffer = await ctx.decodeAudioData(arrayBuffer);
      if (!audioBuffer || audioBuffer.length === 0) {
        return false;
      }

      const source = ctx.createBufferSource();
      source.buffer = audioBuffer;
      source.connect(this.masterGain!);

      const currentTime = ctx.currentTime;
      if (this.nextStartTime < currentTime) {
        this.nextStartTime = currentTime;
      }

      source.start(this.nextStartTime);
      this.nextStartTime += audioBuffer.duration;
      this.activeSources.add(source);

      if (!this.isSpeaking) {
        this.updateSpeaking(true);
      }

      return new Promise<boolean>((resolve) => {
        source.onended = () => {
          this.activeSources.delete(source);
          if (this.activeSources.size === 0) {
            if (ctx.currentTime >= this.nextStartTime - 0.05) {
              this.updateSpeaking(false);
            }
          }
          resolve(true);
        };
      });
    } catch (err) {
      console.error('[AUDIO] Error playing WAV audio buffer:', err);
      return false;
    }
  }

  /**
   * Schedules a raw 24kHz PCM16 chunk for gapless playback
   */
  public playChunk(base64Audio: string) {
    try {
      const ctx = this.initAudioContext();
      const pcm16Data = this.base64ToInt16Array(base64Audio);

      if (pcm16Data.length === 0) return;

      this.chunkCounter++;

      const sampleRate = 24000;
      const audioBuffer = ctx.createBuffer(1, pcm16Data.length, sampleRate);
      const channelData = audioBuffer.getChannelData(0);

      // Convert Int16 [-32768, 32767] to Float32 [-1.0, 1.0]
      for (let i = 0; i < pcm16Data.length; i++) {
        channelData[i] = pcm16Data[i] / 32768.0;
      }

      const source = ctx.createBufferSource();
      source.buffer = audioBuffer;
      source.connect(this.masterGain!);

      // Calculate gapless start time
      const currentTime = ctx.currentTime;
      if (this.nextStartTime < currentTime) {
        this.nextStartTime = currentTime;
      }

      source.start(this.nextStartTime);
      this.nextStartTime += audioBuffer.duration;

      this.activeSources.add(source);
      if (!this.isSpeaking) {
        this.updateSpeaking(true);
      }

      source.onended = () => {
        this.activeSources.delete(source);
        if (this.activeSources.size === 0) {
          if (ctx.currentTime >= this.nextStartTime - 0.05) {
            this.updateSpeaking(false);
          }
        }
      };
    } catch (err) {
      console.error('[AUDIO] Failed to play audio chunk in AudioPlayer:', err);
    }
  }

  /**
   * Instantly stops playback upon interruption signal from model or user
   */
  public interrupt() {
    // Quick micro-fade to avoid audible audio popping
    if (this.masterGain && this.audioContext) {
      try {
        const now = this.audioContext.currentTime;
        this.masterGain.gain.setValueAtTime(this.masterGain.gain.value, now);
        this.masterGain.gain.linearRampToValueAtTime(0.001, now + 0.015);
      } catch (_) {}
    }

    this.activeSources.forEach((src) => {
      try {
        src.stop();
        src.disconnect();
      } catch (_) {}
    });
    this.activeSources.clear();

    if (this.audioContext) {
      this.nextStartTime = this.audioContext.currentTime;
      if (this.masterGain) {
        try {
          const now = this.audioContext.currentTime;
          this.masterGain.gain.setValueAtTime(1.0, now + 0.025);
        } catch (_) {}
      }
    } else {
      this.nextStartTime = 0;
    }

    this.updateSpeaking(false);
  }

  public stop() {
    this.interrupt();

    if (this.animationFrameId !== null) {
      cancelAnimationFrame(this.animationFrameId);
      this.animationFrameId = null;
    }

    if (this.audioContext && this.audioContext.state !== 'closed') {
      this.audioContext.close().catch(() => {});
      this.audioContext = null;
    }

    this.lastReportedLevel = 0;
    if (this.onLevelChange) {
      this.onLevelChange(0);
    }
  }

  public getIsSpeaking(): boolean {
    return this.isSpeaking;
  }

  private updateSpeaking(val: boolean) {
    if (this.isSpeaking !== val) {
      this.isSpeaking = val;
      if (this.onSpeakingChange) {
        this.onSpeakingChange(val);
      }
    }
  }

  private startLevelLoop() {
    if (this.animationFrameId !== null) return;

    const dataArray = new Uint8Array(this.analyserNode?.frequencyBinCount || 128);

    const checkLevel = () => {
      if (this.analyserNode && this.isSpeaking) {
        this.analyserNode.getByteFrequencyData(dataArray);

        let sum = 0;
        for (let i = 0; i < dataArray.length; i++) {
          sum += dataArray[i];
        }
        const average = sum / dataArray.length;
        const normalized = Math.min(100, Math.round((average / 128) * 100));

        const now = performance.now();
        if (now - this.lastLevelReportTime > 50 || Math.abs(normalized - this.lastReportedLevel) > 5) {
          this.lastLevelReportTime = now;
          this.lastReportedLevel = normalized;
          if (this.onLevelChange) {
            this.onLevelChange(normalized);
          }
        }
      } else if (!this.isSpeaking && this.lastReportedLevel !== 0) {
        this.lastReportedLevel = 0;
        if (this.onLevelChange) {
          this.onLevelChange(0);
        }
      }

      this.animationFrameId = requestAnimationFrame(checkLevel);
    };

    this.animationFrameId = requestAnimationFrame(checkLevel);
  }

  private base64ToInt16Array(base64: string): Int16Array {
    try {
      const binaryString = window.atob(base64);
      const len = binaryString.length;
      const bytes = new Uint8Array(len);
      for (let i = 0; i < len; i++) {
        bytes[i] = binaryString.charCodeAt(i);
      }
      return new Int16Array(bytes.buffer);
    } catch (e) {
      console.warn('[AUDIO] Error decoding base64 audio in AudioPlayer:', e);
      return new Int16Array(0);
    }
  }
}
