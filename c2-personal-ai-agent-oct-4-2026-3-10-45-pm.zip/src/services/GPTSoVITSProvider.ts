/**
 * GPTSoVITSProvider
 * Client-side provider service for GPT-SoVITS Text-to-Speech synthesis.
 * Encapsulates connection checking, audio synthesis, cancellation, and status tracking.
 */

import {
  GPTSoVITSStatus,
  normalizeTextForSpeech,
  detectLanguageForTTS,
  VoiceEmotion,
} from '../config/voiceConfig';

export interface TTSGenerationResult {
  success: boolean;
  audioData?: ArrayBuffer;
  error?: string;
  latency?: number;
}

export class GPTSoVITSProvider {
  private status: GPTSoVITSStatus = 'GPT-SOVITS NOT CONFIGURED';
  private currentAbortController: AbortController | null = null;
  private statusListeners: Set<(status: GPTSoVITSStatus) => void> = new Set();
  private endpointUrl: string = '';
  private lastLatency: number = 0;

  constructor() {
    // Initial check without probing unreachable ports
    this.checkConnection();
  }

  /**
   * Subscribe to status updates
   */
  public onStatusChange(callback: (status: GPTSoVITSStatus) => void): () => void {
    this.statusListeners.add(callback);
    callback(this.status);
    return () => this.statusListeners.delete(callback);
  }

  private setStatus(newStatus: GPTSoVITSStatus) {
    if (this.status !== newStatus) {
      this.status = newStatus;
      this.statusListeners.forEach((listener) => {
        try {
          listener(newStatus);
        } catch (e) {
          console.error('[GPTSoVITSProvider] Listener error:', e);
        }
      });
    }
  }

  /**
   * Get current engine status
   */
  public getStatus(): GPTSoVITSStatus {
    return this.status;
  }

  /**
   * Get the last measured roundtrip latency
   */
  public getLastLatency(): number {
    return this.lastLatency;
  }

  /**
   * Check connection to GPT-SoVITS via server proxy
   */
  public async checkConnection(): Promise<boolean> {
    try {
      const res = await fetch('/api/c2/tts/status');
      if (!res.ok) {
        this.setStatus(this.endpointUrl ? 'GPT-SOVITS OFFLINE' : 'GPT-SOVITS NOT CONFIGURED');
        return false;
      }
      const data = await res.json();
      if (data.status === 'not_configured' || !data.url) {
        this.endpointUrl = '';
        this.setStatus('GPT-SOVITS NOT CONFIGURED');
        return false;
      }
      if (data.ok && data.status === 'online') {
        this.endpointUrl = data.url;
        this.lastLatency = data.latency || 0;
        this.setStatus('GPT-SOVITS READY');
        console.log(`[GPTSoVITSProvider] Connected to real GPT-SoVITS server at ${data.url} (${this.lastLatency}ms)`);
        return true;
      } else {
        this.endpointUrl = data.url || this.endpointUrl;
        this.setStatus('GPT-SOVITS OFFLINE');
        return false;
      }
    } catch (err) {
      this.setStatus(this.endpointUrl ? 'GPT-SOVITS OFFLINE' : 'GPT-SOVITS NOT CONFIGURED');
      return false;
    }
  }

  /**
   * Update target GPT-SoVITS endpoint
   */
  public async updateEndpoint(newUrl: string): Promise<boolean> {
    const trimmed = (newUrl || '').trim();
    if (!trimmed) {
      this.endpointUrl = '';
      this.setStatus('GPT-SOVITS NOT CONFIGURED');
      try {
        await fetch('/api/c2/tts/config', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({ url: '' }),
        });
      } catch (_) {}
      return false;
    }

    try {
      this.setStatus('GPT-SOVITS CONNECTING');
      const res = await fetch('/api/c2/tts/config', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ url: trimmed }),
      });
      const data = await res.json();
      if (data.ok && data.status === 'online') {
        this.endpointUrl = data.url;
        this.lastLatency = data.latency || 0;
        this.setStatus('GPT-SOVITS READY');
        return true;
      } else {
        this.endpointUrl = trimmed;
        this.setStatus('GPT-SOVITS OFFLINE');
        return false;
      }
    } catch (_) {
      this.endpointUrl = trimmed;
      this.setStatus('GPT-SOVITS OFFLINE');
      return false;
    }
  }

  /**
   * Generate speech audio for given text
   */
  public async generateSpeech(
    rawText: string,
    options?: { emotion?: VoiceEmotion; language?: string }
  ): Promise<ArrayBuffer | null> {
    // If not configured or not connected to a real server, stay dormant
    if (this.status === 'GPT-SOVITS NOT CONFIGURED' || !this.endpointUrl) {
      return null;
    }
    const cleanText = normalizeTextForSpeech(rawText);
    if (!cleanText) {
      return null;
    }

    // Cancel any previous pending request
    this.cancelSpeech();

    const controller = new AbortController();
    this.currentAbortController = controller;
    this.setStatus('GPT-SOVITS GENERATING');

    const textLang = options?.language || detectLanguageForTTS(cleanText);
    const startTime = performance.now();

    try {
      const response = await fetch('/api/c2/tts/synthesize', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({
          text: cleanText,
          text_lang: textLang,
          emotion: options?.emotion || 'neutral',
        }),
        signal: controller.signal,
      });

      if (!response.ok) {
        throw new Error(`TTS server returned status ${response.status}`);
      }

      const arrayBuffer = await response.arrayBuffer();

      // Validate WAV audio header (RIFF ... WAVE)
      if (arrayBuffer.byteLength < 44) {
        throw new Error('Received truncated or invalid audio data from TTS');
      }

      const headerView = new Uint8Array(arrayBuffer, 0, 4);
      const isRiff =
        headerView[0] === 0x52 && // 'R'
        headerView[1] === 0x49 && // 'I'
        headerView[2] === 0x46 && // 'F'
        headerView[3] === 0x46;   // 'F'

      if (!isRiff) {
        console.warn('[GPTSoVITSProvider] Warning: Audio response does not have standard RIFF header, attempting playback');
      }

      this.lastLatency = Math.round(performance.now() - startTime);
      console.log(`[GPTSoVITSProvider] Speech generated successfully (${arrayBuffer.byteLength} bytes, ${this.lastLatency}ms)`);

      this.setStatus('GPT-SOVITS READY');
      this.currentAbortController = null;
      return arrayBuffer;
    } catch (err: any) {
      if (err.name === 'AbortError') {
        console.log('[GPTSoVITSProvider] Speech generation was cancelled by user/interruption');
        this.setStatus('GPT-SOVITS READY');
        return null;
      }

      console.warn('[GPTSoVITSProvider] Speech synthesis failed:', err?.message);
      this.setStatus('GPT-SOVITS ERROR');
      this.currentAbortController = null;
      return null;
    }
  }

  /**
   * Cancel in-flight TTS generation request
   */
  public cancelSpeech(): void {
    if (this.currentAbortController) {
      console.log('[GPTSoVITSProvider] Cancelling active speech synthesis request');
      this.currentAbortController.abort();
      this.currentAbortController = null;
      if (this.status === 'GPT-SOVITS GENERATING') {
        this.setStatus('GPT-SOVITS READY');
      }
    }
  }

  /**
   * Mark as speaking or finished speaking
   */
  public setSpeaking(speaking: boolean) {
    if (speaking) {
      this.setStatus('GPT-SOVITS SPEAKING');
    } else if (this.status === 'GPT-SOVITS SPEAKING') {
      this.setStatus('GPT-SOVITS READY');
    }
  }

  public getEndpointUrl(): string {
    return this.endpointUrl;
  }
}

// Global singleton instance for app-wide TTS coordination
export const gptSoVITSProvider = new GPTSoVITSProvider();
