/**
 * AvatarTouchLayer
 * 
 * Transparent, high-precision touch interaction overlay for C2.
 * Accurately projects touch / pointer coordinates onto normalized (0..1) character bounds,
 * taking object-fit: contain letterboxing/pillarboxing into account.
 */

import React, { useRef, useState, useCallback } from 'react';
import { TouchZone } from '../../modules/avatar/types';
import { avatarVideoStateManager } from '../../modules/avatar/AvatarVideoStateManager';

interface AvatarTouchLayerProps {
  containerRef: React.RefObject<HTMLDivElement | null>;
  zones: TouchZone[];
  debug: boolean;
  videoAspectRatio?: number; // default 9/16 = 0.5625
  onTouchTriggered?: (zone: TouchZone) => void;
}

export const AvatarTouchLayer: React.FC<AvatarTouchLayerProps> = ({
  containerRef,
  zones,
  debug,
  videoAspectRatio = 9 / 16,
  onTouchTriggered,
}) => {
  const [lastTouchPoint, setLastTouchPoint] = useState<{ x: number; y: number } | null>(null);
  const [feedbackZone, setFeedbackZone] = useState<string | null>(null);
  const feedbackTimeoutRef = useRef<number | null>(null);

  /**
   * Converts client (pointer/touch) screen coordinates to normalized (0..1) video coordinates
   */
  const getNormalizedCoordinates = useCallback(
    (clientX: number, clientY: number): { normX: number; normY: number; insideVideo: boolean } => {
      const container = containerRef.current;
      if (!container) return { normX: -1, normY: -1, insideVideo: false };

      const rect = container.getBoundingClientRect();
      const containerW = rect.width;
      const containerH = rect.height;

      if (containerW <= 0 || containerH <= 0) {
        return { normX: -1, normY: -1, insideVideo: false };
      }

      const containerAR = containerW / containerH;
      let videoW = containerW;
      let videoH = containerH;
      let offsetX = 0;
      let offsetY = 0;

      // Handle letterbox / pillarbox from object-fit: contain
      if (containerAR > videoAspectRatio) {
        // Pillarbox (wider container: video fits to height)
        videoH = containerH;
        videoW = containerH * videoAspectRatio;
        offsetX = (containerW - videoW) / 2;
      } else {
        // Letterbox (taller container: video fits to width)
        videoW = containerW;
        videoH = containerW / videoAspectRatio;
        offsetY = (containerH - videoH) / 2;
      }

      const touchLocalX = clientX - rect.left - offsetX;
      const touchLocalY = clientY - rect.top - offsetY;

      const normX = touchLocalX / videoW;
      const normY = touchLocalY / videoH;

      const insideVideo = normX >= 0 && normX <= 1 && normY >= 0 && normY <= 1;
      return { normX, normY, insideVideo };
    },
    [containerRef, videoAspectRatio]
  );

  const handlePointerDown = useCallback(
    (e: React.PointerEvent<HTMLDivElement>) => {
      // Ignore right clicks or secondary buttons
      if (e.button !== 0 && e.pointerType === 'mouse') return;

      const { normX, normY, insideVideo } = getNormalizedCoordinates(e.clientX, e.clientY);

      if (debug) {
        setLastTouchPoint({ x: Math.max(0, Math.min(1, normX)), y: Math.max(0, Math.min(1, normY)) });
      }

      if (!insideVideo) {
        return; // Touched outside character video area (e.g. background margins)
      }

      const result = avatarVideoStateManager.handleTouch(normX, normY);
      if (result.triggered && result.zone) {
        if (onTouchTriggered) onTouchTriggered(result.zone);

        if (debug) {
          setFeedbackZone(result.zone.id);
          if (feedbackTimeoutRef.current) clearTimeout(feedbackTimeoutRef.current);
          feedbackTimeoutRef.current = window.setTimeout(() => setFeedbackZone(null), 1200);
        }
      }
    },
    [getNormalizedCoordinates, debug, onTouchTriggered]
  );

  return (
    <div
      className="absolute inset-0 z-30 touch-none select-none cursor-pointer"
      onPointerDown={handlePointerDown}
      style={{
        WebkitTapHighlightColor: 'transparent',
      }}
      aria-label="Character Interaction Layer"
    >
      {/* Developer Debug Zone Visualizer (ONLY rendered when debug=true) */}
      {debug && (
        <div className="absolute inset-0 pointer-events-none">
          {zones.map((zone) => {
            const isHit = feedbackZone === zone.id;
            return (
              <div
                key={zone.id}
                className={`absolute border-2 rounded transition-all duration-200 flex flex-col justify-start items-start p-1 text-[10px] font-mono leading-none ${
                  !zone.enabled
                    ? 'border-gray-500/40 bg-gray-500/10 text-gray-400'
                    : isHit
                    ? 'border-red-400 bg-red-500/30 text-red-200 scale-[1.02] shadow-lg shadow-red-500/50'
                    : 'border-amber-400/70 bg-amber-500/15 text-amber-200'
                }`}
                style={{
                  left: `${zone.x * 100}%`,
                  top: `${zone.y * 100}%`,
                  width: `${zone.width * 100}%`,
                  height: `${zone.height * 100}%`,
                }}
              >
                <span className="font-bold bg-black/60 px-1 py-0.5 rounded">
                  {zone.name}
                </span>
                <span className="text-[9px] text-white/70 bg-black/40 px-0.5 rounded mt-0.5">
                  ({zone.x.toFixed(2)}, {zone.y.toFixed(2)})
                </span>
              </div>
            );
          })}

          {/* Last Touch Coordinate Marker */}
          {lastTouchPoint && (
            <div
              className="absolute w-3 h-3 -translate-x-1.5 -translate-y-1.5 rounded-full bg-cyan-400 border border-white shadow-md animate-ping"
              style={{
                left: `${lastTouchPoint.x * 100}%`,
                top: `${lastTouchPoint.y * 100}%`,
              }}
            />
          )}
        </div>
      )}
    </div>
  );
};
