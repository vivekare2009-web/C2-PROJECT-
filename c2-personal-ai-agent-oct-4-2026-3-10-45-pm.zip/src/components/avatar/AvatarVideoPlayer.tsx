/**
 * AvatarVideoPlayer
 * 
 * High-performance animated character video renderer for C2.
 * Features:
 * - 5 States: IDLE, THINKING, TALKING, UPSET, PERSONAL_BOUNDARY
 * - Zero black-frame flicker transitions via double-buffered video swapping
 * - MANDATORY AUDIO RULE: Video audio is permanently MUTED (volume 0, muted=true).
 * - Full Android / Mobile browser compatibility (playsInline, webkit-playsinline)
 * - Transparent touch-boundary interaction overlay
 * - Non-blocking fallback recovery and clear asset error diagnostics
 * - Reliable fallback poster images for all 5 states
 */

import React, { useEffect, useRef, useState, useCallback } from 'react';
import {
  AvatarConfig,
  AvatarVideoState,
  TouchZone,
  VIDEO_ASSET_MAP,
  VideoAssetInfo,
} from '../../modules/avatar/types';
import { avatarVideoStateManager } from '../../modules/avatar/AvatarVideoStateManager';
import { AvatarTouchLayer } from './AvatarTouchLayer';
import { Sparkles, AlertCircle } from 'lucide-react';

const FALLBACK_IMAGE_MAP: Record<AvatarVideoState, string> = {
  IDLE: '/assets/images/c2_idle_pose_1790010645871.jpg',
  THINKING: '/assets/images/c2_thinking_pose_1790010670135.jpg',
  TALKING: '/assets/images/c2_talking_pose_1790010694981.jpg',
  UPSET: '/assets/images/c2_upset_pose_1790010709454.jpg',
  PERSONAL_BOUNDARY: '/assets/images/c2_boundary_pose_1790010727932.jpg',
};

interface AvatarVideoPlayerProps {
  theme?: string;
  onOpenSettings?: () => void;
  className?: string;
}

export const AvatarVideoPlayer: React.FC<AvatarVideoPlayerProps> = ({
  onOpenSettings,
  className = '',
}) => {
  const containerRef = useRef<HTMLDivElement | null>(null);

  // Video element refs for smooth cross-buffering
  const videoA_Ref = useRef<HTMLVideoElement | null>(null);
  const videoB_Ref = useRef<HTMLVideoElement | null>(null);

  // Active buffer tracking ('A' or 'B')
  const [activeBuffer, setActiveBuffer] = useState<'A' | 'B'>('A');

  // State machine values
  const [currentState, setCurrentState] = useState<AvatarVideoState>('IDLE');
  const [config, setConfig] = useState<AvatarConfig>(avatarVideoStateManager.getConfig());
  const [touchZones, setTouchZones] = useState<TouchZone[]>(avatarVideoStateManager.getTouchZones());

  // Error & loading diagnostics
  const [assetError, setAssetError] = useState<{ state: AvatarVideoState; message: string } | null>(null);
  const [touchToast, setTouchToast] = useState<string | null>(null);
  const toastTimerRef = useRef<number | null>(null);

  // Buffer sources & playback states
  const [bufferA_Src, setBufferA_Src] = useState<string>(VIDEO_ASSET_MAP.IDLE.primaryUrl);
  const [bufferB_Src, setBufferB_Src] = useState<string>(VIDEO_ASSET_MAP.IDLE.primaryUrl);
  const [bufferA_Loop, setBufferA_Loop] = useState<boolean>(true);
  const [bufferB_Loop, setBufferB_Loop] = useState<boolean>(true);
  const [bufferA_Loaded, setBufferA_Loaded] = useState<boolean>(false);
  const [bufferB_Loaded, setBufferB_Loaded] = useState<boolean>(false);

  // Track user interaction for autoplay unlocks in sandboxed iframes
  const hasUserInteractedRef = useRef<boolean>(false);
  const pendingBufferRef = useRef<'A' | 'B' | null>(null);
  const lastTargetStateRef = useRef<AvatarVideoState>('IDLE');

  /**
   * Enforce permanent muting on all video elements as per mandatory audio rules
   */
  const enforcePermanentMute = (videoEl: HTMLVideoElement | null) => {
    if (!videoEl) return;
    videoEl.muted = true;
    videoEl.defaultMuted = true;
    videoEl.volume = 0;
    try {
      videoEl.setAttribute('muted', '');
      videoEl.setAttribute('playsinline', '');
      videoEl.setAttribute('webkit-playsinline', '');
    } catch (_) {}
  };

  // Video element ref callbacks that ensure muted is set before insertion into DOM
  const setVideoRefA = useCallback((el: HTMLVideoElement | null) => {
    videoA_Ref.current = el;
    enforcePermanentMute(el);
  }, []);

  const setVideoRefB = useCallback((el: HTMLVideoElement | null) => {
    videoB_Ref.current = el;
    enforcePermanentMute(el);
  }, []);

  // Subscribe to AvatarVideoStateManager changes
  useEffect(() => {
    const unsub = avatarVideoStateManager.subscribe((state, info) => {
      setCurrentState(state);
      setConfig(avatarVideoStateManager.getConfig());
      setTouchZones(avatarVideoStateManager.getTouchZones());

      if (info.reason.startsWith('touched_zone_') && info.activeZone) {
        showTouchFeedback(`Personal Boundary: ${info.activeZone.name}`);
      }
    });

    return () => {
      unsub();
    };
  }, []);

  // Global user gesture listener to unlock any blocked iframe autoplay
  useEffect(() => {
    const handleFirstGesture = () => {
      hasUserInteractedRef.current = true;
      const activeVideo = activeBuffer === 'A' ? videoA_Ref.current : videoB_Ref.current;
      if (activeVideo && activeVideo.paused) {
        enforcePermanentMute(activeVideo);
        activeVideo.play().catch(() => {});
      }
    };

    window.addEventListener('pointerdown', handleFirstGesture, { passive: true });
    window.addEventListener('touchstart', handleFirstGesture, { passive: true });
    window.addEventListener('keydown', handleFirstGesture, { passive: true });

    return () => {
      window.removeEventListener('pointerdown', handleFirstGesture);
      window.removeEventListener('touchstart', handleFirstGesture);
      window.removeEventListener('keydown', handleFirstGesture);
    };
  }, [activeBuffer]);

  const showTouchFeedback = (msg: string) => {
    setTouchToast(msg);
    if (toastTimerRef.current) clearTimeout(toastTimerRef.current);
    toastTimerRef.current = window.setTimeout(() => setTouchToast(null), 2500);
  };

  /**
   * Handle state transitions and switch active video buffer smoothly
   */
  useEffect(() => {
    if (lastTargetStateRef.current === currentState && (bufferA_Loaded || bufferB_Loaded)) {
      return;
    }
    lastTargetStateRef.current = currentState;

    const asset = VIDEO_ASSET_MAP[currentState] || VIDEO_ASSET_MAP.IDLE;
    const targetUrl = asset.primaryUrl;
    const targetLoop = asset.loop;

    // Switch to the OTHER buffer so the current buffer keeps playing until new video is ready
    const nextBuffer: 'A' | 'B' = activeBuffer === 'A' ? 'B' : 'A';
    pendingBufferRef.current = nextBuffer;

    if (nextBuffer === 'A') {
      setBufferA_Loaded(false);
      setBufferA_Loop(targetLoop);
      setBufferA_Src(targetUrl);
    } else {
      setBufferB_Loaded(false);
      setBufferB_Loop(targetLoop);
      setBufferB_Src(targetUrl);
    }
  }, [currentState, activeBuffer, bufferA_Loaded, bufferB_Loaded]);

  /**
   * Called when a buffer's video is ready to play (canplay / loadeddata)
   */
  const handleCanPlay = (buffer: 'A' | 'B') => {
    const videoEl = buffer === 'A' ? videoA_Ref.current : videoB_Ref.current;
    const prevVideoEl = buffer === 'A' ? videoB_Ref.current : videoA_Ref.current;

    if (buffer === 'A') setBufferA_Loaded(true);
    else setBufferB_Loaded(true);

    if (videoEl && pendingBufferRef.current === buffer) {
      enforcePermanentMute(videoEl);
      const playPromise = videoEl.play();

      const activateBuffer = () => {
        enforcePermanentMute(videoEl);
        setActiveBuffer(buffer);
        pendingBufferRef.current = null;
        setAssetError(null);

        // Pause previous buffer after cross-fade starts
        if (prevVideoEl && prevVideoEl !== videoEl) {
          setTimeout(() => {
            try {
              prevVideoEl.pause();
            } catch (_) {}
          }, 250);
        }
      };

      if (playPromise !== undefined) {
        playPromise
          .then(activateBuffer)
          .catch((err) => {
            // Autoplay was blocked by iframe policy before user gesture
            console.log('[AVATAR] Autoplay waiting for user gesture:', err.name);
            // Still switch visually to the buffer so the poster or frame is visible
            activateBuffer();
          });
      } else {
        activateBuffer();
      }
    }
  };

  /**
   * Handle video playback completion for non-looping temporary states
   */
  const handleVideoEnded = (buffer: 'A' | 'B') => {
    if (buffer !== activeBuffer) return;

    if (currentState === 'PERSONAL_BOUNDARY' || currentState === 'UPSET') {
      avatarVideoStateManager.resetToIdle();
    }
  };

  /**
   * Handle video element error gracefully
   */
  const handleVideoError = (buffer: 'A' | 'B') => {
    const asset = VIDEO_ASSET_MAP[currentState];
    console.warn(`[AVATAR] Video element load notice for ${asset?.filename}`);

    // If a temporary reaction state video fails to load, fallback to IDLE safely
    if (currentState !== 'IDLE') {
      setAssetError({
        state: currentState,
        message: `Animation '${asset?.title}' temporarily displaying pose fallback.`,
      });
      avatarVideoStateManager.resetToIdle();
    }
  };

  // State badge aesthetic details
  const getBadgeDetails = () => {
    switch (currentState) {
      case 'TALKING':
        return { text: 'Speaking', color: 'bg-emerald-500/20 text-emerald-300 border-emerald-500/30' };
      case 'THINKING':
        return { text: 'Thinking...', color: 'bg-amber-500/20 text-amber-300 border-amber-500/30' };
      case 'UPSET':
        return { text: 'Upset', color: 'bg-rose-500/20 text-rose-300 border-rose-500/30' };
      case 'PERSONAL_BOUNDARY':
        return { text: 'Personal Space', color: 'bg-purple-500/20 text-purple-300 border-purple-500/30' };
      case 'IDLE':
      default:
        return { text: 'Active', color: 'bg-cyan-500/20 text-cyan-300 border-cyan-500/30' };
    }
  };

  const badge = getBadgeDetails();
  const currentFallbackImage = FALLBACK_IMAGE_MAP[currentState] || FALLBACK_IMAGE_MAP.IDLE;

  return (
    <div
      ref={containerRef}
      className={`relative w-full max-w-[340px] sm:max-w-[380px] aspect-[9/16] max-h-[520px] mx-auto rounded-3xl overflow-hidden bg-slate-950/80 border border-white/15 shadow-2xl backdrop-blur-xl flex items-center justify-center select-none ${className}`}
      style={{
        boxShadow:
          currentState === 'PERSONAL_BOUNDARY'
            ? '0 0 35px rgba(168, 85, 247, 0.4), inset 0 0 20px rgba(168, 85, 247, 0.2)'
            : currentState === 'UPSET'
            ? '0 0 35px rgba(244, 63, 94, 0.4), inset 0 0 20px rgba(244, 63, 94, 0.2)'
            : currentState === 'TALKING'
            ? '0 0 35px rgba(52, 211, 153, 0.3), inset 0 0 15px rgba(52, 211, 153, 0.15)'
            : currentState === 'THINKING'
            ? '0 0 30px rgba(251, 191, 36, 0.35), inset 0 0 15px rgba(251, 191, 36, 0.15)'
            : '0 0 25px rgba(56, 189, 248, 0.2), inset 0 0 15px rgba(56, 189, 248, 0.1)',
        transition: 'box-shadow 0.4s ease-in-out',
      }}
    >
      {/* Background ambient lighting pulse */}
      <div
        className="absolute inset-0 pointer-events-none opacity-40 transition-colors duration-500"
        style={{
          background:
            currentState === 'PERSONAL_BOUNDARY'
              ? 'radial-gradient(circle at 50% 45%, rgba(147, 51, 234, 0.35) 0%, transparent 70%)'
              : currentState === 'UPSET'
              ? 'radial-gradient(circle at 50% 45%, rgba(225, 29, 72, 0.35) 0%, transparent 70%)'
              : currentState === 'TALKING'
              ? 'radial-gradient(circle at 50% 45%, rgba(16, 185, 129, 0.3) 0%, transparent 70%)'
              : currentState === 'THINKING'
              ? 'radial-gradient(circle at 50% 45%, rgba(245, 158, 11, 0.3) 0%, transparent 70%)'
              : 'radial-gradient(circle at 50% 45%, rgba(14, 165, 233, 0.25) 0%, transparent 70%)',
        }}
      />

      {/* Instant High-Resolution Character Poster Fallback (Prevents any black-frame flicker) */}
      <img
        src={currentFallbackImage}
        alt="C2 Character"
        className="absolute inset-0 w-full h-full object-contain pointer-events-none transition-opacity duration-500 opacity-60"
        loading="eager"
      />

      {/* Double-Buffered Video Element A */}
      <video
        ref={setVideoRefA}
        src={bufferA_Src}
        loop={bufferA_Loop}
        muted
        playsInline
        onCanPlay={() => handleCanPlay('A')}
        onEnded={() => handleVideoEnded('A')}
        onError={() => handleVideoError('A')}
        className={`absolute inset-0 w-full h-full object-contain pointer-events-none transition-opacity duration-300 ${
          activeBuffer === 'A' ? 'opacity-100 z-10' : 'opacity-0 z-0'
        }`}
        aria-hidden={activeBuffer !== 'A'}
      />

      {/* Double-Buffered Video Element B */}
      <video
        ref={setVideoRefB}
        src={bufferB_Src}
        loop={bufferB_Loop}
        muted
        playsInline
        onCanPlay={() => handleCanPlay('B')}
        onEnded={() => handleVideoEnded('B')}
        onError={() => handleVideoError('B')}
        className={`absolute inset-0 w-full h-full object-contain pointer-events-none transition-opacity duration-300 ${
          activeBuffer === 'B' ? 'opacity-100 z-10' : 'opacity-0 z-0'
        }`}
        aria-hidden={activeBuffer !== 'B'}
      />

      {/* High-Precision Transparent Touch & Boundary Interaction Overlay */}
      <AvatarTouchLayer
        containerRef={containerRef}
        zones={touchZones}
        debug={config.debugTouchZones}
      />

      {/* Top Status & Mode HUD */}
      <div className="absolute top-3 left-3 right-3 z-30 flex items-center justify-between pointer-events-none">
        <div className="flex items-center gap-1.5">
          <span
            className={`px-2.5 py-1 rounded-full text-[10px] font-mono tracking-wider border backdrop-blur-md transition-all shadow-sm ${badge.color}`}
          >
            ● {badge.text}
          </span>

          {config.debugTouchZones && (
            <span className="px-2 py-0.5 rounded-full text-[9px] font-mono bg-red-500/20 text-red-300 border border-red-500/30 backdrop-blur-md">
              TOUCH DEBUG
            </span>
          )}
        </div>

        {onOpenSettings && (
          <button
            onClick={onOpenSettings}
            className="pointer-events-auto p-1.5 rounded-full bg-black/40 hover:bg-black/60 text-slate-300 hover:text-white border border-white/10 backdrop-blur-md transition-colors text-xs cursor-pointer"
            title="Configure Avatar & Personal Boundary Zones"
          >
            ⚙
          </button>
        )}
      </div>

      {/* Interactive Boundary Touch Feedback Toast */}
      {touchToast && (
        <div className="absolute bottom-4 left-4 right-4 z-40 p-2.5 rounded-xl bg-purple-950/80 border border-purple-400/40 backdrop-blur-xl text-center text-xs text-purple-200 font-medium shadow-xl animate-in fade-in slide-in-from-bottom-2 pointer-events-none">
          <span className="flex items-center justify-center gap-1.5">
            <Sparkles className="w-3.5 h-3.5 text-purple-400" />
            {touchToast}
          </span>
        </div>
      )}

      {/* Graceful Asset Error Notice Banner */}
      {assetError && (
        <div className="absolute top-12 left-3 right-3 z-40 p-2 rounded-lg bg-amber-950/80 border border-amber-500/40 text-[11px] text-amber-200 backdrop-blur-md flex items-center justify-between gap-2 shadow-lg animate-in fade-in">
          <div className="flex items-center gap-1.5 truncate">
            <AlertCircle className="w-3.5 h-3.5 text-amber-400 shrink-0" />
            <span className="truncate">{assetError.message}</span>
          </div>
          <button
            onClick={() => setAssetError(null)}
            className="text-amber-400 hover:text-white text-xs px-1 cursor-pointer"
          >
            ✕
          </button>
        </div>
      )}
    </div>
  );
};
