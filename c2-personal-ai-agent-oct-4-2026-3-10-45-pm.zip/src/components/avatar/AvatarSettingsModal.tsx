/**
 * AvatarSettingsModal
 * 
 * Interactive control panel for C2 Avatar System:
 * - Real-time normalized touch zone editor (Chest, Hip, Gluteal)
 * - Developer Touch Zone Debug Mode Toggle
 * - Upset sensitivity & duration controls
 * - Touch cooldown settings
 * - Asset verification telemetry & custom video upload dropzone
 */

import React, { useState, useEffect } from 'react';
import {
  AvatarConfig,
  TouchZone,
  VIDEO_ASSET_MAP,
  AvatarVideoState,
} from '../../modules/avatar/types';
import { avatarVideoStateManager } from '../../modules/avatar/AvatarVideoStateManager';
import {
  Sliders,
  Shield,
  Eye,
  CheckCircle2,
  AlertTriangle,
  Upload,
  RotateCcw,
  X,
  Sparkles,
} from 'lucide-react';

interface AvatarSettingsModalProps {
  isOpen: boolean;
  onClose: () => void;
}

export const AvatarSettingsModal: React.FC<AvatarSettingsModalProps> = ({
  isOpen,
  onClose,
}) => {
  const [config, setConfig] = useState<AvatarConfig>(avatarVideoStateManager.getConfig());
  const [zones, setZones] = useState<TouchZone[]>(avatarVideoStateManager.getTouchZones());
  const [activeTab, setActiveTab] = useState<'zones' | 'behavior' | 'assets'>('zones');
  const [assetStatus, setAssetStatus] = useState<{
    loading: boolean;
    allPresent: boolean;
    videos: { name: string; exists: boolean; size: number }[];
  }>({ loading: true, allPresent: false, videos: [] });
  const [uploadMsg, setUploadMsg] = useState<string | null>(null);

  useEffect(() => {
    if (isOpen) {
      setConfig(avatarVideoStateManager.getConfig());
      setZones(avatarVideoStateManager.getTouchZones());
      fetchAssetStatus();
    }
  }, [isOpen]);

  const fetchAssetStatus = async () => {
    try {
      const res = await fetch('/api/avatar/status');
      if (res.ok) {
        const data = await res.json();
        setAssetStatus({
          loading: false,
          allPresent: data.allPresent,
          videos: data.videos || [],
        });
      }
    } catch (_) {
      setAssetStatus({ loading: false, allPresent: false, videos: [] });
    }
  };

  if (!isOpen) return null;

  const handleZoneChange = (id: string, updates: Partial<TouchZone>) => {
    const updated = zones.map((z) => (z.id === id ? { ...z, ...updates } : z));
    setZones(updated);
    avatarVideoStateManager.setTouchZones(updated);
  };

  const handleConfigChange = (updates: Partial<AvatarConfig>) => {
    const updated = { ...config, ...updates };
    setConfig(updated);
    avatarVideoStateManager.updateConfig(updated);
  };

  const handleResetZones = () => {
    avatarVideoStateManager.resetTouchZonesToDefault();
    setZones(avatarVideoStateManager.getTouchZones());
  };

  const handleFileUpload = async (stateKey: AvatarVideoState, file: File) => {
    const asset = VIDEO_ASSET_MAP[stateKey];
    setUploadMsg(`Uploading ${file.name} for ${asset.title}...`);
    try {
      const res = await fetch(`/api/avatar/upload?filename=${encodeURIComponent(asset.filename)}`, {
        method: 'POST',
        headers: { 'Content-Type': 'video/mp4' },
        body: file,
      });

      if (res.ok) {
        setUploadMsg(`Successfully updated ${asset.filename}! Reloading asset...`);
        fetchAssetStatus();
        setTimeout(() => setUploadMsg(null), 3000);
      } else {
        setUploadMsg(`Failed to upload ${file.name}. Check file size and format.`);
      }
    } catch (err: any) {
      setUploadMsg(`Upload error: ${err.message}`);
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/75 backdrop-blur-md animate-in fade-in">
      <div className="w-full max-w-xl max-h-[90vh] bg-slate-900/95 border border-white/15 rounded-3xl shadow-2xl flex flex-col overflow-hidden text-slate-200">
        {/* Header */}
        <div className="p-4 border-b border-white/10 flex items-center justify-between">
          <div className="flex items-center gap-2.5">
            <div className="w-8 h-8 rounded-xl bg-purple-500/20 border border-purple-400/40 flex items-center justify-center text-purple-300">
              <Sliders className="w-4 h-4" />
            </div>
            <div>
              <h2 className="text-sm font-semibold text-white">Avatar & Boundary Settings</h2>
              <p className="text-[11px] text-slate-400">Configure personal zones, timings, and video assets</p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-1.5 rounded-lg hover:bg-white/10 text-slate-400 hover:text-white transition-colors"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        {/* Tab Navigation */}
        <div className="flex border-b border-white/10 bg-white/[0.02] text-xs font-medium">
          <button
            onClick={() => setActiveTab('zones')}
            className={`flex-1 py-2.5 text-center border-b-2 transition-colors flex items-center justify-center gap-1.5 ${
              activeTab === 'zones'
                ? 'border-purple-400 text-purple-300 bg-purple-500/10'
                : 'border-transparent text-slate-400 hover:text-slate-200'
            }`}
          >
            <Shield className="w-3.5 h-3.5" />
            Touch Zones ({zones.filter((z) => z.enabled).length}/3)
          </button>
          <button
            onClick={() => setActiveTab('behavior')}
            className={`flex-1 py-2.5 text-center border-b-2 transition-colors flex items-center justify-center gap-1.5 ${
              activeTab === 'behavior'
                ? 'border-purple-400 text-purple-300 bg-purple-500/10'
                : 'border-transparent text-slate-400 hover:text-slate-200'
            }`}
          >
            <Sliders className="w-3.5 h-3.5" />
            Reaction Timing
          </button>
          <button
            onClick={() => setActiveTab('assets')}
            className={`flex-1 py-2.5 text-center border-b-2 transition-colors flex items-center justify-center gap-1.5 ${
              activeTab === 'assets'
                ? 'border-purple-400 text-purple-300 bg-purple-500/10'
                : 'border-transparent text-slate-400 hover:text-slate-200'
            }`}
          >
            <Eye className="w-3.5 h-3.5" />
            Video Assets ({assetStatus.videos.filter((v) => v.exists).length}/5)
          </button>
        </div>

        {/* Body Content */}
        <div className="flex-1 overflow-y-auto p-4 space-y-4 text-xs">
          {/* TAB 1: TOUCH ZONES */}
          {activeTab === 'zones' && (
            <div className="space-y-4">
              {/* Debug Toggle Card */}
              <div className="p-3 rounded-2xl bg-white/[0.04] border border-white/10 flex items-center justify-between">
                <div>
                  <div className="font-medium text-white flex items-center gap-1.5">
                    <Eye className="w-3.5 h-3.5 text-cyan-400" />
                    Developer Touch Zone Overlay
                  </div>
                  <div className="text-[11px] text-slate-400 mt-0.5">
                    Visually displays the touch zone boundaries and coordinates over C2
                  </div>
                </div>
                <label className="relative inline-flex items-center cursor-pointer">
                  <input
                    type="checkbox"
                    checked={config.debugTouchZones}
                    onChange={(e) => handleConfigChange({ debugTouchZones: e.target.checked })}
                    className="sr-only peer"
                  />
                  <div className="w-9 h-5 bg-slate-700 peer-focus:outline-none rounded-full peer peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:border-gray-300 after:border after:rounded-full after:h-4 after:w-4 after:transition-all peer-checked:bg-purple-600"></div>
                </label>
              </div>

              {/* Zone List */}
              <div className="space-y-3">
                {zones.map((zone) => (
                  <div
                    key={zone.id}
                    className={`p-3.5 rounded-2xl border transition-all ${
                      zone.enabled
                        ? 'bg-purple-950/20 border-purple-500/30'
                        : 'bg-white/[0.02] border-white/5 opacity-60'
                    }`}
                  >
                    <div className="flex items-center justify-between mb-2">
                      <div className="flex items-center gap-2">
                        <input
                          type="checkbox"
                          checked={zone.enabled}
                          onChange={(e) => handleZoneChange(zone.id, { enabled: e.target.checked })}
                          className="rounded border-slate-700 text-purple-600 focus:ring-purple-500 w-4 h-4 cursor-pointer"
                        />
                        <span className="font-semibold text-white">{zone.name}</span>
                      </div>
                      <span className="text-[10px] font-mono text-purple-300 bg-purple-500/10 px-2 py-0.5 rounded">
                        id: {zone.id}
                      </span>
                    </div>

                    <p className="text-[11px] text-slate-400 mb-3">{zone.description}</p>

                    {/* Coordinate Sliders */}
                    <div className="grid grid-cols-2 gap-3 text-[11px] font-mono">
                      <div>
                        <div className="flex justify-between text-slate-400 mb-1">
                          <span>X (Horizontal):</span>
                          <span className="text-white">{zone.x.toFixed(2)}</span>
                        </div>
                        <input
                          type="range"
                          min="0"
                          max="0.8"
                          step="0.02"
                          value={zone.x}
                          disabled={!zone.enabled}
                          onChange={(e) => handleZoneChange(zone.id, { x: parseFloat(e.target.value) })}
                          className="w-full accent-purple-500 cursor-pointer"
                        />
                      </div>

                      <div>
                        <div className="flex justify-between text-slate-400 mb-1">
                          <span>Y (Vertical):</span>
                          <span className="text-white">{zone.y.toFixed(2)}</span>
                        </div>
                        <input
                          type="range"
                          min="0"
                          max="0.8"
                          step="0.02"
                          value={zone.y}
                          disabled={!zone.enabled}
                          onChange={(e) => handleZoneChange(zone.id, { y: parseFloat(e.target.value) })}
                          className="w-full accent-purple-500 cursor-pointer"
                        />
                      </div>

                      <div>
                        <div className="flex justify-between text-slate-400 mb-1">
                          <span>Width:</span>
                          <span className="text-white">{zone.width.toFixed(2)}</span>
                        </div>
                        <input
                          type="range"
                          min="0.1"
                          max="0.8"
                          step="0.02"
                          value={zone.width}
                          disabled={!zone.enabled}
                          onChange={(e) =>
                            handleZoneChange(zone.id, { width: parseFloat(e.target.value) })
                          }
                          className="w-full accent-purple-500 cursor-pointer"
                        />
                      </div>

                      <div>
                        <div className="flex justify-between text-slate-400 mb-1">
                          <span>Height:</span>
                          <span className="text-white">{zone.height.toFixed(2)}</span>
                        </div>
                        <input
                          type="range"
                          min="0.1"
                          max="0.6"
                          step="0.02"
                          value={zone.height}
                          disabled={!zone.enabled}
                          onChange={(e) =>
                            handleZoneChange(zone.id, { height: parseFloat(e.target.value) })
                          }
                          className="w-full accent-purple-500 cursor-pointer"
                        />
                      </div>
                    </div>
                  </div>
                ))}
              </div>

              <button
                onClick={handleResetZones}
                className="w-full py-2 px-3 rounded-xl bg-white/5 hover:bg-white/10 text-slate-300 text-[11px] flex items-center justify-center gap-1.5 transition-colors"
              >
                <RotateCcw className="w-3.5 h-3.5" />
                Reset Normalized Zones to Factory Default
              </button>
            </div>
          )}

          {/* TAB 2: REACTION TIMING & BEHAVIOR */}
          {activeTab === 'behavior' && (
            <div className="space-y-4">
              <div className="p-3.5 rounded-2xl bg-white/[0.03] border border-white/10 space-y-3">
                <div className="font-semibold text-white">Touch Cooldown Timing</div>
                <div className="text-[11px] text-slate-400">
                  Prevents repetitive triggers when a finger is held or tapped repeatedly on personal zones.
                </div>
                <div className="flex items-center gap-3">
                  <input
                    type="range"
                    min="1000"
                    max="5000"
                    step="250"
                    value={config.touchCooldownMs}
                    onChange={(e) =>
                      handleConfigChange({ touchCooldownMs: parseInt(e.target.value, 10) })
                    }
                    className="flex-1 accent-purple-500"
                  />
                  <span className="font-mono text-white text-xs min-w-[65px] text-right">
                    {(config.touchCooldownMs / 1000).toFixed(1)}s
                  </span>
                </div>
              </div>

              <div className="p-3.5 rounded-2xl bg-white/[0.03] border border-white/10 space-y-3">
                <div className="font-semibold text-white">Upset Reaction Sensitivity & Duration</div>
                <div className="text-[11px] text-slate-400">
                  Activates upset.mp4 when clearly abusive language is detected. Normal corrections and bug reports are protected from triggering it.
                </div>

                <div className="space-y-3 pt-1">
                  <div>
                    <div className="flex justify-between text-slate-300 mb-1">
                      <span>Abuse Trigger Threshold:</span>
                      <span className="font-mono text-white">
                        {(config.upsetTriggerThreshold * 100).toFixed(0)}%
                      </span>
                    </div>
                    <input
                      type="range"
                      min="0.5"
                      max="0.95"
                      step="0.05"
                      value={config.upsetTriggerThreshold}
                      onChange={(e) =>
                        handleConfigChange({ upsetTriggerThreshold: parseFloat(e.target.value) })
                      }
                      className="w-full accent-rose-500"
                    />
                  </div>

                  <div>
                    <div className="flex justify-between text-slate-300 mb-1">
                      <span>Upset Video Duration:</span>
                      <span className="font-mono text-white">
                        {(config.upsetDisplayDurationMs / 1000).toFixed(1)}s
                      </span>
                    </div>
                    <input
                      type="range"
                      min="2000"
                      max="7000"
                      step="500"
                      value={config.upsetDisplayDurationMs}
                      onChange={(e) =>
                        handleConfigChange({ upsetDisplayDurationMs: parseInt(e.target.value, 10) })
                      }
                      className="w-full accent-rose-500"
                    />
                  </div>
                </div>
              </div>

              <div className="p-3.5 rounded-2xl bg-white/[0.03] border border-white/10 space-y-3">
                <div className="font-semibold text-white">Audio Synchronization Rule</div>
                <div className="text-[11px] text-emerald-300/90 leading-relaxed">
                  ✓ <strong>Permanent Video Muting Active:</strong> In strict adherence to C2 audio architecture, all character animation videos are permanently muted at the video player level. Only the Gemini / TTS voice engine produces speech audio.
                </div>
              </div>
            </div>
          )}

          {/* TAB 3: VIDEO ASSETS */}
          {activeTab === 'assets' && (
            <div className="space-y-3">
              <div className="p-3 rounded-2xl bg-white/[0.03] border border-white/10 text-[11px] text-slate-300">
                All five character animations are registered and served at standard URL paths. You can also replace any video with your own local file using the upload action.
              </div>

              {uploadMsg && (
                <div className="p-2.5 rounded-xl bg-purple-950/80 border border-purple-500/40 text-purple-200 text-center font-medium animate-in fade-in">
                  {uploadMsg}
                </div>
              )}

              <div className="space-y-2">
                {(Object.keys(VIDEO_ASSET_MAP) as AvatarVideoState[]).map((stateKey) => {
                  const asset = VIDEO_ASSET_MAP[stateKey];
                  const stat = assetStatus.videos.find((v) => v.name === asset.filename);
                  const isReady = stat?.exists && stat.size > 0;

                  return (
                    <div
                      key={stateKey}
                      className="p-3 rounded-2xl bg-white/[0.03] border border-white/10 flex items-center justify-between gap-3"
                    >
                      <div className="flex-1 min-w-0">
                        <div className="flex items-center gap-1.5 font-medium text-white truncate">
                          {isReady ? (
                            <CheckCircle2 className="w-3.5 h-3.5 text-emerald-400 shrink-0" />
                          ) : (
                            <AlertTriangle className="w-3.5 h-3.5 text-amber-400 shrink-0" />
                          )}
                          <span className="truncate">{asset.title}</span>
                        </div>
                        <div className="text-[10px] font-mono text-slate-400 truncate mt-0.5">
                          {asset.filename} ({stat?.size ? `${Math.round(stat.size / 1024)} KB` : 'not loaded'})
                        </div>
                      </div>

                      <label className="px-2.5 py-1.5 rounded-lg bg-white/10 hover:bg-white/15 text-slate-200 text-[11px] flex items-center gap-1 cursor-pointer transition-colors shrink-0">
                        <Upload className="w-3 h-3" />
                        Replace
                        <input
                          type="file"
                          accept="video/mp4"
                          className="hidden"
                          onChange={(e) => {
                            const file = e.target.files?.[0];
                            if (file) handleFileUpload(stateKey, file);
                          }}
                        />
                      </label>
                    </div>
                  );
                })}
              </div>
            </div>
          )}
        </div>

        {/* Footer */}
        <div className="p-4 border-t border-white/10 bg-slate-950/60 flex items-center justify-between">
          <span className="text-[11px] text-slate-400 font-mono">
            State: <strong>{avatarVideoStateManager.getState()}</strong>
          </span>
          <button
            onClick={onClose}
            className="px-4 py-1.5 rounded-xl bg-purple-600 hover:bg-purple-500 text-white font-medium text-xs transition-colors cursor-pointer"
          >
            Save & Close
          </button>
        </div>
      </div>
    </div>
  );
};
