import React, { useEffect, useState } from 'react';
import { gptSoVITSProvider } from '../services/GPTSoVITSProvider';
import { GPTSoVITSStatus } from '../config/voiceConfig';
import { Volume2, RefreshCw, CheckCircle2, AlertCircle, Radio, Settings2, X } from 'lucide-react';

interface VoiceEngineStatusProps {
  className?: string;
  variant?: 'compact' | 'full';
}

export const VoiceEngineStatus: React.FC<VoiceEngineStatusProps> = ({
  className = '',
  variant = 'compact',
}) => {
  const [status, setStatus] = useState<GPTSoVITSStatus>(gptSoVITSProvider.getStatus());
  const [isPopoverOpen, setIsPopoverOpen] = useState(false);
  const [endpointInput, setEndpointInput] = useState(gptSoVITSProvider.getEndpointUrl());
  const [isTesting, setIsTesting] = useState(false);
  const [testResult, setTestResult] = useState<string | null>(null);
  const [latency, setLatency] = useState(gptSoVITSProvider.getLastLatency());

  useEffect(() => {
    const unsubscribe = gptSoVITSProvider.onStatusChange((newStatus) => {
      setStatus(newStatus);
      setLatency(gptSoVITSProvider.getLastLatency());
      setEndpointInput(gptSoVITSProvider.getEndpointUrl());
    });
    return () => unsubscribe();
  }, []);

  const getStatusBadge = () => {
    switch (status) {
      case 'GPT-SOVITS READY':
        return {
          label: 'GPT-SoVITS: READY',
          badgeClass: 'bg-emerald-50 text-emerald-700 border-emerald-300 hover:bg-emerald-100',
          dotClass: 'bg-emerald-500',
          pulse: false,
        };
      case 'GPT-SOVITS SPEAKING':
        return {
          label: 'GPT-SoVITS: SPEAKING',
          badgeClass: 'bg-indigo-50 text-indigo-700 border-indigo-300 hover:bg-indigo-100',
          dotClass: 'bg-indigo-500 animate-pulse',
          pulse: true,
        };
      case 'GPT-SOVITS GENERATING':
        return {
          label: 'GPT-SoVITS: GENERATING',
          badgeClass: 'bg-amber-50 text-amber-700 border-amber-300 hover:bg-amber-100',
          dotClass: 'bg-amber-500 animate-ping',
          pulse: true,
        };
      case 'GPT-SOVITS CONNECTING':
        return {
          label: 'GPT-SoVITS: CONNECTING',
          badgeClass: 'bg-sky-50 text-sky-700 border-sky-300 hover:bg-sky-100',
          dotClass: 'bg-sky-500 animate-spin',
          pulse: true,
        };
      case 'GPT-SOVITS OFFLINE':
        return {
          label: 'GPT-SoVITS: OFFLINE',
          badgeClass: 'bg-slate-100 text-slate-700 border-slate-300 hover:bg-slate-200',
          dotClass: 'bg-rose-400',
          pulse: false,
        };
      case 'GPT-SOVITS NOT CONFIGURED':
      default:
        return {
          label: 'GPT-SoVITS: NOT CONFIGURED',
          badgeClass: 'bg-slate-100 text-slate-600 border-slate-200 hover:bg-slate-200',
          dotClass: 'bg-slate-400',
          pulse: false,
        };
    }
  };

  const badgeInfo = getStatusBadge();

  const handleTestConnection = async () => {
    const target = endpointInput.trim();
    if (!target) {
      await gptSoVITSProvider.updateEndpoint('');
      setTestResult('GPT-SoVITS is dormant (not configured).');
      return;
    }
    setIsTesting(true);
    setTestResult(null);
    try {
      const ok = await gptSoVITSProvider.updateEndpoint(target);
      if (ok) {
        setTestResult(`Connected! Status: READY (${gptSoVITSProvider.getLastLatency()}ms)`);
      } else {
        setTestResult('Server unreachable at this URL. Keeping dormant.');
      }
    } catch (e: any) {
      setTestResult(`Connection failed: ${e?.message || 'Check URL'}`);
    } finally {
      setIsTesting(false);
    }
  };

  const handleTestSpeech = async () => {
    if (status !== 'GPT-SOVITS READY') {
      setTestResult('GPT-SoVITS is not configured or connected. Connect a real server first.');
      return;
    }
    setIsTesting(true);
    setTestResult('Generating sample voice...');
    try {
      const audio = await gptSoVITSProvider.generateSpeech(
        'Hello! I am C2, your personal AI assistant. Voice architecture is ready.'
      );
      if (audio) {
        setTestResult(`Generated ${audio.byteLength} bytes of audio. Voice online!`);
      } else {
        setTestResult('TTS synthesis returned no audio. Check server logs.');
      }
    } catch (e: any) {
      setTestResult(`Error: ${e?.message}`);
    } finally {
      setIsTesting(false);
    }
  };

  return (
    <div className={`relative inline-block ${className}`}>
      {/* Clickable Badge */}
      <button
        id="c2-voice-engine-status-badge"
        onClick={() => setIsPopoverOpen(!isPopoverOpen)}
        className={`flex items-center gap-1.5 px-2.5 py-1 rounded-md border text-[11px] font-medium transition-colors cursor-pointer select-none ${badgeInfo.badgeClass}`}
        title="Click to view Voice Architecture info"
      >
        <span className={`w-1.5 h-1.5 rounded-full ${badgeInfo.dotClass}`} />
        <span className="font-mono">{badgeInfo.label}</span>
      </button>

      {/* Popover */}
      {isPopoverOpen && (
        <div className="absolute right-0 mt-2 w-80 sm:w-96 bg-white border border-slate-200 rounded-xl shadow-xl z-50 p-4 text-xs animate-in fade-in zoom-in-95 duration-150">
          <div className="flex items-center justify-between pb-2 border-b border-slate-100 mb-3">
            <div className="flex items-center gap-2">
              <Volume2 className="w-4 h-4 text-indigo-600" />
              <span className="font-semibold text-slate-800 text-sm">GPT-SoVITS Architecture</span>
            </div>
            <button
              onClick={() => setIsPopoverOpen(false)}
              className="p-1 text-slate-400 hover:text-slate-600 rounded-md"
            >
              <X className="w-4 h-4" />
            </button>
          </div>

          <div className="space-y-3">
            <div className="bg-slate-50 p-2.5 rounded-lg border border-slate-200 space-y-1">
              <div className="flex justify-between">
                <span className="text-slate-500 font-medium">Status:</span>
                <span className="font-mono font-semibold text-slate-800">{badgeInfo.label}</span>
              </div>
              <div className="flex justify-between">
                <span className="text-slate-500 font-medium">Euphemiya Reference:</span>
                <span className="font-mono text-emerald-600 font-medium">Preserved (32kHz WAV)</span>
              </div>
              <div className="flex justify-between">
                <span className="text-slate-500 font-medium">C2 Brain & Mic:</span>
                <span className="text-emerald-700 font-medium">Active (Gemini Live)</span>
              </div>
              {latency > 0 && status === 'GPT-SOVITS READY' && (
                <div className="flex justify-between">
                  <span className="text-slate-500 font-medium">Latency:</span>
                  <span className="font-mono text-emerald-600">{latency}ms</span>
                </div>
              )}
            </div>

            <div>
              <label className="block text-slate-600 font-medium mb-1">
                Optional Server URL (leave blank if none):
              </label>
              <div className="flex gap-2">
                <input
                  type="text"
                  value={endpointInput}
                  onChange={(e) => setEndpointInput(e.target.value)}
                  placeholder="Optional (e.g. https://your-server.com)"
                  className="flex-1 px-2.5 py-1.5 border border-slate-300 rounded-lg text-xs font-mono focus:outline-hidden focus:ring-2 focus:ring-indigo-500"
                />
                <button
                  onClick={handleTestConnection}
                  disabled={isTesting}
                  className="px-3 py-1.5 bg-indigo-600 hover:bg-indigo-700 text-white rounded-lg font-medium text-xs disabled:opacity-50 cursor-pointer"
                >
                  {isTesting ? 'Checking...' : endpointInput.trim() ? 'Connect' : 'Clear'}
                </button>
              </div>
              <p className="text-[10px] text-slate-500 mt-1">
                GPT-SoVITS architecture stays dormant until a real server is configured. C2 uses standard Gemini speech pipeline in the meantime.
              </p>
            </div>

            {testResult && (
              <div className="p-2 rounded-md bg-slate-100 text-slate-700 border border-slate-200 text-[11px]">
                {testResult}
              </div>
            )}

            <div className="flex justify-between items-center pt-2 border-t border-slate-100">
              {status === 'GPT-SOVITS READY' && (
                <button
                  onClick={handleTestSpeech}
                  disabled={isTesting}
                  className="px-3 py-1.5 bg-slate-100 hover:bg-slate-200 text-slate-700 font-medium rounded-lg text-xs cursor-pointer"
                >
                  Test Voice Sample
                </button>
              )}
              <div className="ml-auto">
                <button
                  onClick={() => setIsPopoverOpen(false)}
                  className="px-3 py-1.5 text-slate-500 hover:text-slate-700 text-xs"
                >
                  Close
                </button>
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
