import React from 'react';
import { LiveConnectionState, AtmosphereTheme } from '../types';
import { Mic, MicOff, Power, Sparkles, Volume2, Radio } from 'lucide-react';

interface VoiceCoreProps {
  connectionState: LiveConnectionState;
  inputLevel: number;
  outputLevel: number;
  isMuted: boolean;
  theme: AtmosphereTheme;
  micPermission?: 'prompt' | 'granted' | 'denied';
  onToggleConnection: () => void;
  onToggleMute: () => void;
  onInterrupt: () => void;
  onRequestMic?: () => void;
}

export const VoiceCore: React.FC<VoiceCoreProps> = ({
  connectionState,
  inputLevel,
  outputLevel,
  isMuted,
  theme,
  micPermission = 'prompt',
  onToggleConnection,
  onToggleMute,
  onInterrupt,
  onRequestMic,
}) => {
  const isSpeaking = connectionState === 'speaking';
  const isListening = connectionState === 'listening';
  const isThinking = connectionState === 'thinking';
  const isConnecting = connectionState === 'connecting';
  const isError = connectionState === 'error';
  const isDisconnected = connectionState === 'disconnected';

  const activeLevel = isSpeaking ? outputLevel : inputLevel;
  // Visual scale multiplier derived from real-time audio amplitude
  const scaleEffect = 1 + (activeLevel / 100) * 0.35;

  // Glow color scheme
  let ringGlow = 'rgba(139, 92, 246, 0.4)';
  let coreBg = 'from-violet-600 via-indigo-600 to-fuchsia-600';

  if (isSpeaking) {
    ringGlow = 'rgba(236, 72, 153, 0.65)';
    coreBg = 'from-fuchsia-500 via-pink-600 to-rose-500';
  } else if (isListening) {
    ringGlow = 'rgba(16, 185, 129, 0.55)';
    coreBg = 'from-emerald-500 via-teal-500 to-cyan-600';
  } else if (isThinking) {
    ringGlow = 'rgba(59, 130, 246, 0.65)';
    coreBg = 'from-blue-600 via-indigo-600 to-cyan-500';
  } else if (isConnecting) {
    ringGlow = 'rgba(6, 182, 212, 0.6)';
    coreBg = 'from-cyan-500 via-sky-600 to-blue-600';
  } else if (isError) {
    ringGlow = 'rgba(244, 63, 94, 0.65)';
    coreBg = 'from-rose-600 via-red-600 to-amber-600';
  }

  return (
    <div className="relative flex flex-col items-center justify-center select-none my-6">
      {/* Outer Radiating Atmospheric Rings */}
      <div className="relative w-64 h-64 sm:w-72 sm:h-72 flex items-center justify-center">
        {/* Ambient Ring 3 (Outer aura) */}
        <div
          className="absolute inset-0 rounded-full border border-white/5 transition-transform duration-100 ease-out"
          style={{
            transform: `scale(${scaleEffect * 1.15})`,
            boxShadow: `0 0 60px ${ringGlow}`,
            opacity: isDisconnected ? 0.2 : 0.75,
          }}
        />

        {/* Ambient Ring 2 (Middle ripple) */}
        <div
          className={`absolute w-52 h-52 sm:w-60 sm:h-60 rounded-full border border-white/10 transition-transform duration-150 ease-out ${
            isConnecting ? 'animate-spin border-dashed border-cyan-400/40' : ''
          }`}
          style={{
            transform: isConnecting ? undefined : `scale(${scaleEffect * 1.08})`,
            boxShadow: `0 0 40px ${ringGlow}`,
            opacity: isDisconnected ? 0.3 : 0.85,
          }}
        />

        {/* Ambient Ring 1 (Inner glow border) */}
        <div
          className="absolute w-44 h-44 sm:w-50 sm:h-50 rounded-full border border-white/20 transition-all duration-75"
          style={{
            transform: `scale(${scaleEffect})`,
            boxShadow: `inset 0 0 30px ${ringGlow}`,
          }}
        />

        {/* Core Animated Glass Sphere / Interactive Power Core */}
        <button
          type="button"
          id="c2-core-power-btn"
          onClick={() => {
            if (isSpeaking) {
              onInterrupt();
            } else {
              onToggleConnection();
            }
          }}
          className={`relative z-10 w-36 h-36 sm:w-40 sm:h-40 rounded-full p-1 cursor-pointer transition-all duration-300 focus:outline-hidden group shadow-2xl active:scale-95 ${
            isDisconnected ? 'hover:scale-105' : ''
          }`}
          title={
            isDisconnected
              ? 'Tap to Connect to C2 Voice'
              : isSpeaking
              ? 'Tap to Interrupt C2'
              : 'Tap to Disconnect'
          }
        >
          {/* Glass Gradient Core Surface */}
          <div
            className={`w-full h-full rounded-full bg-gradient-to-tr ${coreBg} flex flex-col items-center justify-center relative overflow-hidden backdrop-blur-md transition-all duration-500 border border-white/30`}
          >
            {/* Top specular reflection arc */}
            <div className="absolute top-1 inset-x-4 h-1/2 bg-gradient-to-b from-white/35 to-transparent rounded-t-full pointer-events-none" />

            {/* Inner dynamic pulsing wave */}
            <div
              className={`absolute inset-0 bg-white/20 rounded-full mix-blend-overlay ${
                isSpeaking ? 'animate-ping duration-1000' : isListening ? 'animate-pulse duration-700' : ''
              }`}
              style={{ opacity: (activeLevel / 100) * 0.8 }}
            />

            {/* Central Icon */}
            <div className="relative z-20 flex flex-col items-center justify-center text-white">
              {isDisconnected && (
                <>
                  <Power className="w-10 h-10 text-white/90 drop-shadow-md group-hover:scale-110 transition-transform" />
                  <span className="text-[10px] uppercase font-bold tracking-widest mt-1 text-white/80">
                    Connect
                  </span>
                </>
              )}

              {isConnecting && (
                <>
                  <Radio className="w-9 h-9 text-white animate-spin drop-shadow-md" />
                  <span className="text-[10px] uppercase font-semibold tracking-wider mt-1 text-white/90">
                    Connecting
                  </span>
                </>
              )}

              {isThinking && (
                <>
                  <Sparkles className="w-9 h-9 text-cyan-200 animate-pulse drop-shadow-md" />
                  <span className="text-[10px] uppercase font-bold tracking-wider mt-1 text-cyan-100">
                    Thinking...
                  </span>
                </>
              )}

              {isListening && (
                <>
                  {micPermission === 'denied' ? (
                    <>
                      <Volume2 className="w-10 h-10 text-amber-200 drop-shadow-md animate-pulse" />
                      <span className="text-[10px] uppercase font-bold tracking-widest mt-1 text-amber-100">
                        Speaker Mode
                      </span>
                    </>
                  ) : (
                    <>
                      <Mic
                        className={`w-10 h-10 text-white drop-shadow-md ${
                          isMuted ? 'opacity-40' : 'animate-bounce'
                        }`}
                      />
                      <span className="text-[10px] uppercase font-bold tracking-widest mt-1 text-emerald-100">
                        Listening
                      </span>
                    </>
                  )}
                </>
              )}

              {isSpeaking && (
                <>
                  <Volume2 className="w-10 h-10 text-white drop-shadow-md animate-pulse" />
                  <span className="text-[10px] uppercase font-bold tracking-widest mt-1 text-fuchsia-100">
                    Speaking
                  </span>
                </>
              )}

              {isError && (
                <>
                  <Power className="w-10 h-10 text-rose-200 drop-shadow-md hover:scale-110 transition-transform" />
                  <span className="text-[10px] uppercase font-bold tracking-widest mt-1 text-rose-100">
                    Reconnect
                  </span>
                </>
              )}
            </div>

            {/* Subtle bottom glow rim */}
            <div className="absolute bottom-0 inset-x-6 h-4 bg-white/20 blur-sm rounded-full pointer-events-none" />
          </div>
        </button>
      </div>

      {/* Floating Control Badges Below Core */}
      <div className="flex items-center gap-3 mt-4">
        {/* Enable Mic Button if Denied */}
        {!isDisconnected && micPermission === 'denied' && onRequestMic && (
          <button
            type="button"
            id="c2-grant-mic-badge-btn"
            onClick={onRequestMic}
            className="px-3.5 py-1.5 rounded-full text-xs font-semibold flex items-center gap-1.5 bg-amber-500/20 border border-amber-500/40 text-amber-200 hover:bg-amber-500/30 backdrop-blur-xl transition-all cursor-pointer"
            title="Microphone is currently blocked. Tap to grant permission."
          >
            <MicOff className="w-3.5 h-3.5 text-amber-400" />
            <span>Enable Mic</span>
          </button>
        )}

        {/* Mic Mute Toggle */}
        {!isDisconnected && micPermission !== 'denied' && (
          <button
            type="button"
            id="c2-mute-toggle-btn"
            onClick={onToggleMute}
            className={`px-3.5 py-1.5 rounded-full text-xs font-medium flex items-center gap-2 backdrop-blur-xl border transition-all cursor-pointer ${
              isMuted
                ? 'bg-rose-500/20 border-rose-500/40 text-rose-300 hover:bg-rose-500/30'
                : 'bg-white/10 border-white/15 text-slate-300 hover:bg-white/20'
            }`}
          >
            {isMuted ? <MicOff className="w-3.5 h-3.5 text-rose-400" /> : <Mic className="w-3.5 h-3.5 text-emerald-400" />}
            <span>{isMuted ? 'Unmute Mic' : 'Mute Mic'}</span>
          </button>
        )}

        {/* Interrupt Button when Speaking */}
        {isSpeaking && (
          <button
            type="button"
            id="c2-interrupt-btn"
            onClick={onInterrupt}
            className="px-3.5 py-1.5 rounded-full text-xs font-semibold flex items-center gap-1.5 bg-fuchsia-500/20 border border-fuchsia-500/40 text-fuchsia-200 hover:bg-fuchsia-500/30 backdrop-blur-xl transition-all cursor-pointer animate-in fade-in"
          >
            <Sparkles className="w-3.5 h-3.5 text-fuchsia-400" />
            <span>Interrupt</span>
          </button>
        )}

        {/* Disconnect Button if active */}
        {!isDisconnected && (
          <button
            type="button"
            id="c2-disconnect-btn"
            onClick={onToggleConnection}
            className="px-3 py-1.5 rounded-full text-xs font-medium bg-red-500/15 border border-red-500/30 text-red-300 hover:bg-red-500/25 backdrop-blur-xl transition-all cursor-pointer"
          >
            End Call
          </button>
        )}
      </div>
    </div>
  );
};
