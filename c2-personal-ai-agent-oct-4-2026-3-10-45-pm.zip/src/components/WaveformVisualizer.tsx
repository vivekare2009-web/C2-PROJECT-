import React, { useEffect, useRef } from 'react';
import { LiveConnectionState, AtmosphereTheme } from '../types';

interface WaveformVisualizerProps {
  connectionState: LiveConnectionState;
  inputLevel: number; // 0 - 100
  outputLevel: number; // 0 - 100
  theme: AtmosphereTheme;
}

export const WaveformVisualizer: React.FC<WaveformVisualizerProps> = ({
  connectionState,
  inputLevel,
  outputLevel,
  theme,
}) => {
  const canvasRef = useRef<HTMLCanvasElement | null>(null);

  // Store fast-changing values in refs to avoid restarting the requestAnimationFrame loop at 60fps
  const stateRef = useRef({ connectionState, inputLevel, outputLevel, theme });
  stateRef.current = { connectionState, inputLevel, outputLevel, theme };

  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    let animId: number;
    let width = (canvas.width = canvas.parentElement?.clientWidth || 360);
    let height = (canvas.height = 80);

    const handleResize = () => {
      if (!canvas) return;
      width = canvas.width = canvas.parentElement?.clientWidth || 360;
      height = canvas.height = 80;
    };

    window.addEventListener('resize', handleResize);

    const barCount = 48;
    const barWidth = 3.5;
    let phase = 0;

    const render = () => {
      try {
        phase += 0.08;
        ctx.clearRect(0, 0, width, height);

        const current = stateRef.current;
        const isSpeaking = current.connectionState === 'speaking';
        const isListening = current.connectionState === 'listening';
        const isThinking = current.connectionState === 'thinking';
        const isConnecting = current.connectionState === 'connecting';
        const isError = current.connectionState === 'error';
        const activeLevel = isSpeaking ? current.outputLevel : current.inputLevel;

        const centerY = height / 2;
        const gap = Math.max(1, (width - barCount * barWidth) / (barCount - 1));

        // Select color scheme based on state & theme
        let primaryColor = '139, 92, 246'; // violet
        let secondaryColor = '236, 72, 153'; // pink

        if (isSpeaking) {
          primaryColor = '168, 85, 247'; // purple
          secondaryColor = '244, 63, 94'; // rose
        } else if (isListening) {
          primaryColor = '16, 185, 129'; // emerald
          secondaryColor = '6, 182, 212'; // cyan
        } else if (isThinking) {
          primaryColor = '59, 130, 246'; // blue
          secondaryColor = '147, 51, 234'; // purple
        } else if (isError) {
          primaryColor = '244, 63, 94'; // rose
          secondaryColor = '251, 146, 60'; // amber
        } else if (current.theme === 'cyberpunk') {
          primaryColor = '6, 182, 212';
          secondaryColor = '217, 70, 239';
        }

        for (let i = 0; i < barCount; i++) {
          const x = i * (barWidth + gap);
          const distFromCenter = Math.abs(i - barCount / 2) / (barCount / 2);
          const centerFactor = Math.cos(distFromCenter * Math.PI * 0.45);

          let targetHeight = 4; // idle baseline

          if (isSpeaking || isListening) {
            // Sine wave modulation + real-time audio amplitude
            const wave = Math.sin(phase + i * 0.3) * 0.5 + 0.5;
            const randomJitter = Math.sin(phase * 1.5 + i * 0.8) * 0.3;
            const energy = (activeLevel / 100) * 32 * centerFactor;
            targetHeight = Math.max(4, energy * (wave + randomJitter + 0.4) + 4);
          } else if (isThinking) {
            const ripple = Math.sin(phase * 3 - i * 0.4);
            targetHeight = Math.max(4, Math.abs(ripple) * 20 * centerFactor + 4);
          } else if (isConnecting) {
            const pulse = Math.sin(phase * 2 - i * 0.25);
            targetHeight = Math.max(4, Math.abs(pulse) * 16 * centerFactor);
          } else if (isError) {
            const errPulse = Math.sin(phase * 1.2 + i * 0.1);
            targetHeight = Math.max(3, 4 + errPulse * 2 * centerFactor);
          } else {
            // subtle breathing pulse in disconnected
            const subtle = Math.sin(phase * 0.5 + i * 0.2) * 2;
            targetHeight = Math.max(2, 4 + subtle * centerFactor);
          }

          const halfH = targetHeight / 2;
          const yTop = centerY - halfH;

          // Linear gradient for each bar
          const gradient = ctx.createLinearGradient(0, yTop, 0, yTop + targetHeight);
          const isLive = isSpeaking || isListening || isThinking;
          gradient.addColorStop(0, `rgba(${secondaryColor}, ${isLive ? 0.95 : 0.4})`);
          gradient.addColorStop(0.5, `rgba(${primaryColor}, ${isLive ? 0.85 : 0.3})`);
          gradient.addColorStop(1, `rgba(${secondaryColor}, ${isLive ? 0.95 : 0.4})`);

          ctx.fillStyle = gradient;
          ctx.beginPath();
          // Safe rounded bar caps
          const radius = Math.max(0, Math.min(barWidth / 2, targetHeight / 2));
          if (typeof (ctx as any).roundRect === 'function') {
            try {
              (ctx as any).roundRect(x, yTop, barWidth, targetHeight, radius);
            } catch (_) {
              ctx.rect(x, yTop, barWidth, targetHeight);
            }
          } else {
            ctx.rect(x, yTop, barWidth, targetHeight);
          }
          ctx.fill();

          // Glow reflection
          if (isLive && activeLevel > 20) {
            ctx.shadowColor = `rgba(${primaryColor}, 0.5)`;
            ctx.shadowBlur = 8;
          } else {
            ctx.shadowBlur = 0;
          }
        }
      } catch (loopErr) {
        console.warn('[WaveformVisualizer] render error caught:', loopErr);
      }

      animId = requestAnimationFrame(render);
    };

    render();

    return () => {
      window.removeEventListener('resize', handleResize);
      cancelAnimationFrame(animId);
    };
  }, []); // Run ONCE on mount, values read from stateRef

  return (
    <div className="w-full max-w-sm mx-auto h-20 flex items-center justify-center">
      <canvas ref={canvasRef} className="w-full h-full block" />
    </div>
  );
};

