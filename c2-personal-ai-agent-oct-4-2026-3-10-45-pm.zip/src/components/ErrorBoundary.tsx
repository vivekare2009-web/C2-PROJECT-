import React, { Component, ErrorInfo, ReactNode } from 'react';
import { AlertTriangle, RefreshCw } from 'lucide-react';

interface Props {
  children: ReactNode;
}

interface State {
  hasError: boolean;
  error: Error | null;
}

export class ErrorBoundary extends Component<Props, State> {
  constructor(props: Props) {
    super(props);
    this.state = {
      hasError: false,
      error: null,
    };
  }

  public static getDerivedStateFromError(error: Error): State {
    return { hasError: true, error };
  }

  public componentDidCatch(error: Error, errorInfo: ErrorInfo) {
    console.error('[C2 ErrorBoundary] Uncaught runtime error:', error, errorInfo);
  }

  private handleRecover = () => {
    this.setState({ hasError: false, error: null });
    window.location.reload();
  };

  public render() {
    if (this.state.hasError) {
      return (
        <div className="min-h-screen w-full bg-[#050510] text-white flex flex-col items-center justify-center p-6 text-center">
          <div className="max-w-md w-full p-6 rounded-2xl bg-white/[0.04] border border-rose-500/30 backdrop-blur-xl shadow-2xl space-y-4">
            <div className="w-12 h-12 rounded-full bg-rose-500/20 border border-rose-500/40 flex items-center justify-center mx-auto text-rose-400">
              <AlertTriangle className="w-6 h-6" />
            </div>
            <div>
              <h2 className="text-lg font-semibold text-white">C2 Core Notice</h2>
              <p className="text-xs text-slate-300 mt-1">
                A visual runtime exception occurred. C2's recovery system caught the fault.
              </p>
            </div>
            {this.state.error && (
              <div className="p-3 rounded-lg bg-black/40 border border-white/10 text-left text-[11px] font-mono text-rose-300 overflow-auto max-h-32">
                {this.state.error.message || 'Unknown error'}
              </div>
            )}
            <button
              id="c2-recover-btn"
              onClick={this.handleRecover}
              className="w-full py-2.5 px-4 rounded-xl bg-violet-600 hover:bg-violet-500 text-white font-medium text-xs flex items-center justify-center gap-2 cursor-pointer transition-all shadow-lg shadow-violet-600/20"
            >
              <RefreshCw className="w-4 h-4" />
              <span>Recover C2 Interface</span>
            </button>
          </div>
        </div>
      );
    }

    return this.props.children;
  }
}
