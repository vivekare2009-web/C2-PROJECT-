import React, { useState } from 'react';
import { UserProfile, MemoryItem } from '../types';
import {
  User,
  Database,
  Shield,
  Check,
  Plus,
  Trash2,
  X,
  Sparkles,
  ArrowRight,
  UserPlus,
  RefreshCw,
  Key,
} from 'lucide-react';

interface IdentityMemoryModalProps {
  isOpen: boolean;
  onClose: () => void;
  currentUser: UserProfile | null;
  memories: MemoryItem[];
  allUsers: UserProfile[];
  onSwitchUser: (userId: string) => Promise<void>;
  onCreateUser: (email: string, displayName: string, preferredName: string) => Promise<void>;
  onUpdatePreferredName: (name: string) => Promise<void>;
  onAddMemory: (category: string, key: string, value: string) => Promise<void>;
  onDeleteMemory: (id: string) => Promise<void>;
  onClearMemories: () => Promise<void>;
}

export const IdentityMemoryModal: React.FC<IdentityMemoryModalProps> = ({
  isOpen,
  onClose,
  currentUser,
  memories,
  allUsers,
  onSwitchUser,
  onCreateUser,
  onUpdatePreferredName,
  onAddMemory,
  onDeleteMemory,
  onClearMemories,
}) => {
  const [activeTab, setActiveTab] = useState<'identity' | 'memories' | 'new_account'>('identity');
  const [editingTitle, setEditingTitle] = useState(currentUser?.preferredName || 'Master');
  const [isUpdatingTitle, setIsUpdatingTitle] = useState(false);
  const [titleSuccess, setTitleSuccess] = useState(false);

  // New account form state
  const [newEmail, setNewEmail] = useState('');
  const [newDisplayName, setNewDisplayName] = useState('');
  const [newPreferredTitle, setNewPreferredTitle] = useState('Master');
  const [isCreating, setIsCreating] = useState(false);

  // New memory form state
  const [newKey, setNewKey] = useState('');
  const [newValue, setNewValue] = useState('');
  const [newCategory, setNewCategory] = useState('preference');
  const [isAddingMemory, setIsAddingMemory] = useState(false);

  if (!isOpen) return null;

  const handleSaveTitle = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!editingTitle.trim()) return;
    setIsUpdatingTitle(true);
    try {
      await onUpdatePreferredName(editingTitle.trim());
      setTitleSuccess(true);
      setTimeout(() => setTitleSuccess(false), 2500);
    } finally {
      setIsUpdatingTitle(false);
    }
  };

  const handleCreateAccount = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!newEmail.trim() && !newDisplayName.trim()) return;
    setIsCreating(true);
    try {
      await onCreateUser(newEmail.trim(), newDisplayName.trim(), newPreferredTitle.trim() || 'Master');
      setNewEmail('');
      setNewDisplayName('');
      setNewPreferredTitle('Master');
      setActiveTab('identity');
    } finally {
      setIsCreating(false);
    }
  };

  const handleAddMemoryItem = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!newKey.trim() || !newValue.trim()) return;
    setIsAddingMemory(true);
    try {
      await onAddMemory(newCategory, newKey.trim(), newValue.trim());
      setNewKey('');
      setNewValue('');
    } finally {
      setIsAddingMemory(false);
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/70 backdrop-blur-md animate-fade-in">
      <div
        id="c2-identity-modal"
        className="w-full max-w-2xl bg-slate-900/95 border border-white/10 rounded-2xl shadow-2xl overflow-hidden flex flex-col max-h-[90vh]"
      >
        {/* Modal Header */}
        <div className="flex items-center justify-between px-6 py-4 border-b border-white/10 bg-white/5">
          <div className="flex items-center gap-2.5">
            <div className="w-8 h-8 rounded-lg bg-violet-600/30 border border-violet-400/30 flex items-center justify-center text-violet-300">
              <Shield className="w-4 h-4" />
            </div>
            <div>
              <h2 className="text-base font-bold text-white tracking-tight flex items-center gap-2">
                Persistent Identity & C2 Memory
              </h2>
              <p className="text-xs text-slate-400">
                Persistent database profiles & memory storage for returning sessions
              </p>
            </div>
          </div>
          <button
            id="close-identity-modal"
            onClick={onClose}
            className="p-1.5 rounded-lg text-slate-400 hover:text-white hover:bg-white/10 transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Modal Navigation Tabs */}
        <div className="flex items-center px-6 pt-3 border-b border-white/10 gap-2 bg-slate-950/40">
          <button
            id="tab-identity"
            onClick={() => setActiveTab('identity')}
            className={`flex items-center gap-2 px-3.5 py-2 text-xs font-medium border-b-2 transition-all ${
              activeTab === 'identity'
                ? 'border-violet-500 text-white font-semibold'
                : 'border-transparent text-slate-400 hover:text-slate-200'
            }`}
          >
            <User className="w-3.5 h-3.5" />
            <span>Account Profile</span>
          </button>
          <button
            id="tab-memories"
            onClick={() => setActiveTab('memories')}
            className={`flex items-center gap-2 px-3.5 py-2 text-xs font-medium border-b-2 transition-all ${
              activeTab === 'memories'
                ? 'border-violet-500 text-white font-semibold'
                : 'border-transparent text-slate-400 hover:text-slate-200'
            }`}
          >
            <Database className="w-3.5 h-3.5" />
            <span>C2 Database Memories ({memories.length})</span>
          </button>
          <button
            id="tab-new-account"
            onClick={() => setActiveTab('new_account')}
            className={`flex items-center gap-2 px-3.5 py-2 text-xs font-medium border-b-2 transition-all ${
              activeTab === 'new_account'
                ? 'border-violet-500 text-white font-semibold'
                : 'border-transparent text-slate-400 hover:text-slate-200'
            }`}
          >
            <UserPlus className="w-3.5 h-3.5" />
            <span>Create / Test First Login</span>
          </button>
        </div>

        {/* Modal Body */}
        <div className="p-6 overflow-y-auto space-y-6 flex-1 text-slate-300 text-sm">
          {/* TAB 1: USER IDENTITY & ACCOUNT */}
          {activeTab === 'identity' && (
            <div className="space-y-6">
              {/* Active Profile Card */}
              <div className="p-4 rounded-xl bg-gradient-to-r from-violet-950/40 to-slate-800/40 border border-violet-500/20 space-y-3">
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-3">
                    <div className="w-10 h-10 rounded-full bg-violet-600/30 border border-violet-400/40 flex items-center justify-center font-bold text-violet-200 text-base">
                      {currentUser?.preferredName?.[0] || 'M'}
                    </div>
                    <div>
                      <div className="font-bold text-white text-base flex items-center gap-2">
                        {currentUser?.displayName || 'Master'}
                        {currentUser?.isFirstLogin ? (
                          <span className="px-2 py-0.5 rounded-full text-[10px] font-semibold bg-amber-500/20 text-amber-300 border border-amber-500/30">
                            First Login
                          </span>
                        ) : (
                          <span className="px-2 py-0.5 rounded-full text-[10px] font-semibold bg-emerald-500/20 text-emerald-300 border border-emerald-500/30">
                            Returning User (Recognized)
                          </span>
                        )}
                      </div>
                      <div className="text-xs font-mono text-slate-400 flex items-center gap-1.5 mt-0.5">
                        <Key className="w-3 h-3 text-slate-500" />
                        <span>ID: {currentUser?.id || 'usr_master_vivek'}</span>
                        {currentUser?.email && <span>• {currentUser.email}</span>}
                      </div>
                    </div>
                  </div>
                </div>

                {/* Natural C2 Greeting Recognition preview */}
                <div className="p-3 rounded-lg bg-black/40 border border-white/5 space-y-1">
                  <div className="text-[11px] font-semibold uppercase tracking-wider text-violet-300 flex items-center gap-1.5">
                    <Sparkles className="w-3 h-3" />
                    <span>C2 Recognition Greeting</span>
                  </div>
                  <p className="text-xs italic text-slate-200">
                    "{currentUser?.isFirstLogin
                      ? "Hey! I'm C2. Nice to meet you. You can call me whenever you need me. What should I call you?"
                      : `Hey ${currentUser?.preferredName || 'Master'}, good to see you again.`}"
                  </p>
                </div>
              </div>

              {/* Preferred Title Setting */}
              <div className="space-y-3 p-4 rounded-xl bg-white/5 border border-white/10">
                <div>
                  <h3 className="text-sm font-semibold text-white">How C2 Should Address You</h3>
                  <p className="text-xs text-slate-400 mt-0.5">
                    C2 addresses you naturally and occasionally using your preferred title or name (e.g., "Master" or "Master Vivek").
                  </p>
                </div>

                <form onSubmit={handleSaveTitle} className="flex gap-2">
                  <input
                    id="preferred-title-input"
                    type="text"
                    value={editingTitle}
                    onChange={(e) => setEditingTitle(e.target.value)}
                    placeholder="e.g. Master, Master Vivek"
                    className="flex-1 px-3 py-2 text-xs rounded-lg bg-slate-950 border border-white/15 text-white placeholder-slate-500 focus:outline-hidden focus:border-violet-500"
                  />
                  <button
                    id="save-preferred-title"
                    type="submit"
                    disabled={isUpdatingTitle}
                    className="px-4 py-2 rounded-lg bg-violet-600 hover:bg-violet-500 text-white font-medium text-xs flex items-center gap-1.5 transition-colors disabled:opacity-50"
                  >
                    {titleSuccess ? (
                      <>
                        <Check className="w-3.5 h-3.5" />
                        <span>Saved</span>
                      </>
                    ) : (
                      <>
                        <span>Update Title</span>
                      </>
                    )}
                  </button>
                </form>

                {/* Quick Selection Presets */}
                <div className="flex flex-wrap gap-1.5 pt-1">
                  {['Master', 'Master Vivek', 'Vivek'].map((preset) => (
                    <button
                      key={preset}
                      type="button"
                      onClick={() => {
                        setEditingTitle(preset);
                        onUpdatePreferredName(preset);
                      }}
                      className={`px-2.5 py-1 text-[11px] rounded-md border transition-all ${
                        currentUser?.preferredName === preset
                          ? 'bg-violet-500/20 text-violet-200 border-violet-500/40'
                          : 'bg-white/5 text-slate-400 border-white/10 hover:text-white hover:bg-white/10'
                      }`}
                    >
                      {preset}
                    </button>
                  ))}
                </div>
              </div>

              {/* Database Accounts Switcher */}
              <div className="space-y-3">
                <div className="flex items-center justify-between">
                  <h3 className="text-sm font-semibold text-white">Database User Accounts</h3>
                  <span className="text-xs text-slate-400 font-mono">{allUsers.length} Registered</span>
                </div>
                <div className="grid gap-2">
                  {allUsers.map((u) => {
                    const isSelected = u.id === currentUser?.id;
                    return (
                      <div
                        key={u.id}
                        onClick={() => !isSelected && onSwitchUser(u.id)}
                        className={`flex items-center justify-between p-3 rounded-xl border transition-all cursor-pointer ${
                          isSelected
                            ? 'bg-violet-950/30 border-violet-500/40 text-white'
                            : 'bg-white/5 border-white/10 text-slate-300 hover:bg-white/10'
                        }`}
                      >
                        <div className="flex items-center gap-3">
                          <div
                            className={`w-8 h-8 rounded-lg flex items-center justify-center font-bold text-xs ${
                              isSelected ? 'bg-violet-600 text-white' : 'bg-slate-800 text-slate-400'
                            }`}
                          >
                            {u.preferredName?.[0] || 'U'}
                          </div>
                          <div>
                            <div className="font-medium text-xs flex items-center gap-2">
                              <span>{u.displayName}</span>
                              <span className="text-[10px] text-slate-400">({u.preferredName})</span>
                              {isSelected && (
                                <span className="px-1.5 py-0.5 rounded text-[10px] font-semibold bg-violet-500/20 text-violet-300">
                                  Active
                                </span>
                              )}
                            </div>
                            <div className="text-[11px] font-mono text-slate-500">ID: {u.id}</div>
                          </div>
                        </div>

                        {!isSelected && (
                          <span className="text-xs text-violet-400 flex items-center gap-1 font-medium">
                            <span>Switch</span>
                            <ArrowRight className="w-3 h-3" />
                          </span>
                        )}
                      </div>
                    );
                  })}
                </div>
              </div>
            </div>
          )}

          {/* TAB 2: C2 DATABASE MEMORIES */}
          {activeTab === 'memories' && (
            <div className="space-y-6">
              <div className="flex items-center justify-between">
                <div>
                  <h3 className="text-sm font-semibold text-white">Persistent Memory Storage</h3>
                  <p className="text-xs text-slate-400">
                    Stored on server database and loaded when C2 initializes. C2 dynamically recalls these during voice interaction.
                  </p>
                </div>
                {memories.length > 0 && (
                  <button
                    id="clear-all-memories"
                    onClick={onClearMemories}
                    className="px-3 py-1.5 rounded-lg bg-red-500/10 hover:bg-red-500/20 text-red-300 text-xs border border-red-500/30 flex items-center gap-1.5 transition-colors"
                  >
                    <Trash2 className="w-3.5 h-3.5" />
                    <span>Clear All</span>
                  </button>
                )}
              </div>

              {/* Add Memory Item Form */}
              <form onSubmit={handleAddMemoryItem} className="p-4 rounded-xl bg-white/5 border border-white/10 space-y-3">
                <div className="text-xs font-semibold text-white flex items-center gap-1.5">
                  <Plus className="w-3.5 h-3.5 text-violet-400" />
                  <span>Add Persistent Fact or Preference</span>
                </div>
                <div className="grid grid-cols-1 sm:grid-cols-3 gap-2">
                  <input
                    type="text"
                    placeholder="Key (e.g. favorite_coffee)"
                    value={newKey}
                    onChange={(e) => setNewKey(e.target.value)}
                    className="px-3 py-2 text-xs rounded-lg bg-slate-950 border border-white/15 text-white placeholder-slate-500 focus:outline-hidden focus:border-violet-500"
                  />
                  <input
                    type="text"
                    placeholder="Value (e.g. Iced Matcha)"
                    value={newValue}
                    onChange={(e) => setNewValue(e.target.value)}
                    className="px-3 py-2 text-xs rounded-lg bg-slate-950 border border-white/15 text-white placeholder-slate-500 focus:outline-hidden focus:border-violet-500"
                  />
                  <div className="flex gap-2">
                    <select
                      value={newCategory}
                      onChange={(e) => setNewCategory(e.target.value)}
                      className="px-2 py-2 text-xs rounded-lg bg-slate-950 border border-white/15 text-white focus:outline-hidden focus:border-violet-500"
                    >
                      <option value="preference">Preference</option>
                      <option value="profile">Profile</option>
                      <option value="long_term">Long-term</option>
                      <option value="task">Task</option>
                    </select>
                    <button
                      type="submit"
                      disabled={isAddingMemory || !newKey || !newValue}
                      className="flex-1 px-3 py-2 rounded-lg bg-violet-600 hover:bg-violet-500 text-white font-medium text-xs transition-colors disabled:opacity-50"
                    >
                      Add
                    </button>
                  </div>
                </div>
              </form>

              {/* Memories List */}
              <div className="space-y-2">
                {memories.length === 0 ? (
                  <div className="p-8 text-center rounded-xl bg-white/5 border border-white/5 text-slate-400 text-xs">
                    No memories saved yet for this user. Tell C2 "Remember that I like..." or add facts above!
                  </div>
                ) : (
                  memories.map((m) => (
                    <div
                      key={m.id}
                      className="flex items-center justify-between p-3 rounded-lg bg-slate-950/60 border border-white/10 group hover:border-violet-500/30 transition-all"
                    >
                      <div className="space-y-0.5">
                        <div className="flex items-center gap-2">
                          <span className="font-mono text-xs font-semibold text-violet-300">{m.key}</span>
                          <span className="px-1.5 py-0.5 rounded text-[10px] font-mono uppercase bg-white/10 text-slate-400">
                            {m.category}
                          </span>
                        </div>
                        <div className="text-xs text-slate-200">{m.value}</div>
                      </div>
                      <button
                        onClick={() => onDeleteMemory(m.id)}
                        className="p-1.5 rounded text-slate-500 hover:text-red-400 hover:bg-red-500/10 opacity-60 group-hover:opacity-100 transition-all"
                        title="Delete memory"
                      >
                        <Trash2 className="w-3.5 h-3.5" />
                      </button>
                    </div>
                  ))
                )}
              </div>
            </div>
          )}

          {/* TAB 3: CREATE NEW ACCOUNT (TEST FIRST LOGIN FLOW) */}
          {activeTab === 'new_account' && (
            <div className="space-y-6">
              <div className="p-4 rounded-xl bg-violet-950/30 border border-violet-500/20 space-y-2">
                <h3 className="text-sm font-semibold text-white flex items-center gap-2">
                  <Sparkles className="w-4 h-4 text-violet-400" />
                  <span>First Login Onboarding Experience</span>
                </h3>
                <p className="text-xs text-slate-300 leading-relaxed">
                  When a user creates an account for the first time, C2 introduces herself naturally:
                  <br />
                  <span className="italic text-violet-300 font-medium">
                    "Hey! I'm C2. Nice to meet you. You can call me whenever you need me. What should I call you?"
                  </span>
                  <br />
                  Create a new account below to test this onboarding flow!
                </p>
              </div>

              <form onSubmit={handleCreateAccount} className="space-y-4">
                <div className="space-y-1">
                  <label className="text-xs font-medium text-slate-300">Account Email / Username</label>
                  <input
                    id="new-user-email"
                    type="text"
                    placeholder="e.g. master.vivek@example.com or vivek"
                    value={newEmail}
                    onChange={(e) => setNewEmail(e.target.value)}
                    required
                    className="w-full px-3 py-2 text-xs rounded-lg bg-slate-950 border border-white/15 text-white placeholder-slate-500 focus:outline-hidden focus:border-violet-500"
                  />
                </div>

                <div className="space-y-1">
                  <label className="text-xs font-medium text-slate-300">Display Name</label>
                  <input
                    id="new-user-display-name"
                    type="text"
                    placeholder="e.g. Master Vivek"
                    value={newDisplayName}
                    onChange={(e) => setNewDisplayName(e.target.value)}
                    className="w-full px-3 py-2 text-xs rounded-lg bg-slate-950 border border-white/15 text-white placeholder-slate-500 focus:outline-hidden focus:border-violet-500"
                  />
                </div>

                <div className="space-y-1">
                  <label className="text-xs font-medium text-slate-300">Initial Preferred Title</label>
                  <input
                    id="new-user-title"
                    type="text"
                    placeholder="e.g. Master"
                    value={newPreferredTitle}
                    onChange={(e) => setNewPreferredTitle(e.target.value)}
                    className="w-full px-3 py-2 text-xs rounded-lg bg-slate-950 border border-white/15 text-white placeholder-slate-500 focus:outline-hidden focus:border-violet-500"
                  />
                  <p className="text-[11px] text-slate-400">
                    Default is "Master". On first voice connect, C2 will ask "What should I call you?".
                  </p>
                </div>

                <button
                  id="submit-create-account"
                  type="submit"
                  disabled={isCreating || (!newEmail && !newDisplayName)}
                  className="w-full py-2.5 rounded-lg bg-violet-600 hover:bg-violet-500 text-white font-semibold text-xs transition-colors flex items-center justify-center gap-2 disabled:opacity-50"
                >
                  <UserPlus className="w-4 h-4" />
                  <span>Create Account & Experience First Login</span>
                </button>
              </form>
            </div>
          )}
        </div>

        {/* Modal Footer */}
        <div className="px-6 py-3 border-t border-white/10 bg-white/5 flex items-center justify-between text-xs text-slate-400">
          <div className="flex items-center gap-1.5 font-mono text-[11px]">
            <span className="w-2 h-2 rounded-full bg-emerald-400" />
            <span>Persistent Database Active</span>
          </div>
          <button
            onClick={onClose}
            className="px-4 py-1.5 rounded-lg bg-white/10 hover:bg-white/20 text-white text-xs font-medium transition-colors"
          >
            Done
          </button>
        </div>
      </div>
    </div>
  );
};
