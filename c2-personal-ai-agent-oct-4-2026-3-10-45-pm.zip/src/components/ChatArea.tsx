import React, { useRef, useEffect } from 'react';
import { ChatMessage, ToolCall, RiskLevel } from '../types';
import { 
  Bot, 
  User, 
  Terminal, 
  Volume2, 
  CheckCircle, 
  XCircle, 
  AlertOctagon, 
  ShieldAlert,
  Sparkles,
  Play,
  Mic,
  Radio
} from 'lucide-react';

interface ChatAreaProps {
  messages: ChatMessage[];
  onConfirmAction: (toolCall: ToolCall) => void;
  onCancelAction: (toolCall: ToolCall) => void;
  onSpeakMessage: (text: string, language?: 'English' | 'Hindi' | 'Hinglish') => void;
  onSelectPrompt: (promptText: string) => void;
  onStartVoice?: () => void;
}

export const ChatArea: React.FC<ChatAreaProps> = ({
  messages,
  onConfirmAction,
  onCancelAction,
  onSpeakMessage,
  onSelectPrompt,
  onStartVoice,
}) => {
  const scrollEndRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    scrollEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, [messages]);

  const getRiskBadge = (risk: RiskLevel) => {
    switch (risk) {
      case 'HIGH':
        return (
          <span className="inline-flex items-center gap-1 px-1.5 py-0.5 rounded text-[11px] font-semibold bg-rose-100 text-rose-700 border border-rose-200">
            <AlertOctagon className="w-3 h-3 text-rose-600" />
            HIGH RISK
          </span>
        );
      case 'MEDIUM':
        return (
          <span className="inline-flex items-center gap-1 px-1.5 py-0.5 rounded text-[11px] font-semibold bg-amber-100 text-amber-800 border border-amber-200">
            <ShieldAlert className="w-3 h-3 text-amber-600" />
            MEDIUM RISK
          </span>
        );
      default:
        return (
          <span className="inline-flex items-center px-1.5 py-0.5 rounded text-[11px] font-medium bg-emerald-100 text-emerald-800 border border-emerald-200">
            LOW RISK
          </span>
        );
    }
  };

  const samplePrompts = [
    { label: 'YouTube kholo', text: 'C2, YouTube kholo.' },
    { label: 'Multi-step search', text: 'C2, open YouTube and search for home workout.' },
    { label: 'Find PDF', text: 'Find my workout PDF.' },
    { label: 'Delete file (Confirmation)', text: 'Delete homework.pdf.' },
    { label: 'Play music', text: 'C2, play music.' },
    { label: 'Wi-Fi settings', text: 'Open the Wi-Fi settings.' },
    { label: 'Remember preference', text: 'C2, remember that when I say browser, I mean Chrome.' },
    { label: 'Check memory', text: 'C2, what do you remember about me?' },
    { label: 'Hindi command', text: 'Is file ko rename kar do training.pdf mein.' },
  ];

  return (
    <div className="flex-1 flex flex-col overflow-y-auto px-4 sm:px-6 py-4 space-y-4">
      {messages.length === 0 ? (
        <div className="my-auto text-center max-w-lg mx-auto py-8">
          <div className="w-16 h-16 mx-auto mb-3 rounded-2xl bg-gradient-to-tr from-indigo-600 to-purple-600 flex items-center justify-center text-white shadow-md">
            <Bot className="w-8 h-8" />
          </div>
          <h2 className="text-xl font-semibold text-slate-900 mb-1">C2 is Ready</h2>
          <p className="text-sm text-slate-600 leading-relaxed mb-5">
            Your female personal AI assistant with persistent user memory, emotional intelligence, and safe Android device control.
          </p>

          {/* Primary Voice Mic Action Banner */}
          {onStartVoice && (
            <div className="mb-5 p-4 bg-gradient-to-r from-indigo-900 via-indigo-800 to-purple-900 rounded-2xl text-white shadow-lg border border-indigo-700/50 flex flex-col sm:flex-row items-center justify-between gap-3 text-left">
              <div className="flex items-center gap-3">
                <div className="relative">
                  <div className="w-11 h-11 rounded-xl bg-rose-600 flex items-center justify-center text-white shadow-md animate-pulse">
                    <Mic className="w-6 h-6" />
                  </div>
                  <span className="absolute -top-1 -right-1 flex h-3 w-3">
                    <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-rose-400 opacity-75"></span>
                    <span className="relative inline-flex rounded-full h-3 w-3 bg-rose-500"></span>
                  </span>
                </div>
                <div>
                  <h3 className="font-semibold text-sm text-white">Talk to C2 with Voice</h3>
                  <p className="text-xs text-indigo-200">Tap your microphone to speak in English, Hindi, or Hinglish</p>
                </div>
              </div>
              <button
                id="hero-start-talking-mic-btn"
                onClick={onStartVoice}
                className="w-full sm:w-auto px-4 py-2 bg-white text-indigo-900 hover:bg-indigo-50 rounded-xl text-xs font-bold transition-all shadow-sm flex items-center justify-center gap-2 cursor-pointer shrink-0"
              >
                <Radio className="w-4 h-4 text-rose-600 animate-pulse" />
                <span>Start Talking</span>
              </button>
            </div>
          )}

          {/* Prompt chips */}
          <div className="text-left bg-slate-50 border border-slate-200 rounded-xl p-4">
            <div className="text-xs font-semibold text-slate-600 mb-2 flex items-center gap-1.5">
              <Sparkles className="w-3.5 h-3.5 text-indigo-600" />
              <span>Try asking C2 (English / Hindi / Hinglish):</span>
            </div>
            <div className="flex flex-wrap gap-1.5">
              {samplePrompts.map((p, idx) => (
                <button
                  key={idx}
                  id={`sample-prompt-${idx}`}
                  onClick={() => onSelectPrompt(p.text)}
                  className="text-xs bg-white text-slate-700 hover:text-indigo-600 hover:border-indigo-300 px-2.5 py-1.5 rounded-lg border border-slate-200 transition-colors cursor-pointer text-left"
                >
                  {p.label}
                </button>
              ))}
            </div>
          </div>
        </div>
      ) : (
        messages.map((msg) => {
          const isUser = msg.sender === 'user';
          const isSystem = msg.sender === 'system';

          if (isSystem) {
            return (
              <div key={msg.id} className="flex justify-center my-2">
                <span className="text-xs bg-slate-100 text-slate-600 px-3 py-1 rounded-full border border-slate-200 font-mono">
                  {msg.text}
                </span>
              </div>
            );
          }

          return (
            <div
              key={msg.id}
              className={`flex gap-3 max-w-3xl ${isUser ? 'ml-auto flex-row-reverse' : 'mr-auto'}`}
            >
              {/* Avatar */}
              <div
                className={`w-8 h-8 rounded-lg flex items-center justify-center shrink-0 text-white font-medium text-xs shadow-xs ${
                  isUser
                    ? 'bg-slate-700'
                    : 'bg-gradient-to-tr from-indigo-700 to-purple-600'
                }`}
              >
                {isUser ? <User className="w-4 h-4" /> : <Bot className="w-4 h-4" />}
              </div>

              {/* Message bubble */}
              <div
                className={`flex flex-col space-y-2 rounded-2xl p-4 text-sm leading-relaxed border ${
                  isUser
                    ? 'bg-indigo-600 text-white border-indigo-700 rounded-tr-none'
                    : 'bg-white text-slate-900 border-slate-200 rounded-tl-none shadow-xs'
                }`}
              >
                {/* Header info */}
                <div className="flex items-center justify-between gap-4 text-xs">
                  <span className={`font-semibold ${isUser ? 'text-indigo-100' : 'text-slate-700'}`}>
                    {isUser ? 'You' : 'C2'}
                  </span>
                  <div className="flex items-center gap-2">
                    {msg.language && (
                      <span className={`px-1.5 py-0.5 rounded text-[11px] font-medium ${isUser ? 'bg-indigo-700 text-indigo-200' : 'bg-slate-100 text-slate-600'}`}>
                        {msg.language}
                      </span>
                    )}
                    {msg.emotionalState && (
                      <span className="px-1.5 py-0.5 rounded text-[11px] font-medium bg-purple-50 text-purple-700 border border-purple-100">
                        {msg.emotionalState}
                      </span>
                    )}
                    <span className={isUser ? 'text-indigo-200' : 'text-slate-700'}>
                      {msg.timestamp}
                    </span>
                    {!isUser && (
                      <button
                        title="Play audio response"
                        onClick={() => onSpeakMessage(msg.text, msg.language)}
                        className="text-slate-600 hover:text-indigo-600 transition-colors p-0.5 rounded cursor-pointer"
                      >
                        <Volume2 className="w-3.5 h-3.5" />
                      </button>
                    )}
                  </div>
                </div>

                {/* Main text */}
                <div className="whitespace-pre-wrap">{msg.text}</div>

                {/* Tool calls execution details */}
                {msg.toolCalls && msg.toolCalls.length > 0 && (
                  <div className="mt-2 space-y-2 pt-2 border-t border-slate-100">
                    <div className="text-[11px] font-semibold text-slate-600 flex items-center gap-1 uppercase tracking-wider">
                      <Terminal className="w-3.5 h-3.5 text-indigo-500" />
                      <span>Android Tool Actions</span>
                    </div>

                    {msg.toolCalls.map((tc, tcIdx) => (
                      <div
                        key={tc.id || tcIdx}
                        className="bg-slate-50 border border-slate-200 rounded-lg p-2.5 text-xs text-slate-800 space-y-1.5 font-mono"
                      >
                        <div className="flex items-center justify-between flex-wrap gap-2">
                          <div className="flex items-center gap-2">
                            <span className="font-bold text-indigo-700">{tc.tool}()</span>
                            {getRiskBadge(tc.risk)}
                          </div>
                          <span
                            className={`px-1.5 py-0.5 rounded text-[11px] font-semibold uppercase ${
                              tc.status === 'completed'
                                ? 'bg-emerald-100 text-emerald-800'
                                : tc.status === 'failed'
                                ? 'bg-red-100 text-red-800'
                                : tc.status === 'cancelled'
                                ? 'bg-slate-200 text-slate-700'
                                : 'bg-amber-100 text-amber-800 animate-pulse'
                            }`}
                          >
                            Status: {tc.status}
                          </span>
                        </div>

                        <div className="text-slate-600 text-[11px] bg-white p-1.5 rounded border border-slate-100 overflow-x-auto">
                          Args: {JSON.stringify(tc.arguments)}
                        </div>

                        {tc.result && (
                          <div
                            className={`flex items-start gap-1.5 p-1.5 rounded text-[11px] ${
                              tc.result.success
                                ? 'bg-emerald-50 text-emerald-900 border border-emerald-200'
                                : 'bg-rose-50 text-rose-900 border border-rose-200'
                            }`}
                          >
                            {tc.result.success ? (
                              <CheckCircle className="w-3.5 h-3.5 text-emerald-600 shrink-0 mt-0.5" />
                            ) : (
                              <XCircle className="w-3.5 h-3.5 text-rose-600 shrink-0 mt-0.5" />
                            )}
                            <div>
                              <span>{tc.result.message || tc.result.error}</span>
                            </div>
                          </div>
                        )}
                      </div>
                    ))}
                  </div>
                )}

                {/* Pending Confirmation Box (Risk Manager Gate) */}
                {msg.pendingConfirmation && (
                  <div className="mt-3 p-3 bg-rose-50 border-2 border-rose-300 rounded-xl space-y-2">
                    <div className="flex items-center gap-2 text-rose-800 font-bold text-xs uppercase tracking-wide">
                      <AlertOctagon className="w-4 h-4 text-rose-600" />
                      <span>Confirmation Required (High Risk Action)</span>
                    </div>
                    <p className="text-xs text-rose-900">
                      C2 is requesting permission to execute{' '}
                      <span className="font-mono font-bold bg-white px-1 py-0.5 rounded border border-rose-200">
                        {msg.pendingConfirmation.tool}({JSON.stringify(msg.pendingConfirmation.arguments)})
                      </span>
                      . This will permanently modify or delete data.
                    </p>
                    <div className="flex items-center gap-2 pt-1">
                      <button
                        id="confirm-action-btn"
                        onClick={() => onConfirmAction(msg.pendingConfirmation!)}
                        className="px-3 py-1.5 bg-rose-600 hover:bg-rose-700 text-white rounded-lg text-xs font-semibold shadow-xs transition-colors cursor-pointer"
                      >
                        Yes, Execute
                      </button>
                      <button
                        id="cancel-action-btn"
                        onClick={() => onCancelAction(msg.pendingConfirmation!)}
                        className="px-3 py-1.5 bg-white hover:bg-slate-100 text-slate-700 border border-slate-300 rounded-lg text-xs font-semibold transition-colors cursor-pointer"
                      >
                        No, Cancel
                      </button>
                    </div>
                  </div>
                )}
              </div>
            </div>
          );
        })
      )}
      <div ref={scrollEndRef} />
    </div>
  );
};
