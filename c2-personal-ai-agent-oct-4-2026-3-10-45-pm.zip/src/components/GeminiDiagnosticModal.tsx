import React, { useState, useEffect } from 'react';
import { 
  Sparkles, 
  ShieldCheck, 
  CheckCircle2, 
  AlertCircle, 
  Zap, 
  RefreshCw, 
  X, 
  Cpu, 
  Lock, 
  HelpCircle,
  Play,
  Key
} from 'lucide-react';

interface GeminiDiagnosticModalProps {
  isOpen: boolean;
  onClose: () => void;
  onOpenKeyManager?: () => void;
}

interface GeminiStatusData {
  configured: boolean;
  tier: string;
  primaryModel: string;
  fallbackModel: string;
  liveVoiceModel: string;
  billingRequired: boolean;
  security: string;
}

interface GeminiTestResult {
  success: boolean;
  tier: string;
  model: string;
  prompt?: string;
  response?: string;
  latencyMs: number;
  billingRequired: boolean;
  error?: string;
  message?: string;
  suggestion?: string;
}

export const GeminiDiagnosticModal: React.FC<GeminiDiagnosticModalProps> = ({
  isOpen,
  onClose,
  onOpenKeyManager,
}) => {
  const [status, setStatus] = useState<GeminiStatusData | null>(null);
  const [isLoadingStatus, setIsLoadingStatus] = useState(false);
  const [testPrompt, setTestPrompt] = useState('Hello C2! Confirm you are connected to Gemini Free Tier.');
  const [testResult, setTestResult] = useState<GeminiTestResult | null>(null);
  const [isTesting, setIsTesting] = useState(false);

  useEffect(() => {
    if (isOpen) {
      fetchStatus();
    }
  }, [isOpen]);

  const fetchStatus = async () => {
    setIsLoadingStatus(true);
    try {
      const res = await fetch('/api/c2/gemini/status');
      const data = await res.json();
      setStatus(data);
    } catch (e) {
      console.error('Error fetching Gemini status:', e);
    } finally {
      setIsLoadingStatus(false);
    }
  };

  const handleRunTest = async () => {
    setIsTesting(true);
    setTestResult(null);
    try {
      const res = await fetch('/api/c2/gemini/test', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ prompt: testPrompt }),
      });
      const data = await res.json();
      setTestResult(data);
    } catch (e: any) {
      setTestResult({
        success: false,
        tier: 'Free Tier',
        model: 'gemini-3.8-flash',
        latencyMs: 0,
        billingRequired: false,
        error: 'NETWORK_ERROR',
        message: e?.message || 'Could not reach server diagnostic endpoint.',
      });
    } finally {
      setIsTesting(false);
    }
  };

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/70 backdrop-blur-md animate-in fade-in duration-200">
      <div 
        className="w-full max-w-xl bg-slate-900/95 border border-white/10 rounded-2xl shadow-2xl overflow-hidden text-white flex flex-col max-h-[90vh]"
        role="dialog"
        aria-modal="true"
      >
        {/* Modal Header */}
        <div className="px-6 py-4 border-b border-white/10 flex items-center justify-between bg-white/[0.02]">
          <div className="flex items-center gap-3">
            <div className="w-9 h-9 rounded-xl bg-gradient-to-tr from-emerald-600 to-teal-500 flex items-center justify-center shadow-lg shadow-emerald-600/30">
              <Sparkles className="w-5 h-5 text-white" />
            </div>
            <div>
              <h2 className="text-base font-semibold tracking-tight text-white flex items-center gap-2">
                <span>Gemini Free-Tier Integration</span>
                <span className="text-[10px] uppercase font-mono px-2 py-0.5 rounded-full bg-emerald-500/20 text-emerald-300 border border-emerald-500/30">
                  Zero Billing
                </span>
              </h2>
              <p className="text-xs text-slate-400">
                Server-side API key configuration & real-time Free Tier diagnostics
              </p>
            </div>
          </div>
          <button
            id="close-gemini-diagnostic-modal-btn"
            onClick={onClose}
            className="p-1.5 rounded-lg text-slate-400 hover:text-white hover:bg-white/10 transition-colors cursor-pointer"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Modal Body */}
        <div className="p-6 overflow-y-auto space-y-5 text-xs text-slate-300 leading-relaxed">
          {/* Billing & Model Compliance Card */}
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
            <div className="p-3.5 rounded-xl bg-white/[0.03] border border-white/10">
              <div className="flex items-center gap-2 text-emerald-400 font-semibold mb-1">
                <ShieldCheck className="w-4 h-4" />
                <span>Strict Free-Tier Tier</span>
              </div>
              <p className="text-slate-400 text-[11px]">
                Paid models (e.g. Pro, Veo, Lyria) and billing account upgrades are strictly blocked.
              </p>
            </div>

            <div className="p-3.5 rounded-xl bg-white/[0.03] border border-white/10">
              <div className="flex items-center gap-2 text-violet-400 font-semibold mb-1">
                <Lock className="w-4 h-4" />
                <span>Server-Side Key Isolation</span>
              </div>
              <p className="text-slate-400 text-[11px]">
                Key is injected from AI Studio Secrets into server environment. Never exposed to browser.
              </p>
            </div>
          </div>

          {/* Active Model Table */}
          <div className="p-3.5 rounded-xl bg-slate-950/60 border border-white/10 space-y-2">
            <div className="text-xs font-semibold text-white flex items-center justify-between">
              <span className="flex items-center gap-1.5">
                <Cpu className="w-3.5 h-3.5 text-indigo-400" />
                Configured Free-Tier Models
              </span>
              <button
                onClick={fetchStatus}
                disabled={isLoadingStatus}
                className="text-[11px] text-slate-400 hover:text-white flex items-center gap-1 cursor-pointer"
              >
                <RefreshCw className={`w-3 h-3 ${isLoadingStatus ? 'animate-spin' : ''}`} />
                Refresh
              </button>
            </div>

            <div className="space-y-1.5 font-mono text-[11px]">
              <div className="flex items-center justify-between p-2 rounded-lg bg-white/[0.02]">
                <span className="text-slate-400">Primary Brain (Chat / Reasoning):</span>
                <span className="text-emerald-400 font-bold">gemini-3.8-flash</span>
              </div>
              <div className="flex items-center justify-between p-2 rounded-lg bg-white/[0.02]">
                <span className="text-slate-400">Fast Fallback Brain:</span>
                <span className="text-sky-400 font-bold">gemini-3.1-flash-lite</span>
              </div>
              <div className="flex items-center justify-between p-2 rounded-lg bg-white/[0.02]">
                <span className="text-slate-400">Live Voice Pipeline:</span>
                <span className="text-purple-400 font-bold">gemini-3.1-flash-live-preview</span>
              </div>
            </div>
          </div>

          {/* Interactive Test Request Box */}
          <div className="p-4 rounded-xl bg-white/[0.02] border border-white/10 space-y-3">
            <div className="flex items-center justify-between">
              <span className="text-xs font-semibold text-white flex items-center gap-1.5">
                <Zap className="w-3.5 h-3.5 text-amber-400" />
                Test Gemini Free-Tier Request
              </span>
              {testResult && (
                <span
                  className={`text-[10px] font-mono px-2 py-0.5 rounded-full ${
                    testResult.success
                      ? 'bg-emerald-500/20 text-emerald-300 border border-emerald-500/30'
                      : 'bg-rose-500/20 text-rose-300 border border-rose-500/30'
                  }`}
                >
                  {testResult.success ? `Success (${testResult.latencyMs}ms)` : 'Diagnostics Recorded'}
                </span>
              )}
            </div>

            <div className="flex gap-2">
              <input
                type="text"
                value={testPrompt}
                onChange={(e) => setTestPrompt(e.target.value)}
                placeholder="Enter prompt to test with Gemini Free Tier..."
                className="flex-1 bg-black/40 border border-white/15 rounded-lg px-3 py-2 text-xs text-white placeholder-slate-500 focus:outline-hidden focus:border-violet-500 font-sans"
              />
              <button
                id="run-gemini-test-btn"
                onClick={handleRunTest}
                disabled={isTesting || !testPrompt.trim()}
                className="px-3.5 py-2 rounded-lg bg-emerald-600 hover:bg-emerald-500 disabled:opacity-50 text-white font-medium text-xs flex items-center gap-1.5 transition-all shadow-md cursor-pointer shrink-0"
              >
                {isTesting ? (
                  <>
                    <RefreshCw className="w-3.5 h-3.5 animate-spin" />
                    <span>Testing...</span>
                  </>
                ) : (
                  <>
                    <Play className="w-3.5 h-3.5 fill-white" />
                    <span>Send Test</span>
                  </>
                )}
              </button>
            </div>

            {/* Test Result Display */}
            {testResult && (
              <div
                className={`p-3 rounded-lg border text-xs space-y-1.5 ${
                  testResult.success
                    ? 'bg-emerald-950/40 border-emerald-500/30 text-emerald-200'
                    : 'bg-rose-950/40 border-rose-500/30 text-rose-200'
                }`}
              >
                <div className="flex items-center justify-between font-semibold">
                  <span className="flex items-center gap-1.5">
                    {testResult.success ? (
                      <CheckCircle2 className="w-4 h-4 text-emerald-400" />
                    ) : (
                      <AlertCircle className="w-4 h-4 text-rose-400" />
                    )}
                    <span>{testResult.success ? 'Gemini Response Received' : 'API Request Notice'}</span>
                  </span>
                  <span className="font-mono text-[10px] text-slate-400">
                    Model: {testResult.model}
                  </span>
                </div>

                {testResult.response && (
                  <div className="p-2 rounded bg-black/30 text-slate-200 font-sans leading-relaxed">
                    "{testResult.response}"
                  </div>
                )}

                {testResult.error && (
                  <div className="space-y-1 text-[11px]">
                    <div className="font-mono text-rose-300">Error: {testResult.error}</div>
                    {testResult.suggestion && (
                      <div className="text-amber-200 bg-amber-950/40 p-2 rounded border border-amber-500/20">
                        {testResult.suggestion}
                      </div>
                    )}
                  </div>
                )}
              </div>
            )}
          </div>

          {/* Security & Instructions Notice */}
          <div className="flex items-start gap-2.5 p-3 rounded-xl bg-violet-950/30 border border-violet-500/20 text-slate-300 text-[11px]">
            <HelpCircle className="w-4 h-4 text-violet-400 shrink-0 mt-0.5" />
            <div>
              <span className="font-semibold text-violet-300 block mb-0.5">
                How to update your Free-Tier Gemini API Key:
              </span>
              <p className="text-slate-400">
                1. Open <strong className="text-white">Settings &gt; Secrets</strong> in the AI Studio menu.<br />
                2. Set or update the secret named <code className="bg-white/10 px-1 py-0.5 rounded text-white font-mono">GEMINI_API_KEY</code> with your free key from Google AI Studio.<br />
                3. The server automatically loads it securely without any billing or source code changes.
              </p>
            </div>
          </div>
        </div>

        {/* Modal Footer */}
        <div className="px-6 py-3 border-t border-white/10 flex items-center justify-between bg-white/[0.02] text-xs">
          <span className="text-slate-400 font-mono text-[11px]">
            Billing Required: <strong className="text-emerald-400">NO (100% Free Tier)</strong>
          </span>
          <div className="flex items-center gap-2">
            {onOpenKeyManager && (
              <button
                id="c2-open-key-manager-from-diag"
                onClick={() => {
                  onClose();
                  onOpenKeyManager();
                }}
                className="px-3 py-1.5 rounded-lg bg-violet-600 hover:bg-violet-500 text-white font-medium transition-colors flex items-center gap-1.5 cursor-pointer"
              >
                <Key className="w-3.5 h-3.5" />
                <span>Manage Keys</span>
              </button>
            )}
            <button
              onClick={onClose}
              className="px-4 py-1.5 rounded-lg bg-white/10 hover:bg-white/20 text-white font-medium transition-colors cursor-pointer"
            >
              Close
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};
