import React, { useState } from 'react';
import { MemoryItem, UserProfile, MemoryCategory } from '../types';
import { 
  Database, 
  Trash2, 
  UserPlus, 
  UserCheck, 
  ShieldCheck, 
  ToggleLeft, 
  ToggleRight, 
  Plus, 
  X, 
  Check, 
  Key, 
  Clock 
} from 'lucide-react';

interface MemoryModalProps {
  isOpen: boolean;
  onClose: () => void;
  currentUser: UserProfile;
  allUsers: UserProfile[];
  memories: MemoryItem[];
  isMemoryEnabled: boolean;
  onToggleMemory: (enabled: boolean) => void;
  onSwitchUser: (userId: string) => void;
  onCreateUser: (displayName: string, language: 'English' | 'Hindi' | 'Hinglish') => void;
  onDeleteMemory: (id: string) => void;
  onClearAll: () => void;
  onAddMemory: (category: MemoryCategory, key: string, value: string) => void;
}

export const MemoryModal: React.FC<MemoryModalProps> = ({
  isOpen,
  onClose,
  currentUser,
  allUsers,
  memories,
  isMemoryEnabled,
  onToggleMemory,
  onSwitchUser,
  onCreateUser,
  onDeleteMemory,
  onClearAll,
  onAddMemory,
}) => {
  const [newKey, setNewKey] = useState('');
  const [newVal, setNewVal] = useState('');
  const [newCat, setNewCat] = useState<MemoryCategory>('preference');

  const [newUserName, setNewUserName] = useState('');
  const [newUserLang, setNewUserLang] = useState<'English' | 'Hindi' | 'Hinglish'>('Hinglish');
  const [showAddUser, setShowAddUser] = useState(false);

  if (!isOpen) return null;

  const handleAddSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newKey.trim() || !newVal.trim()) return;
    onAddMemory(newCat, newKey.trim(), newVal.trim());
    setNewKey('');
    setNewVal('');
  };

  const handleCreateUserSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newUserName.trim()) return;
    onCreateUser(newUserName.trim(), newUserLang);
    setNewUserName('');
    setShowAddUser(false);
  };

  const getCategoryBadge = (cat: MemoryCategory) => {
    switch (cat) {
      case 'profile':
        return 'bg-blue-50 text-blue-700 border-blue-200';
      case 'preference':
        return 'bg-purple-50 text-purple-700 border-purple-200';
      case 'conversation':
        return 'bg-amber-50 text-amber-700 border-amber-200';
      case 'task':
        return 'bg-emerald-50 text-emerald-700 border-emerald-200';
      case 'long_term':
        return 'bg-indigo-50 text-indigo-700 border-indigo-200';
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/60 backdrop-blur-xs">
      <div className="bg-white rounded-2xl max-w-2xl w-full max-h-[85vh] flex flex-col shadow-2xl border border-slate-200 overflow-hidden animate-in fade-in zoom-in-95 duration-150">
        {/* Header */}
        <div className="px-6 py-4 border-b border-slate-200 flex items-center justify-between bg-slate-50">
          <div className="flex items-center gap-2.5">
            <div className="w-8 h-8 rounded-lg bg-purple-600 text-white flex items-center justify-center">
              <Database className="w-4 h-4" />
            </div>
            <div>
              <h3 className="font-semibold text-slate-900 text-base">C2 Persistent Memory Vault</h3>
              <p className="text-xs text-slate-500">
                User-isolated, privacy-first cross-session memory architecture
              </p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-1 rounded-lg text-slate-400 hover:text-slate-700 hover:bg-slate-200 transition-colors cursor-pointer"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Content */}
        <div className="flex-1 overflow-y-auto p-6 space-y-6">
          {/* User Account Authentication Bar */}
          <div className="bg-slate-50 p-4 rounded-xl border border-slate-200 space-y-3">
            <div className="flex items-center justify-between">
              <div className="text-xs font-bold uppercase tracking-wider text-slate-600 flex items-center gap-1.5">
                <UserCheck className="w-4 h-4 text-indigo-600" />
                <span>Authenticated User Account</span>
              </div>
              <button
                onClick={() => setShowAddUser(!showAddUser)}
                className="text-xs text-indigo-600 hover:text-indigo-700 font-semibold flex items-center gap-1 cursor-pointer"
              >
                <UserPlus className="w-3.5 h-3.5" />
                <span>{showAddUser ? 'Cancel' : 'New User Account'}</span>
              </button>
            </div>

            <div className="flex flex-wrap items-center gap-2">
              {allUsers.map((u) => (
                <button
                  key={u.id}
                  onClick={() => onSwitchUser(u.id)}
                  className={`px-3 py-1.5 rounded-lg text-xs font-semibold flex items-center gap-2 transition-all cursor-pointer border ${
                    u.id === currentUser.id
                      ? 'bg-indigo-600 text-white border-indigo-700 shadow-xs'
                      : 'bg-white text-slate-700 border-slate-200 hover:bg-slate-100'
                  }`}
                >
                  <span>{u.displayName}</span>
                  <span className="text-[10px] opacity-75 font-mono">({u.preferredLanguage})</span>
                  {u.id === currentUser.id && <Check className="w-3 h-3" />}
                </button>
              ))}
            </div>

            {showAddUser && (
              <form onSubmit={handleCreateUserSubmit} className="pt-2 border-t border-slate-200 flex flex-wrap gap-2 items-center">
                <input
                  type="text"
                  placeholder="Display Name (e.g. Priya)"
                  value={newUserName}
                  onChange={(e) => setNewUserName(e.target.value)}
                  className="px-3 py-1.5 rounded-lg text-xs border border-slate-300 focus:outline-hidden focus:border-indigo-500 bg-white"
                />
                <select
                  value={newUserLang}
                  onChange={(e) => setNewUserLang(e.target.value as any)}
                  className="px-2.5 py-1.5 rounded-lg text-xs border border-slate-300 bg-white"
                >
                  <option value="Hinglish">Hinglish</option>
                  <option value="English">English</option>
                  <option value="Hindi">Hindi</option>
                </select>
                <button
                  type="submit"
                  className="px-3 py-1.5 bg-indigo-600 hover:bg-indigo-700 text-white rounded-lg text-xs font-semibold cursor-pointer"
                >
                  Create Account
                </button>
              </form>
            )}
          </div>

          {/* Controls: Toggle Memory & Clear All */}
          <div className="flex items-center justify-between flex-wrap gap-3 pb-2 border-b border-slate-100">
            <div className="flex items-center gap-2">
              <button
                onClick={() => onToggleMemory(!isMemoryEnabled)}
                className="flex items-center gap-1.5 text-xs font-semibold cursor-pointer text-slate-700"
              >
                {isMemoryEnabled ? (
                  <ToggleRight className="w-6 h-6 text-emerald-600" />
                ) : (
                  <ToggleLeft className="w-6 h-6 text-slate-400" />
                )}
                <span>Memory System: {isMemoryEnabled ? 'Active' : 'Disabled'}</span>
              </button>
            </div>

            <button
              onClick={onClearAll}
              className="text-xs text-rose-600 hover:text-rose-700 font-semibold flex items-center gap-1 cursor-pointer hover:bg-rose-50 px-2.5 py-1.5 rounded-lg border border-transparent hover:border-rose-200 transition-colors"
            >
              <Trash2 className="w-3.5 h-3.5" />
              <span>Clear All Memories for {currentUser.displayName}</span>
            </button>
          </div>

          {/* Memories List */}
          <div className="space-y-2">
            <div className="text-xs font-semibold text-slate-700 flex items-center justify-between">
              <span>Saved Memory Items ({memories.length})</span>
              <span className="text-[11px] text-slate-400">Isolated to User: {currentUser.id}</span>
            </div>

            {memories.length === 0 ? (
              <div className="p-6 text-center bg-slate-50 rounded-xl border border-slate-200 text-xs text-slate-500">
                No memories stored for this user account. Tell C2 to remember something (e.g. "C2, remember that when I say browser, I mean Chrome").
              </div>
            ) : (
              <div className="space-y-2 max-h-56 overflow-y-auto pr-1">
                {memories.map((m) => (
                  <div
                    key={m.id}
                    className="p-3 bg-white rounded-xl border border-slate-200 flex items-center justify-between gap-3 text-xs shadow-2xs hover:border-slate-300 transition-colors"
                  >
                    <div className="space-y-1">
                      <div className="flex items-center gap-2">
                        <span className={`px-1.5 py-0.5 rounded text-[10px] font-bold uppercase border ${getCategoryBadge(m.category)}`}>
                          {m.category}
                        </span>
                        <span className="font-mono font-bold text-slate-900">{m.key}</span>
                      </div>
                      <div className="text-slate-700">{m.value}</div>
                    </div>
                    <button
                      title="Delete this memory item"
                      onClick={() => onDeleteMemory(m.id)}
                      className="p-1.5 rounded-lg text-slate-400 hover:text-rose-600 hover:bg-rose-50 transition-colors cursor-pointer shrink-0"
                    >
                      <Trash2 className="w-4 h-4" />
                    </button>
                  </div>
                ))}
              </div>
            )}
          </div>

          {/* Add Manual Memory Form */}
          <form onSubmit={handleAddSubmit} className="bg-slate-50 p-4 rounded-xl border border-slate-200 space-y-3">
            <div className="text-xs font-bold text-slate-700 flex items-center gap-1.5">
              <Plus className="w-3.5 h-3.5 text-indigo-600" />
              <span>Add Custom Memory Record</span>
            </div>
            <div className="grid grid-cols-1 sm:grid-cols-3 gap-2">
              <select
                value={newCat}
                onChange={(e) => setNewCat(e.target.value as any)}
                className="px-2.5 py-1.5 rounded-lg text-xs border border-slate-300 bg-white"
              >
                <option value="preference">Preference</option>
                <option value="profile">Profile</option>
                <option value="long_term">Long-Term</option>
                <option value="task">Task State</option>
              </select>
              <input
                type="text"
                placeholder="Key (e.g. browser)"
                value={newKey}
                onChange={(e) => setNewKey(e.target.value)}
                className="px-3 py-1.5 rounded-lg text-xs border border-slate-300 bg-white"
              />
              <input
                type="text"
                placeholder="Value (e.g. Chrome)"
                value={newVal}
                onChange={(e) => setNewVal(e.target.value)}
                className="px-3 py-1.5 rounded-lg text-xs border border-slate-300 bg-white"
              />
            </div>
            <div className="flex justify-end">
              <button
                type="submit"
                className="px-3 py-1.5 bg-purple-600 hover:bg-purple-700 text-white rounded-lg text-xs font-semibold transition-colors cursor-pointer"
              >
                Save to Vault
              </button>
            </div>
          </form>
        </div>

        {/* Footer */}
        <div className="px-6 py-3 bg-slate-50 border-t border-slate-200 flex items-center justify-between text-xs text-slate-500">
          <div className="flex items-center gap-1.5">
            <ShieldCheck className="w-4 h-4 text-emerald-600" />
            <span>Privacy Rule: Sensitive tokens/passwords are never saved in conversational memory.</span>
          </div>
          <button
            onClick={onClose}
            className="px-4 py-1.5 bg-slate-900 text-white rounded-lg text-xs font-medium hover:bg-slate-800 transition-colors cursor-pointer"
          >
            Done
          </button>
        </div>
      </div>
    </div>
  );
};
