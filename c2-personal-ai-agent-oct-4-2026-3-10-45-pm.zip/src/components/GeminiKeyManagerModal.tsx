import React, { useState, useEffect } from 'react';
import {
  Key,
  Sparkles,
  ShieldCheck,
  AlertTriangle,
  CheckCircle2,
  ExternalLink,
  Volume2,
  RefreshCw,
  X,
  Eye,
  EyeOff,
  Copy,
  Plus,
  Zap,
  HelpCircle,
  Play,
} from 'lucide-react';
import { ApiKeyStatus } from '../types';
import { safeStorage } from '../utils/safeStorage';

export type KeyModalMode = 'onboarding' | 'quota_exhausted' | 'settings';

interface GeminiKeyManagerModalProps {
  isOpen: boolean;
  mode: KeyModalMode;
  onClose: () => void;
  onKeySaved: (status: ApiKeyStatus) => void;
}

export const GeminiKeyManagerModal: React.FC<GeminiKeyManagerModalProps> = ({
  isOpen,
  mode,
  onClose,
  onKeySaved,
}) => {
  const [primaryKey, setPrimaryKey] = useState('');
  const [backupKey, setBackupKey] = useState('');
  const [showPrimaryKey, setShowPrimaryKey] = useState(false);
  const [showBackupKey, setShowBackupKey] = useState(false);
  const [showBackupSection, setShowBackupSection] = useState(false);

  const [isLoading, setIsLoading] = useState(false);
  const [isTestingVoice, setIsTestingVoice] = useState(false);
  const [voiceTestMessage, setVoiceTestMessage] = useState<string | null>(null);

  const [error, setError] = useState<string | null>(null);
  const [successMessage, setSuccessMessage] = useState<string | null>(null);
  const [currentStatus, setCurrentStatus] = useState<ApiKeyStatus | null>(null);

  useEffect(() => {
    if (isOpen) {
      setError(null);
      setSuccessMessage(null);
      setVoiceTestMessage(null);
      fetchKeyStatus();
    }
  }, [isOpen, mode]);

  const fetchKeyStatus = async () => {
    try {
      const res = await fetch('/api/c2/keys/status');
      const data: ApiKeyStatus = await res.json();
      setCurrentStatus(data);
      if (data.hasBackupKey) {
        setShowBackupSection(true);
      }
    } catch (e) {
      console.error('Failed to fetch key status:', e);
    }
  };

  const handleSaveKeys = async (e?: React.FormEvent) => {
    if (e) e.preventDefault();
    if (!primaryKey.trim()) {
      setError('Please enter your Gemini API key.');
      return;
    }

    setIsLoading(true);
    setError(null);
    setSuccessMessage(null);

    try {
      const endpoint = mode === 'quota_exhausted' ? '/api/c2/keys/replace-active' : '/api/c2/keys/save';
      const payload =
        mode === 'quota_exhausted'
          ? { newKey: primaryKey.trim() }
          : { primaryKey: primaryKey.trim(), backupKey: backupKey.trim() || undefined };

      const res = await fetch(endpoint, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(payload),
      });

      const data = await res.json();

      if (!res.ok || !data.success) {
        setError(data.message || 'The Gemini API key could not be verified. Please check your key.');
        return;
      }

      setSuccessMessage(data.message || 'Gemini API key verified & activated!');
      setPrimaryKey('');
      setBackupKey('');

      // Mark onboarding as completed so it never asks automatically again
      safeStorage.setItem('c2_api_key_onboarding_completed', 'true');
      safeStorage.setItem('c2_has_saved_key', 'true');

      // Refresh status
      await fetchKeyStatus();

      if (currentStatus) {
        onKeySaved({
          ...currentStatus,
          hasKey: true,
          quotaExhausted: false,
          liveVoiceReady: true,
        });
      }

      // Automatically play voice preview test to demonstrate Gemini Voice
      handleTestVoice();

      // Auto close after brief celebration
      setTimeout(() => {
        onClose();
      }, 1800);
    } catch (err: any) {
      setError(err?.message || 'Network error connecting to verification endpoint.');
    } finally {
      setIsLoading(false);
    }
  };

  const handleSkipOnboarding = () => {
    // Record that user chose to skip for now so it will never ask automatically again
    safeStorage.setItem('c2_api_key_onboarding_completed', 'true');
    onClose();
  };

  const handleTestVoice = async () => {
    setIsTestingVoice(true);
    setVoiceTestMessage('Synthesizing sample in Gemini Voice...');
    try {
      const res = await fetch('/api/c2/voice/preview', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          voice: 'Aoede',
          text: 'Hello Master! I am C2, powered by Gemini Voice. All systems are operational.',
        }),
      });
      const data = await res.json();

      if (data.audio) {
        // Play PCM 24kHz audio
        playBase64Pcm(data.audio);
        setVoiceTestMessage('Gemini Voice playing: "Hello Master! I am C2, powered by Gemini Voice."');
      } else {
        setVoiceTestMessage(data.message || 'Gemini Voice engine verified.');
      }
    } catch (e: any) {
      setVoiceTestMessage('Voice test notice: ' + (e?.message || 'Ready in Live stream'));
    } finally {
      setIsTestingVoice(false);
    }
  };

  const playBase64Pcm = (base64Audio: string) => {
    try {
      const binaryString = window.atob(base64Audio);
      const bytes = new Uint8Array(binaryString.length);
      for (let i = 0; i < binaryString.length; i++) {
        bytes[i] = binaryString.charCodeAt(i);
      }
      const pcm16 = new Int16Array(bytes.buffer);
      const float32 = new Float32Array(pcm16.length);
      for (let i = 0; i < pcm16.length; i++) {
        float32[i] = pcm16[i] / 32768.0;
      }

      const AudioCtx = window.AudioContext || (window as any).webkitAudioContext;
      const ctx = new AudioCtx({ sampleRate: 24000 });
      const buffer = ctx.createBuffer(1, float32.length, 24000);
      buffer.getChannelData(0).set(float32);

      const source = ctx.createBufferSource();
      source.buffer = buffer;
      source.connect(ctx.destination);
      source.start();
    } catch (err) {
      console.warn('Could not play preview audio PCM:', err);
    }
  };

  const handlePasteKey = async (isBackup: boolean = false) => {
    try {
      const text = await navigator.clipboard.readText();
      if (text) {
        if (isBackup) {
          setBackupKey(text.trim());
        } else {
          setPrimaryKey(text.trim());
        }
      }
    } catch (e) {
      console.log('Clipboard access not permitted');
    }
  };

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-md animate-in fade-in duration-200">
      <div
        id="c2-gemini-key-modal"
        className="w-full max-w-lg bg-slate-900/95 border border-violet-500/30 rounded-2xl shadow-2xl overflow-hidden flex flex-col max-h-[90vh]"
      >
        {/* Header */}
        <div className="p-5 border-b border-white/10 flex items-start justify-between bg-gradient-to-r from-violet-950/50 via-slate-900 to-indigo-950/40">
          <div className="flex items-center gap-3">
            <div
              className={`w-10 h-10 rounded-xl flex items-center justify-center shadow-lg border ${
                mode === 'quota_exhausted'
                  ? 'bg-gradient-to-br from-amber-600 to-rose-600 border-amber-400/40 shadow-rose-950/50'
                  : 'bg-gradient-to-br from-violet-600 to-fuchsia-600 border-violet-400/40 shadow-violet-950/50'
              }`}
            >
              {mode === 'quota_exhausted' ? (
                <AlertTriangle className="w-5 h-5 text-white animate-pulse" />
              ) : (
                <Key className="w-5 h-5 text-white" />
              )}
            </div>
            <div>
              <h2 className="text-base font-bold text-white flex items-center gap-2">
                {mode === 'onboarding' && 'Activate Gemini Voice & AI Engine'}
                {mode === 'quota_exhausted' && 'Gemini Free-Tier Quota Reached'}
                {mode === 'settings' && 'Gemini API Keys & Voice Settings'}
                <span className="text-[10px] font-mono uppercase px-2 py-0.5 rounded-full bg-emerald-500/20 text-emerald-300 border border-emerald-500/30">
                  Zero Billing
                </span>
              </h2>
              <p className="text-xs text-slate-400 mt-0.5">
                {mode === 'onboarding' &&
                  'Connect your free Gemini key once. C2 will save it and never ask again.'}
                {mode === 'quota_exhausted' &&
                  'Your free quota was reached. Enter another Gemini API key to continue without waiting.'}
                {mode === 'settings' &&
                  'Manage your primary & backup keys for automatic quota fallback.'}
              </p>
            </div>
          </div>

          <button
            onClick={mode === 'onboarding' ? handleSkipOnboarding : onClose}
            className="p-1 rounded-lg text-slate-400 hover:text-white hover:bg-white/10 transition-colors cursor-pointer"
            title="Close"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Content Area */}
        <div className="p-5 overflow-y-auto space-y-4">
          {/* Quota Exhausted Banner */}
          {mode === 'quota_exhausted' && (
            <div className="p-3.5 rounded-xl bg-rose-950/40 border border-rose-500/40 text-rose-200 text-xs flex items-start gap-2.5">
              <AlertTriangle className="w-4 h-4 text-rose-400 shrink-0 mt-0.5" />
              <div>
                <p className="font-semibold text-rose-100">Quota Limit Exceeded on Active Key</p>
                <p className="text-rose-300/80 mt-0.5">
                  Google Gemini's free tier rate limit was reached on your previous key. Enter another free key below to restore Gemini Voice immediately.
                </p>
              </div>
            </div>
          )}

          {/* Current Key Status Card (if settings or key exists) */}
          {currentStatus?.hasKey && mode !== 'quota_exhausted' && (
            <div className="p-3 rounded-xl bg-white/5 border border-white/10 space-y-2 text-xs">
              <div className="flex items-center justify-between">
                <span className="text-slate-400 font-medium">Active Gemini Key:</span>
                <span className="font-mono text-emerald-400 flex items-center gap-1.5">
                  <span className="w-1.5 h-1.5 rounded-full bg-emerald-400 animate-pulse" />
                  {currentStatus.primaryKeyMasked || 'Configured'}
                  {currentStatus.activeKeyType === 'backup' && ' (Backup Active)'}
                </span>
              </div>
              {currentStatus.hasBackupKey && (
                <div className="flex items-center justify-between text-slate-400">
                  <span>Backup Key (Auto-fallback):</span>
                  <span className="font-mono text-cyan-300">
                    {currentStatus.backupKeyMasked || 'Configured'}
                  </span>
                </div>
              )}
            </div>
          )}

          {/* Key Form */}
          <form onSubmit={handleSaveKeys} className="space-y-4">
            {/* Primary Key Input */}
            <div className="space-y-1.5">
              <div className="flex items-center justify-between text-xs">
                <label className="font-medium text-slate-200 flex items-center gap-1.5">
                  <Key className="w-3.5 h-3.5 text-violet-400" />
                  {mode === 'quota_exhausted' ? 'New / Replacement Gemini API Key' : 'Gemini API Key'}
                  <span className="text-rose-400">*</span>
                </label>
                <button
                  type="button"
                  onClick={() => handlePasteKey(false)}
                  className="text-violet-400 hover:text-violet-300 text-[11px] flex items-center gap-1 cursor-pointer"
                >
                  <Copy className="w-3 h-3" /> Paste
                </button>
              </div>

              <div className="relative flex items-center">
                <input
                  id="gemini-primary-api-key-input"
                  type={showPrimaryKey ? 'text' : 'password'}
                  value={primaryKey}
                  onChange={(e) => setPrimaryKey(e.target.value)}
                  placeholder="AIzaSy..."
                  autoComplete="off"
                  className="w-full px-3.5 py-2.5 bg-black/40 border border-violet-500/30 rounded-xl text-white text-xs font-mono placeholder:text-slate-600 focus:outline-hidden focus:border-violet-400 transition-colors pr-10"
                />
                <button
                  type="button"
                  onClick={() => setShowPrimaryKey(!showPrimaryKey)}
                  className="absolute right-3 text-slate-400 hover:text-slate-200 cursor-pointer"
                  title={showPrimaryKey ? 'Hide Key' : 'Show Key'}
                >
                  {showPrimaryKey ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
                </button>
              </div>
            </div>

            {/* Optional Backup Key Section (Automatic Quota Protection) */}
            {mode !== 'quota_exhausted' && (
              <div className="space-y-2 pt-1">
                {!showBackupSection ? (
                  <button
                    type="button"
                    onClick={() => setShowBackupSection(true)}
                    className="text-xs text-cyan-400 hover:text-cyan-300 flex items-center gap-1.5 transition-colors cursor-pointer"
                  >
                    <Plus className="w-3.5 h-3.5" />
                    <span>Add Backup Key (Automatic quota fallback)</span>
                  </button>
                ) : (
                  <div className="p-3 rounded-xl bg-cyan-950/20 border border-cyan-500/20 space-y-2">
                    <div className="flex items-center justify-between text-xs">
                      <label className="font-medium text-cyan-200 flex items-center gap-1.5">
                        <Zap className="w-3.5 h-3.5 text-cyan-400" />
                        Secondary / Backup Key (Optional)
                      </label>
                      <button
                        type="button"
                        onClick={() => handlePasteKey(true)}
                        className="text-cyan-400 hover:text-cyan-300 text-[11px] flex items-center gap-1 cursor-pointer"
                      >
                        <Copy className="w-3 h-3" /> Paste
                      </button>
                    </div>

                    <div className="relative flex items-center">
                      <input
                        id="gemini-backup-api-key-input"
                        type={showBackupKey ? 'text' : 'password'}
                        value={backupKey}
                        onChange={(e) => setBackupKey(e.target.value)}
                        placeholder="AIzaSy... (Switched automatically if quota reached)"
                        autoComplete="off"
                        className="w-full px-3.5 py-2 bg-black/40 border border-cyan-500/30 rounded-xl text-white text-xs font-mono placeholder:text-slate-600 focus:outline-hidden focus:border-cyan-400 transition-colors pr-10"
                      />
                      <button
                        type="button"
                        onClick={() => setShowBackupKey(!showBackupKey)}
                        className="absolute right-3 text-slate-400 hover:text-slate-200 cursor-pointer"
                      >
                        {showBackupKey ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
                      </button>
                    </div>
                    <p className="text-[11px] text-cyan-300/70">
                      If primary key hits Google's free-tier quota (RESOURCE_EXHAUSTED), C2 will automatically rotate to this backup key with zero interruption.
                    </p>
                  </div>
                )}
              </div>
            )}

            {/* Error Message Display */}
            {error && (
              <div className="p-3 rounded-xl bg-rose-950/50 border border-rose-500/40 text-rose-300 text-xs flex items-start gap-2 animate-in fade-in">
                <AlertTriangle className="w-4 h-4 shrink-0 text-rose-400 mt-0.5" />
                <div>
                  <p className="font-semibold text-rose-200">Validation Error</p>
                  <p className="mt-0.5 text-rose-300/90">{error}</p>
                </div>
              </div>
            )}

            {/* Success Message Display */}
            {successMessage && (
              <div className="p-3 rounded-xl bg-emerald-950/50 border border-emerald-500/40 text-emerald-300 text-xs flex items-center gap-2 animate-in fade-in">
                <CheckCircle2 className="w-4 h-4 shrink-0 text-emerald-400" />
                <span className="font-medium text-emerald-200">{successMessage}</span>
              </div>
            )}

            {/* Actions */}
            <div className="flex items-center gap-2 pt-2">
              <button
                type="submit"
                id="gemini-key-save-btn"
                disabled={isLoading}
                className="flex-1 py-2.5 px-4 rounded-xl bg-gradient-to-r from-violet-600 via-fuchsia-600 to-indigo-600 hover:from-violet-500 hover:to-indigo-500 text-white font-medium text-xs flex items-center justify-center gap-2 transition-all shadow-lg shadow-violet-900/30 disabled:opacity-50 cursor-pointer"
              >
                {isLoading ? (
                  <>
                    <RefreshCw className="w-4 h-4 animate-spin" />
                    <span>Verifying with Google Gemini...</span>
                  </>
                ) : (
                  <>
                    <Sparkles className="w-4 h-4" />
                    <span>
                      {mode === 'quota_exhausted'
                        ? 'Verify & Resume Gemini Voice'
                        : 'Verify & Activate Gemini Voice'}
                    </span>
                  </>
                )}
              </button>

              {/* Skip option for first download onboarding */}
              {mode === 'onboarding' && (
                <button
                  type="button"
                  id="gemini-key-skip-btn"
                  onClick={handleSkipOnboarding}
                  className="py-2.5 px-3 rounded-xl bg-white/5 hover:bg-white/10 border border-white/10 text-slate-400 hover:text-slate-200 text-xs transition-colors cursor-pointer"
                  title="Continue using C2 Local Voice Engine for now"
                >
                  Skip for now
                </button>
              )}
            </div>
          </form>

          {/* Test Gemini Voice Button (for testing authentic Gemini 24kHz voice) */}
          {currentStatus?.hasKey && (
            <div className="pt-2 border-t border-white/10 flex flex-col gap-2">
              <div className="flex items-center justify-between">
                <span className="text-xs text-slate-300 font-medium flex items-center gap-1.5">
                  <Volume2 className="w-3.5 h-3.5 text-fuchsia-400" />
                  Gemini Voice Soundcheck
                </span>
                <button
                  type="button"
                  id="gemini-voice-test-btn"
                  onClick={handleTestVoice}
                  disabled={isTestingVoice}
                  className="px-3 py-1.5 rounded-lg bg-fuchsia-950/40 hover:bg-fuchsia-900/50 border border-fuchsia-500/40 text-fuchsia-300 font-medium text-xs flex items-center gap-1.5 transition-all cursor-pointer disabled:opacity-50"
                >
                  {isTestingVoice ? (
                    <RefreshCw className="w-3.5 h-3.5 animate-spin" />
                  ) : (
                    <Play className="w-3.5 h-3.5 fill-current" />
                  )}
                  <span>Test Gemini Voice (Aoede)</span>
                </button>
              </div>
              {voiceTestMessage && (
                <p className="text-[11px] text-fuchsia-200/80 bg-fuchsia-950/20 px-2.5 py-1 rounded-lg border border-fuchsia-500/20">
                  {voiceTestMessage}
                </p>
              )}
            </div>
          )}

          {/* Quick Helper / Get Free Key Link */}
          <div className="p-3.5 rounded-xl bg-slate-950/60 border border-white/10 space-y-2 text-xs">
            <div className="flex items-center justify-between text-slate-300">
              <span className="font-semibold flex items-center gap-1.5">
                <ShieldCheck className="w-4 h-4 text-emerald-400" />
                Free Tier • 100% Free Forever
              </span>
              <a
                href="https://aistudio.google.com/apikey"
                target="_blank"
                rel="noreferrer"
                className="text-violet-400 hover:text-violet-300 flex items-center gap-1 text-[11px] font-medium transition-colors"
              >
                Get Free API Key <ExternalLink className="w-3 h-3" />
              </a>
            </div>
            <ul className="text-[11px] text-slate-400 space-y-1 list-disc list-inside">
              <li>No credit card required. Zero charges guaranteed.</li>
              <li>Saved only on your device; never sent to third parties.</li>
              <li>Enables real-time 24kHz Gemini Voice (Aoede, Kore, Puck, Fenrir).</li>
            </ul>
          </div>
        </div>
      </div>
    </div>
  );
};
