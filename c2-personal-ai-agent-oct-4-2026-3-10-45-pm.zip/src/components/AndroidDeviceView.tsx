import React from 'react';
import { AndroidDeviceState, AndroidFile } from '../types';
import { 
  Smartphone, 
  Play, 
  Pause, 
  SkipForward, 
  SkipBack, 
  Wifi, 
  Bluetooth, 
  Volume2, 
  Folder, 
  FileText, 
  Image as ImageIcon, 
  Check, 
  ArrowLeft, 
  Search, 
  Youtube, 
  Globe, 
  Settings, 
  Music, 
  Layers, 
  RotateCcw,
  ShieldCheck
} from 'lucide-react';

interface AndroidDeviceViewProps {
  deviceState: AndroidDeviceState;
  onResetDevice: () => void;
  onClose: () => void;
}

export const AndroidDeviceView: React.FC<AndroidDeviceViewProps> = ({
  deviceState,
  onResetDevice,
  onClose,
}) => {
  return (
    <div className="w-full lg:w-96 bg-slate-900 text-white flex flex-col border-l border-slate-800 h-full overflow-hidden">
      {/* Device Header */}
      <div className="p-3.5 bg-slate-950 border-b border-slate-800 flex items-center justify-between">
        <div className="flex items-center gap-2">
          <Smartphone className="w-4 h-4 text-emerald-400" />
          <span className="font-bold text-xs tracking-wider uppercase text-slate-200">
            Android Device Bridge
          </span>
          <span className="text-[10px] bg-emerald-950 text-emerald-300 border border-emerald-800 px-1.5 py-0.5 rounded font-mono">
            SIMULATED
          </span>
        </div>
        <div className="flex items-center gap-1.5">
          <button
            title="Reset simulated phone state"
            onClick={onResetDevice}
            className="p-1 rounded text-slate-400 hover:text-white hover:bg-slate-800 transition-colors text-xs flex items-center gap-1 cursor-pointer"
          >
            <RotateCcw className="w-3.5 h-3.5" />
          </button>
          <button
            onClick={onClose}
            className="lg:hidden text-xs text-slate-400 hover:text-white px-2 py-1 bg-slate-800 rounded cursor-pointer"
          >
            Close
          </button>
        </div>
      </div>

      {/* Simulated Phone Screen Bezel */}
      <div className="flex-1 overflow-y-auto p-4 space-y-4">
        {/* Status Bar */}
        <div className="bg-slate-950 rounded-2xl border border-slate-800 p-3 shadow-lg flex flex-col space-y-3">
          <div className="flex items-center justify-between text-[11px] text-slate-400 font-mono border-b border-slate-800 pb-2">
            <span>09:41 AM</span>
            <div className="flex items-center gap-2">
              <span className="flex items-center gap-1">
                <Wifi className={`w-3 h-3 ${deviceState.settings.wifi ? 'text-emerald-400' : 'text-slate-600'}`} />
                {deviceState.settings.wifi ? '5G Wi-Fi' : 'Off'}
              </span>
              <Bluetooth className={`w-3 h-3 ${deviceState.settings.bluetooth ? 'text-sky-400' : 'text-slate-600'}`} />
              <span>88% 🔋</span>
            </div>
          </div>

          {/* Active Screen Title & Current App */}
          <div className="bg-slate-900 rounded-xl p-3 border border-slate-800">
            <div className="text-[11px] text-slate-400 flex items-center justify-between mb-1">
              <span>Foreground Application:</span>
              <span className="font-semibold text-emerald-400 font-mono">{deviceState.currentApp}</span>
            </div>
            <div className="text-sm font-semibold text-white flex items-center gap-2">
              {deviceState.currentApp === 'YouTube' && <Youtube className="w-4 h-4 text-red-500" />}
              {deviceState.currentApp === 'Chrome' && <Globe className="w-4 h-4 text-blue-400" />}
              {deviceState.currentApp === 'Spotify' && <Music className="w-4 h-4 text-green-500" />}
              {deviceState.currentApp === 'Files' && <Folder className="w-4 h-4 text-amber-400" />}
              {deviceState.currentApp === 'Settings' && <Settings className="w-4 h-4 text-slate-400" />}
              <span>{deviceState.currentScreenTitle}</span>
            </div>

            {deviceState.activeInputQuery && (
              <div className="mt-2 bg-slate-950 px-2.5 py-1.5 rounded-lg border border-slate-700 text-xs font-mono text-emerald-300 flex items-center gap-2">
                <Search className="w-3 h-3 text-slate-400" />
                <span>Search: "{deviceState.activeInputQuery}"</span>
              </div>
            )}
          </div>

          {/* Media Player Card */}
          <div className="bg-slate-900/80 rounded-xl p-3 border border-slate-800 space-y-2">
            <div className="flex items-center justify-between text-[11px] text-slate-400">
              <span className="flex items-center gap-1 font-semibold uppercase tracking-wider text-[10px]">
                <Music className="w-3 h-3 text-pink-400" />
                Android MediaSession
              </span>
              <span className={`text-[10px] px-1.5 py-0.5 rounded font-mono ${deviceState.mediaState.isPlaying ? 'bg-emerald-950 text-emerald-400' : 'bg-slate-800 text-slate-400'}`}>
                {deviceState.mediaState.isPlaying ? 'PLAYING' : 'PAUSED'}
              </span>
            </div>
            <div>
              <div className="text-xs font-bold text-white truncate">
                {deviceState.mediaState.trackTitle}
              </div>
              <div className="text-[11px] text-slate-400 truncate">
                {deviceState.mediaState.artist} • {deviceState.mediaState.album}
              </div>
            </div>
            <div className="flex items-center justify-center gap-4 pt-1">
              <div className="p-1 text-slate-400">
                <SkipBack className="w-4 h-4" />
              </div>
              <div className="p-2 rounded-full bg-indigo-600 text-white">
                {deviceState.mediaState.isPlaying ? <Pause className="w-4 h-4" /> : <Play className="w-4 h-4" />}
              </div>
              <div className="p-1 text-slate-400">
                <SkipForward className="w-4 h-4" />
              </div>
            </div>
          </div>

          {/* File Storage Explorer */}
          <div className="bg-slate-900/80 rounded-xl p-3 border border-slate-800 space-y-2">
            <div className="flex items-center justify-between text-[11px] text-slate-400">
              <span className="flex items-center gap-1 font-semibold uppercase tracking-wider text-[10px]">
                <Folder className="w-3 h-3 text-amber-400" />
                MediaStore Storage ({deviceState.files.length} items)
              </span>
              <span className="text-[10px] text-slate-500 font-mono">Scoped IDs</span>
            </div>
            <div className="space-y-1.5 max-h-44 overflow-y-auto pr-1">
              {deviceState.files.map((file) => (
                <div
                  key={file.file_id}
                  className="bg-slate-950 p-2 rounded-lg border border-slate-800 text-xs flex items-center justify-between hover:border-slate-700 transition-colors"
                >
                  <div className="flex items-center gap-2 overflow-hidden">
                    {file.filename.endsWith('.pdf') ? (
                      <FileText className="w-3.5 h-3.5 text-rose-400 shrink-0" />
                    ) : file.filename.endsWith('.jpg') ? (
                      <ImageIcon className="w-3.5 h-3.5 text-blue-400 shrink-0" />
                    ) : (
                      <FileText className="w-3.5 h-3.5 text-amber-400 shrink-0" />
                    )}
                    <div className="overflow-hidden">
                      <div className="font-mono text-slate-200 truncate">{file.filename}</div>
                      <div className="text-[10px] text-slate-500 truncate">{file.location}</div>
                    </div>
                  </div>
                  <div className="text-right shrink-0 font-mono text-[10px] text-slate-400 ml-2">
                    <div>{file.size}</div>
                    <div className="text-slate-600">{file.file_id}</div>
                  </div>
                </div>
              ))}
            </div>
          </div>

          {/* Settings Status */}
          <div className="bg-slate-900/80 rounded-xl p-3 border border-slate-800 space-y-2">
            <div className="flex items-center justify-between text-[11px] text-slate-400">
              <span className="flex items-center gap-1 font-semibold uppercase tracking-wider text-[10px]">
                <Settings className="w-3 h-3 text-slate-400" />
                Android System Toggles
              </span>
              <span className="text-[10px] text-emerald-400 font-mono flex items-center gap-1">
                <ShieldCheck className="w-3 h-3" /> Permissions OK
              </span>
            </div>
            <div className="grid grid-cols-2 gap-2 text-xs">
              <div className="bg-slate-950 p-2 rounded-lg border border-slate-800 flex items-center justify-between">
                <span className="text-slate-400">Wi-Fi:</span>
                <span className={`font-mono font-bold ${deviceState.settings.wifi ? 'text-emerald-400' : 'text-slate-500'}`}>
                  {deviceState.settings.wifi ? 'ENABLED' : 'DISABLED'}
                </span>
              </div>
              <div className="bg-slate-950 p-2 rounded-lg border border-slate-800 flex items-center justify-between">
                <span className="text-slate-400">Bluetooth:</span>
                <span className={`font-mono font-bold ${deviceState.settings.bluetooth ? 'text-sky-400' : 'text-slate-500'}`}>
                  {deviceState.settings.bluetooth ? 'ENABLED' : 'DISABLED'}
                </span>
              </div>
            </div>
          </div>

          {/* Accessibility Log */}
          <div className="bg-slate-900/80 rounded-xl p-3 border border-slate-800 space-y-2">
            <div className="flex items-center justify-between text-[11px] text-slate-400">
              <span className="flex items-center gap-1 font-semibold uppercase tracking-wider text-[10px]">
                <Layers className="w-3 h-3 text-purple-400" />
                AccessibilityService Event Stream
              </span>
              <span className="text-[10px] text-slate-500 font-mono">Real-time</span>
            </div>
            <div className="space-y-1 max-h-32 overflow-y-auto text-[11px] font-mono pr-1">
              {deviceState.accessibilityLogs.length === 0 ? (
                <div className="text-slate-600 italic py-2 text-center">No gestures recorded yet</div>
              ) : (
                deviceState.accessibilityLogs.slice(0, 5).map((log) => (
                  <div key={log.id} className="bg-slate-950 p-1.5 rounded border border-slate-800 text-slate-300 flex items-center justify-between">
                    <span className="text-indigo-400">{log.action}()</span>
                    <span className="text-slate-400 truncate max-w-[120px]">"{log.target}"</span>
                    <span className="text-emerald-400 text-[10px]">OK</span>
                  </div>
                ))
              )}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
