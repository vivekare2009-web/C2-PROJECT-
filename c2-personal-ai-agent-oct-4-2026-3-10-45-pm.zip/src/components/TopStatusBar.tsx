import React from 'react';
import { LiveConnectionState, AtmosphereTheme, UserProfile, ApiKeyStatus } from '../types';
import { Sparkles, Activity, ShieldCheck, Zap, Palette, Music, User, Database, Key, AlertTriangle } from 'lucide-react';

interface TopStatusBarProps {
  connectionState: LiveConnectionState;
  latencyMs: number;
  sessionSeconds: number;
  atmosphere: AtmosphereTheme;
  selectedVoice: string;
  currentUser: UserProfile | null;
  memoryCount: number;
  keyStatus?: ApiKeyStatus | null;
  onAtmosphereChange: (theme: AtmosphereTheme) => void;
  onVoiceChange: (voice: string) => void;
  onOpenIdentityModal: () => void;
  onOpenGeminiDiagnostic?: () => void;
  onOpenKeyModal?: () => void;
}

export const TopStatusBar: React.FC<TopStatusBarProps> = ({
  connectionState,
  latencyMs,
  sessionSeconds,
  atmosphere,
  selectedVoice,
  currentUser,
  memoryCount,
  keyStatus,
  onAtmosphereChange,
  onVoiceChange,
  onOpenIdentityModal,
  onOpenGeminiDiagnostic,
  onOpenKeyModal,
}) => {
  const formatTime = (secs: number) => {
    const m = Math.floor(secs / 60);
    const s = secs % 60;
    return `${m.toString().padStart(2, '0')}:${s.toString().padStart(2, '0')}`;
  };

  // Status badge config
  const statusConfigs = {
    disconnected: {
      label: 'Disconnected',
      color: 'bg-slate-500/20 text-slate-400 border-slate-500/30',
      dot: 'bg-slate-400',
    },
    connecting: {
      label: 'Connecting',
      color: 'bg-cyan-500/20 text-cyan-300 border-cyan-500/40 animate-pulse',
      dot: 'bg-cyan-400 animate-ping',
    },
    listening: {
      label: 'Listening',
      color: 'bg-emerald-500/20 text-emerald-300 border-emerald-500/40',
      dot: 'bg-emerald-400 animate-pulse',
    },
    thinking: {
      label: 'Thinking',
      color: 'bg-blue-500/20 text-blue-300 border-blue-500/40 animate-pulse',
      dot: 'bg-blue-400 animate-ping',
    },
    speaking: {
      label: 'Speaking',
      color: 'bg-fuchsia-500/20 text-fuchsia-300 border-fuchsia-500/40',
      dot: 'bg-fuchsia-400 animate-ping',
    },
    error: {
      label: 'Attention Needed',
      color: 'bg-rose-500/20 text-rose-300 border-rose-500/40',
      dot: 'bg-rose-400',
    },
  };

  const currentStatus = statusConfigs[connectionState] || statusConfigs.disconnected;

  return (
    <header className="w-full max-w-4xl mx-auto px-4 pt-4 pb-2 flex flex-wrap items-center justify-between gap-3 z-30">
      {/* C2 Brand Identity & Status */}
      <div className="flex items-center gap-3">
        <div className="flex items-center gap-2">
          <div className="w-8 h-8 rounded-xl bg-gradient-to-tr from-violet-600 via-fuchsia-600 to-indigo-500 flex items-center justify-center shadow-lg shadow-violet-500/30 border border-white/20">
            <Sparkles className="w-4 h-4 text-white" />
          </div>
          <div>
            <div className="flex items-center gap-1.5">
              <span className="font-bold tracking-tight text-white text-base">C2</span>
              <span className="text-[10px] font-mono uppercase px-1.5 py-0.5 rounded-md bg-white/10 text-white/70 border border-white/10">
                LIVE
              </span>
            </div>
          </div>
        </div>

        {/* Live Status Pill */}
        <div
          className={`flex items-center gap-2 px-2.5 py-1 rounded-full text-xs font-semibold border backdrop-blur-md ${currentStatus.color}`}
        >
          <span className={`w-2 h-2 rounded-full ${currentStatus.dot}`} />
          <span>{currentStatus.label}</span>
          {sessionSeconds > 0 && (
            <span className="font-mono text-[10px] text-white/60 ml-1">
              {formatTime(sessionSeconds)}
            </span>
          )}
        </div>
      </div>

      {/* Controls & Telemetry Pills */}
      <div className="flex items-center flex-wrap gap-2 text-xs">
        {/* Gemini Key Manager Pill */}
        {onOpenKeyModal && (
          <button
            id="c2-gemini-key-btn"
            onClick={onOpenKeyModal}
            className={`flex items-center gap-1.5 px-2.5 py-1 rounded-lg border font-medium text-xs transition-all backdrop-blur-md shadow-xs cursor-pointer ${
              keyStatus?.quotaExhausted
                ? 'bg-rose-950/50 hover:bg-rose-900/60 border-rose-500/50 text-rose-300 animate-pulse'
                : keyStatus?.hasKey
                ? 'bg-violet-950/40 hover:bg-violet-900/50 border-violet-500/40 text-violet-300'
                : 'bg-amber-950/40 hover:bg-amber-900/50 border-amber-500/40 text-amber-300'
            }`}
            title="Manage Gemini API Keys, Auto-Fallback, and Live Voice"
          >
            {keyStatus?.quotaExhausted ? (
              <AlertTriangle className="w-3.5 h-3.5 text-rose-400 shrink-0" />
            ) : (
              <Key className="w-3.5 h-3.5 text-violet-400 shrink-0" />
            )}
            <span className="font-semibold text-white">
              {keyStatus?.quotaExhausted
                ? 'Quota Reached'
                : keyStatus?.hasKey
                ? 'Gemini Key'
                : 'Add Key'}
            </span>
            {keyStatus?.hasKey && !keyStatus.quotaExhausted && (
              <span className="w-1.5 h-1.5 rounded-full bg-emerald-400 animate-pulse" />
            )}
          </button>
        )}

        {/* Gemini Free Tier Status Pill */}
        {onOpenGeminiDiagnostic && (
          <button
            id="c2-gemini-free-tier-btn"
            onClick={onOpenGeminiDiagnostic}
            className="flex items-center gap-1.5 px-2.5 py-1 rounded-lg bg-emerald-950/40 hover:bg-emerald-900/50 border border-emerald-500/40 text-emerald-300 font-medium text-xs transition-all backdrop-blur-md shadow-xs group cursor-pointer"
            title="Gemini Free Tier Status and 1-Click Diagnostics"
          >
            <span className="w-2 h-2 rounded-full bg-emerald-400 animate-pulse" />
            <span className="font-semibold text-white group-hover:text-emerald-200">Gemini Free Tier</span>
            <span className="text-[10px] font-mono px-1 rounded bg-emerald-500/20 text-emerald-300 border border-emerald-500/30">
              Zero $
            </span>
          </button>
        )}

        {/* User Identity & Persistent Memory Pill */}
        <button
          id="c2-identity-pill"
          onClick={onOpenIdentityModal}
          className="flex items-center gap-2 px-2.5 py-1 rounded-lg bg-violet-950/40 hover:bg-violet-900/50 border border-violet-500/30 text-white font-medium text-xs transition-all backdrop-blur-md shadow-xs group"
          title="Account identity and C2 memories database"
        >
          <div className="w-4 h-4 rounded-full bg-violet-600 flex items-center justify-center text-[10px] font-bold text-white shadow-xs">
            {currentUser?.preferredName?.[0] || 'M'}
          </div>
          <span className="group-hover:text-violet-200">
            {currentUser?.preferredName || 'Master'}
          </span>
          <span className="text-[10px] px-1 py-0.2 rounded bg-violet-500/20 text-violet-300 font-mono">
            {memoryCount} mem
          </span>
        </button>

        {/* Latency & Audio Spec Indicator */}
        <div className="hidden sm:flex items-center gap-1.5 px-2.5 py-1 rounded-lg bg-white/5 border border-white/10 text-slate-300 font-mono text-[11px] backdrop-blur-md">
          <Zap className="w-3 h-3 text-amber-400" />
          <span>{latencyMs}ms</span>
          <span className="text-white/20">|</span>
          <span className="text-slate-400">16k In / 24k Out</span>
        </div>

        {/* Voice Selector */}
        <div className="flex items-center gap-1 bg-white/5 border border-white/10 rounded-lg px-2 py-0.5 backdrop-blur-md">
          <Music className="w-3 h-3 text-violet-400" />
          <select
            id="c2-voice-selector"
            value={selectedVoice}
            disabled={connectionState !== 'disconnected'}
            onChange={(e) => onVoiceChange(e.target.value)}
            className="bg-transparent text-slate-200 text-xs py-0.5 focus:outline-hidden cursor-pointer disabled:opacity-50"
            title="Gemini Live Voice"
          >
            <option value="Aoede" className="bg-slate-900 text-white">Aoede (Confident)</option>
            <option value="Kore" className="bg-slate-900 text-white">Kore (Warm)</option>
            <option value="Zephyr" className="bg-slate-900 text-white">Zephyr (Breezy)</option>
            <option value="Puck" className="bg-slate-900 text-white">Puck (Playful)</option>
            <option value="Fenrir" className="bg-slate-900 text-white">Fenrir (Deep)</option>
          </select>
        </div>

        {/* Atmosphere Theme Switcher */}
        <div className="flex items-center gap-1 bg-white/5 border border-white/10 rounded-lg px-2 py-0.5 backdrop-blur-md">
          <Palette className="w-3 h-3 text-fuchsia-400" />
          <select
            id="c2-atmosphere-selector"
            value={atmosphere}
            onChange={(e) => onAtmosphereChange(e.target.value as AtmosphereTheme)}
            className="bg-transparent text-slate-200 text-xs py-0.5 focus:outline-hidden cursor-pointer"
            title="Atmosphere Theme"
          >
            <option value="nebula" className="bg-slate-900 text-white">Nebula</option>
            <option value="cyberpunk" className="bg-slate-900 text-white">Cyberpunk</option>
            <option value="aurora" className="bg-slate-900 text-white">Aurora</option>
            <option value="midnight" className="bg-slate-900 text-white">Midnight</option>
          </select>
        </div>
      </div>
    </header>
  );
};
