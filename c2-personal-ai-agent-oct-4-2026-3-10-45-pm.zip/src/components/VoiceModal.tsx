import React, { useEffect, useState } from 'react';
import { AgentStatus, EmotionalState, LanguageCode } from '../types';
import { VoiceEngineStatus } from './VoiceEngineStatus';
import { 
  Mic, 
  MicOff, 
  Volume2, 
  VolumeX, 
  X, 
  Sparkles, 
  Radio, 
  RefreshCw, 
  ShieldAlert, 
  Bot, 
  Cpu, 
  CheckCircle2,
  Globe
} from 'lucide-react';

interface VoiceModalProps {
  isOpen: boolean;
  onClose: () => void;
  isListening: boolean;
  isSpeaking: boolean;
  agentStatus: AgentStatus;
  emotionalState: EmotionalState;
  audioLevel: number;
  currentTranscript: string;
  lastAgentResponse: string | null;
  preferredLanguage: LanguageCode;
  isContinuousMode: boolean;
  permissionStatus: 'prompt' | 'granted' | 'denied' | 'unsupported';
  onToggleMic: () => void;
  onInterrupt: () => void;
  onChangeLanguage: (lang: LanguageCode) => void;
  onToggleContinuousMode: (enabled: boolean) => void;
  onRequestPermission: () => void;
  onSelectPrompt: (promptText: string) => void;
}

export const VoiceModal: React.FC<VoiceModalProps> = ({
  isOpen,
  onClose,
  isListening,
  isSpeaking,
  agentStatus,
  emotionalState,
  audioLevel,
  currentTranscript,
  lastAgentResponse,
  preferredLanguage,
  isContinuousMode,
  permissionStatus,
  onToggleMic,
  onInterrupt,
  onChangeLanguage,
  onToggleContinuousMode,
  onRequestPermission,
  onSelectPrompt,
}) => {
  if (!isOpen) return null;

  // Voice prompts suited for spoken command testing
  const voicePrompts = [
    { label: 'YouTube kholo', text: 'C2, YouTube kholo.' },
    { label: 'Search workout', text: 'C2, open YouTube and search for home workout.' },
    { label: 'Play music', text: 'C2, play music.' },
    { label: 'Open Wi-Fi', text: 'Open the Wi-Fi settings.' },
    { label: 'Find PDF', text: 'Find my workout PDF.' },
    { label: 'Check memory', text: 'What do you remember about me?' },
    { label: 'Hindi rename', text: 'Is file ko rename kar do.' },
  ];

  // Simulated visual waveform bar heights when audioLevel is active or speaking
  const barsCount = 20;
  const bars = Array.from({ length: barsCount }, (_, idx) => {
    if (isListening) {
      const centerFactor = 1 - Math.abs(idx - barsCount / 2) / (barsCount / 2);
      const wave = Math.sin(idx * 0.7 + Date.now() * 0.006) * 0.3 + 0.7;
      return Math.max(12, Math.min(96, Math.round((audioLevel || 20) * centerFactor * wave * 1.2)));
    } else if (isSpeaking) {
      const wave = Math.sin(idx * 0.8 + Date.now() * 0.008) * 0.4 + 0.6;
      return Math.max(16, Math.round(55 * wave));
    } else {
      return 6;
    }
  });

  // Emotional accent colors for orb glow
  const getEmotionGlow = () => {
    switch (emotionalState) {
      case 'happy':
      case 'excited':
        return 'from-amber-400 via-pink-500 to-indigo-600 shadow-pink-500/40';
      case 'focused':
        return 'from-blue-400 via-indigo-600 to-purple-700 shadow-indigo-500/40';
      case 'curious':
        return 'from-teal-400 via-emerald-500 to-indigo-600 shadow-emerald-500/40';
      case 'frustrated':
        return 'from-rose-500 via-red-600 to-amber-600 shadow-rose-500/40';
      case 'calm':
      default:
        return 'from-indigo-400 via-purple-500 to-pink-500 shadow-indigo-500/40';
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-6 bg-slate-950/80 backdrop-blur-md animate-in fade-in duration-200">
      <div 
        id="c2-voice-modal-container"
        className="relative w-full max-w-2xl bg-gradient-to-b from-slate-900 via-slate-900 to-slate-950 border border-slate-700/80 rounded-3xl shadow-2xl overflow-hidden flex flex-col max-h-[92vh]"
      >
        {/* Subtle Ambient Background Light */}
        <div className="absolute top-0 left-1/2 -translate-x-1/2 w-96 h-64 bg-indigo-500/15 rounded-full blur-3xl pointer-events-none" />

        {/* Modal Top Bar */}
        <div className="relative px-6 py-4 border-b border-slate-800 flex items-center justify-between z-10">
          <div className="flex items-center gap-3">
            <div className="w-9 h-9 rounded-xl bg-gradient-to-tr from-indigo-500 to-purple-600 flex items-center justify-center text-white font-bold text-sm shadow-md">
              C2
            </div>
            <div>
              <div className="flex items-center gap-2">
                <h3 className="text-white font-semibold text-base tracking-tight">Talk with C2</h3>
                <span className="text-[11px] font-medium px-2 py-0.5 rounded-full bg-indigo-950 text-indigo-300 border border-indigo-800">
                  Live Voice
                </span>
              </div>
              <p className="text-xs text-slate-400 flex items-center gap-2">
                <span>Emotion: <strong className="text-slate-200 capitalize">{emotionalState}</strong></span>
                <span>•</span>
                <span>Language: <strong className="text-indigo-300">{preferredLanguage}</strong></span>
              </p>
            </div>
          </div>

          <div className="flex items-center gap-2">
            {/* Voice Engine Status */}
            <VoiceEngineStatus />

            {/* Close Button */}
            <button
              id="close-voice-modal-btn"
              onClick={onClose}
              className="p-2 text-slate-400 hover:text-white hover:bg-slate-800 rounded-xl transition-colors cursor-pointer"
              title="Close Voice Mode"
            >
              <X className="w-5 h-5" />
            </button>
          </div>
        </div>

        {/* Modal Body */}
        <div className="relative flex-1 flex flex-col items-center justify-between p-6 overflow-y-auto space-y-6 z-10">
          
          {/* Permission warning banner if microphone permission is denied */}
          {permissionStatus === 'denied' && (
            <div className="w-full p-3.5 bg-rose-950/70 border border-rose-800/80 rounded-2xl flex items-center justify-between text-rose-200 text-xs">
              <div className="flex items-center gap-2">
                <ShieldAlert className="w-4 h-4 text-rose-400 shrink-0" />
                <span>Microphone blocked in browser. Please click the lock icon in the address bar and select "Allow".</span>
              </div>
              <button
                onClick={onRequestPermission}
                className="px-3 py-1 bg-rose-600 hover:bg-rose-500 text-white font-medium rounded-lg shrink-0 cursor-pointer"
              >
                Retry
              </button>
            </div>
          )}

          {/* Center Voice Orb & Waveform Display */}
          <div className="flex flex-col items-center justify-center my-auto py-2 w-full">
            {/* Animated Dynamic Voice Sphere */}
            <div className="relative flex items-center justify-center mb-6">
              {/* Outer Energy Pulse Rings */}
              {isListening && (
                <>
                  <div 
                    className="absolute w-44 h-44 rounded-full border border-rose-500/30 animate-ping"
                    style={{ animationDuration: '2s' }}
                  />
                  <div 
                    className="absolute w-36 h-36 rounded-full bg-rose-500/10 animate-pulse"
                    style={{ 
                      transform: `scale(${1 + (audioLevel / 150)})`,
                      transition: 'transform 0.1s ease-out'
                    }}
                  />
                </>
              )}

              {isSpeaking && (
                <>
                  <div className="absolute w-40 h-40 rounded-full border border-indigo-400/40 animate-pulse" />
                  <div className="absolute w-48 h-48 rounded-full border border-purple-500/20 animate-ping" style={{ animationDuration: '2.5s' }} />
                </>
              )}

              {/* Main Glowing Sphere */}
              <div 
                className={`relative w-28 h-28 rounded-full bg-gradient-to-tr ${getEmotionGlow()} shadow-2xl flex items-center justify-center transition-all duration-300 ${
                  isListening
                    ? 'ring-4 ring-rose-400/80 scale-105 shadow-rose-500/50'
                    : isSpeaking
                    ? 'ring-4 ring-indigo-300/80 scale-105 animate-pulse'
                    : 'scale-100 opacity-90'
                }`}
              >
                <div className="w-24 h-24 rounded-full bg-slate-950/40 backdrop-blur-xs flex items-center justify-center text-white">
                  {agentStatus === 'thinking' ? (
                    <Cpu className="w-10 h-10 text-white animate-spin" />
                  ) : isSpeaking ? (
                    <Volume2 className="w-10 h-10 text-white animate-pulse" />
                  ) : (
                    <Mic className={`w-10 h-10 ${isListening ? 'text-rose-200 animate-pulse' : 'text-white'}`} />
                  )}
                </div>
              </div>
            </div>

            {/* Status Text Indicator */}
            <div className="text-center mb-4">
              <span className={`inline-flex items-center gap-2 px-3 py-1 rounded-full text-xs font-semibold tracking-wide uppercase ${
                isListening
                  ? 'bg-rose-950/80 text-rose-300 border border-rose-800 animate-pulse'
                  : isSpeaking
                  ? 'bg-indigo-950/80 text-indigo-300 border border-indigo-800'
                  : agentStatus === 'thinking'
                  ? 'bg-sky-950/80 text-sky-300 border border-sky-800 animate-pulse'
                  : 'bg-slate-800/80 text-slate-400 border border-slate-700'
              }`}>
                <span className={`w-2 h-2 rounded-full ${
                  isListening ? 'bg-rose-400 animate-ping' : isSpeaking ? 'bg-indigo-400' : 'bg-slate-400'
                }`} />
                {isListening
                  ? 'Listening to you... (Speak freely)'
                  : isSpeaking
                  ? 'C2 is speaking...'
                  : agentStatus === 'thinking'
                  ? 'C2 is thinking...'
                  : 'Tap Microphone or say a command'}
              </span>
            </div>

            {/* Audio Waveform Bars Reacting to Microphone */}
            <div className="flex items-center justify-center gap-1.5 h-14 w-full max-w-sm px-4">
              {bars.map((height, i) => (
                <div
                  key={i}
                  className={`w-1.5 rounded-full transition-all duration-75 ${
                    isListening
                      ? 'bg-gradient-to-t from-rose-600 to-amber-300'
                      : isSpeaking
                      ? 'bg-gradient-to-t from-indigo-500 to-purple-300'
                      : 'bg-slate-800'
                  }`}
                  style={{ height: `${height}px` }}
                />
              ))}
            </div>

            {/* Live Subtitle / Transcript Preview Box */}
            <div className="w-full mt-4 min-h-[76px] p-3.5 bg-slate-950/60 border border-slate-800 rounded-2xl flex flex-col justify-center text-center">
              {currentTranscript ? (
                <div className="space-y-1">
                  <span className="text-[11px] font-semibold tracking-wider text-rose-400 uppercase">You said:</span>
                  <p className="text-sm font-medium text-white break-words animate-in fade-in">
                    "{currentTranscript}"
                  </p>
                </div>
              ) : lastAgentResponse ? (
                <div className="space-y-1">
                  <span className="text-[11px] font-semibold tracking-wider text-indigo-400 uppercase">C2 replied:</span>
                  <p className="text-xs sm:text-sm text-slate-200 line-clamp-3">
                    "{lastAgentResponse}"
                  </p>
                </div>
              ) : (
                <p className="text-xs text-slate-500 italic">
                  Press the microphone below and speak in English, Hindi, or Hinglish...
                </p>
              )}
            </div>
          </div>

          {/* Quick Spoken Command Chips */}
          <div className="w-full">
            <div className="text-[11px] font-semibold text-slate-400 mb-2 flex items-center gap-1.5">
              <Sparkles className="w-3.5 h-3.5 text-indigo-400" />
              <span>Tap to try saying:</span>
            </div>
            <div className="flex flex-wrap gap-1.5">
              {voicePrompts.map((p, i) => (
                <button
                  key={i}
                  id={`voice-prompt-chip-${i}`}
                  onClick={() => onSelectPrompt(p.text)}
                  className="text-xs bg-slate-800/80 hover:bg-indigo-950/70 hover:border-indigo-600 text-slate-300 hover:text-white px-2.5 py-1.5 rounded-xl border border-slate-700/70 transition-all cursor-pointer"
                >
                  {p.label}
                </button>
              ))}
            </div>
          </div>

          {/* Controls: Big Microphone & Settings */}
          <div className="w-full pt-3 border-t border-slate-800/80 flex flex-col sm:flex-row items-center justify-between gap-4">
            {/* Language Selector */}
            <div className="flex items-center gap-1.5 bg-slate-950/60 p-1 rounded-xl border border-slate-800 text-xs">
              <Globe className="w-3.5 h-3.5 text-slate-400 ml-1.5" />
              {(['English', 'Hinglish', 'Hindi'] as LanguageCode[]).map((lang) => (
                <button
                  key={lang}
                  id={`voice-lang-${lang}`}
                  onClick={() => onChangeLanguage(lang)}
                  className={`px-2.5 py-1 rounded-lg font-medium transition-colors cursor-pointer ${
                    preferredLanguage === lang
                      ? 'bg-indigo-600 text-white shadow-xs'
                      : 'text-slate-400 hover:text-slate-200'
                  }`}
                >
                  {lang}
                </button>
              ))}
            </div>

            {/* Central Giant Mic Action Button */}
            <div className="flex items-center gap-3">
              {isSpeaking && (
                <button
                  id="interrupt-c2-btn"
                  onClick={onInterrupt}
                  className="px-3 py-2 bg-slate-800 hover:bg-slate-700 text-slate-200 rounded-xl text-xs font-semibold transition-colors flex items-center gap-1.5 cursor-pointer border border-slate-700"
                  title="Interrupt C2 speech"
                >
                  <VolumeX className="w-4 h-4 text-rose-400" />
                  <span>Interrupt</span>
                </button>
              )}

              <button
                id="voice-modal-mic-toggle-btn"
                onClick={onToggleMic}
                title={isListening ? 'Click to stop listening' : 'Click to talk to C2'}
                className={`relative px-6 py-3.5 rounded-2xl font-semibold text-sm flex items-center gap-2.5 transition-all shadow-lg cursor-pointer ${
                  isListening
                    ? 'bg-rose-600 hover:bg-rose-500 text-white ring-4 ring-rose-500/40 animate-pulse'
                    : 'bg-indigo-600 hover:bg-indigo-500 text-white shadow-indigo-600/30'
                }`}
              >
                {isListening ? (
                  <>
                    <Mic className="w-5 h-5 animate-bounce" />
                    <span>Listening... Tap to stop</span>
                  </>
                ) : (
                  <>
                    <Mic className="w-5 h-5" />
                    <span>Talk to C2</span>
                  </>
                )}
              </button>
            </div>

            {/* Continuous Conversation Toggle */}
            <button
              id="continuous-mode-toggle-btn"
              onClick={() => onToggleContinuousMode(!isContinuousMode)}
              className={`flex items-center gap-1.5 px-3 py-1.5 rounded-xl text-xs font-medium border transition-colors cursor-pointer ${
                isContinuousMode
                  ? 'bg-emerald-950/60 text-emerald-300 border-emerald-800'
                  : 'bg-slate-950/60 text-slate-400 border-slate-800 hover:text-slate-300'
              }`}
              title="When enabled, C2 stays listening after answering for hands-free conversations"
            >
              <Radio className={`w-3.5 h-3.5 ${isContinuousMode ? 'text-emerald-400 animate-pulse' : 'text-slate-500'}`} />
              <span>Hands-Free {isContinuousMode ? 'ON' : 'OFF'}</span>
            </button>
          </div>

        </div>
      </div>
    </div>
  );
};
