import React from 'react';
import { Sparkles } from 'lucide-react';

interface VoicePromptsProps {
  onSelectPrompt?: (prompt: string) => void;
}

const SAMPLE_PROMPTS = [
  'Call me Master Vivek',
  'Remember that my favorite drink is Iced Matcha',
  'What do you remember about me?',
  'Open YouTube for me',
  'Tell me a witty joke',
  'Change atmosphere to Cyberpunk',
];

export const VoicePrompts: React.FC<VoicePromptsProps> = ({ onSelectPrompt }) => {
  return (
    <div className="w-full max-w-xl mx-auto px-4 mt-4 select-none">
      <div className="flex items-center justify-center gap-1.5 text-slate-400 text-xs font-medium mb-2.5">
        <Sparkles className="w-3 h-3 text-violet-400" />
        <span>Try speaking or clicking a prompt for C2</span>
      </div>

      <div className="flex flex-wrap justify-center gap-2">
        {SAMPLE_PROMPTS.map((prompt, idx) => (
          <button
            key={idx}
            id={`voice-prompt-${idx}`}
            onClick={() => onSelectPrompt?.(prompt)}
            className="px-3 py-1.5 rounded-full text-xs font-normal text-slate-300 bg-white/[0.04] border border-white/10 backdrop-blur-md transition-all hover:bg-violet-600/30 hover:border-violet-400/40 hover:text-white cursor-pointer active:scale-95 text-left"
          >
            "{prompt}"
          </button>
        ))}
      </div>
    </div>
  );
};
