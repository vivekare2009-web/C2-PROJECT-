import React from 'react';
import { ToolExecutionEvent } from '../types';
import { ExternalLink, Terminal, CheckCircle2, AlertCircle, Loader2 } from 'lucide-react';

interface ToolActivityHudProps {
  activeTool: ToolExecutionEvent | null;
  toolHistory: ToolExecutionEvent[];
}

export const ToolActivityHud: React.FC<ToolActivityHudProps> = ({
  activeTool,
  toolHistory,
}) => {
  if (!activeTool && toolHistory.length === 0) return null;

  const currentTool = activeTool || toolHistory[0];
  if (!currentTool) return null;

  const isRunning = currentTool.status === 'running';
  const isFailed = currentTool.status === 'failed';

  return (
    <div className="w-full max-w-md mx-auto px-4 my-2 z-20">
      <div
        className={`p-3 rounded-xl border backdrop-blur-xl transition-all duration-300 ${
          isRunning
            ? 'bg-cyan-950/40 border-cyan-500/40 shadow-lg shadow-cyan-500/10'
            : isFailed
            ? 'bg-rose-950/40 border-rose-500/40'
            : 'bg-white/[0.04] border-white/10'
        }`}
      >
        <div className="flex items-center justify-between gap-2 mb-1.5">
          <div className="flex items-center gap-2">
            <div className="p-1 rounded-md bg-white/10 text-cyan-400">
              <Terminal className="w-3.5 h-3.5" />
            </div>
            <span className="text-xs font-mono font-semibold text-slate-200 uppercase tracking-wider">
              Tool Action: {currentTool.name}
            </span>
          </div>

          <div className="flex items-center gap-1.5 text-[11px]">
            {isRunning && (
              <span className="flex items-center gap-1 text-cyan-300 font-mono">
                <Loader2 className="w-3 h-3 animate-spin" />
                Executing...
              </span>
            )}
            {!isRunning && !isFailed && (
              <span className="flex items-center gap-1 text-emerald-400 font-mono">
                <CheckCircle2 className="w-3 h-3" />
                Done
              </span>
            )}
            {isFailed && (
              <span className="flex items-center gap-1 text-rose-400 font-mono">
                <AlertCircle className="w-3 h-3" />
                Failed
              </span>
            )}
          </div>
        </div>

        {/* Action description / link */}
        <div className="text-xs text-slate-300 font-sans pl-6">
          {currentTool.name === 'openWebsite' && (
            <div className="flex items-center justify-between gap-2">
              <span className="truncate">
                {currentTool.args?.url || ''}
              </span>
              {currentTool.args?.url && (
                <a
                  href={currentTool.args.url}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="flex items-center gap-1 px-2 py-0.5 rounded-md bg-cyan-500/20 text-cyan-300 hover:bg-cyan-500/30 border border-cyan-500/30 text-[11px] font-medium shrink-0 cursor-pointer"
                >
                  <ExternalLink className="w-3 h-3" />
                  <span>Open Tab</span>
                </a>
              )}
            </div>
          )}

          {currentTool.name === 'searchWeb' && (
            <div className="flex items-center justify-between gap-2">
              <span className="truncate">Searching "{currentTool.args?.query || ''}"</span>
              {currentTool.result?.searchUrl && (
                <a
                  href={currentTool.result.searchUrl}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="flex items-center gap-1 px-2 py-0.5 rounded-md bg-cyan-500/20 text-cyan-300 hover:bg-cyan-500/30 border border-cyan-500/30 text-[11px] font-medium shrink-0 cursor-pointer"
                >
                  <ExternalLink className="w-3 h-3" />
                  <span>View</span>
                </a>
              )}
            </div>
          )}

          {currentTool.name === 'changeAtmosphere' && (
            <span>Switched atmosphere theme to <strong className="text-white capitalize">{currentTool.args?.theme || 'nebula'}</strong></span>
          )}

          {currentTool.name === 'playAmbientTone' && (
            <span>Played synthesized ambient <strong className="text-white capitalize">{currentTool.args?.tone || 'chime'}</strong> tone</span>
          )}

          {currentTool.name === 'getSystemInfo' && (
            <span>Gathered local device context and time</span>
          )}
        </div>
      </div>
    </div>
  );
};
