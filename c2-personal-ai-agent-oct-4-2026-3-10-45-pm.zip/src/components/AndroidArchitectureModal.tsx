import React, { useState } from 'react';
import { X, Code2, Copy, Check, Smartphone, ShieldCheck, Terminal } from 'lucide-react';

interface AndroidArchitectureModalProps {
  isOpen: boolean;
  onClose: () => void;
}

export const AndroidArchitectureModal: React.FC<AndroidArchitectureModalProps> = ({
  isOpen,
  onClose,
}) => {
  const [activeTab, setActiveTab] = useState<'bridge' | 'accessibility' | 'manifest' | 'risk'>('bridge');
  const [copied, setCopied] = useState(false);

  if (!isOpen) return null;

  const codeSnippets = {
    bridge: `// AndroidBridge.kt - Turnkey Android Integration Layer for C2
package ai.c2.agent.android

import android.content.Context
import android.content.Intent
import android.net.Uri
import android.provider.MediaStore
import android.provider.Settings
import android.support.v4.media.session.MediaControllerCompat
import android.support.v4.media.session.MediaSessionCompat
import org.json.JSONObject

class AndroidBridge(private val context: Context) {

    // 1. Tool: open_app
    fun openApp(appName: String): String {
        val pm = context.packageManager
        val packages = pm.getInstalledApplications(0)
        val matched = packages.firstOrNull { it.loadLabel(pm).toString().equals(appName, ignoreCase = true) }
            ?: return JSONObject().put("success", false).put("error", "App $appName not installed").toString()

        val intent = pm.getLaunchIntentForPackage(matched.packageName)
        intent?.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        context.startActivity(intent)
        return JSONObject().put("success", true).put("message", "$appName opened on foreground").toString()
    }

    // 2. Tool: find_file (Scoped Storage / MediaStore API)
    fun findFile(filename: String): String {
        val projection = arrayOf(MediaStore.MediaColumns._ID, MediaStore.MediaColumns.DISPLAY_NAME, MediaStore.MediaColumns.SIZE)
        val cursor = context.contentResolver.query(
            MediaStore.Files.getContentUri("external"),
            projection,
            "\${MediaStore.MediaColumns.DISPLAY_NAME} LIKE ?",
            arrayOf("%$filename%"),
            null
        )
        val results = mutableListOf<Map<String, Any>>()
        cursor?.use {
            while (it.moveToNext()) {
                results.add(mapOf(
                    "file_id" to it.getString(0),
                    "filename" to it.getString(1),
                    "size" to it.getLong(2)
                ))
            }
        }
        return JSONObject().put("success", results.isNotEmpty()).put("matches", results).toString()
    }

    // 3. Tool: media_control
    fun mediaControl(action: String): String {
        // Dispatches media key event through AudioManager / MediaSessionCompat
        val keyCode = when (action) {
            "play", "pause" -> android.view.KeyEvent.KEYCODE_MEDIA_PLAY_PAUSE
            "next" -> android.view.KeyEvent.KEYCODE_MEDIA_NEXT
            "previous" -> android.view.KeyEvent.KEYCODE_MEDIA_PREVIOUS
            else -> return JSONObject().put("success", false).put("error", "Unknown media action").toString()
        }
        val am = context.getSystemService(Context.AUDIO_SERVICE) as android.media.AudioManager
        am.dispatchMediaKeyEvent(android.view.KeyEvent(android.view.KeyEvent.ACTION_DOWN, keyCode))
        am.dispatchMediaKeyEvent(android.view.KeyEvent(android.view.KeyEvent.ACTION_UP, keyCode))
        return JSONObject().put("success", true).put("message", "Media action $action executed").toString()
    }
}`,

    accessibility: `// C2AccessibilityService.kt - Safe Android Accessibility Implementation
package ai.c2.agent.accessibility

import android.accessibilityservice.AccessibilityService
import android.accessibilityservice.GestureDescription
import android.graphics.Path
import android.view.accessibility.AccessibilityEvent
import android.view.accessibility.AccessibilityNodeInfo
import org.json.JSONObject

class C2AccessibilityService : AccessibilityService() {

    companion object {
        var instance: C2AccessibilityService? = null
    }

    override fun onServiceConnected() {
        super.onServiceConnected()
        instance = this
    }

    // Executes targeted click or typing
    fun performAction(action: String, targetText: String?): String {
        val rootNode = rootInActiveWindow ?: return JSONObject().put("success", false).put("error", "No active window").toString()
        
        when (action) {
            "click" -> {
                val nodes = rootNode.findAccessibilityNodeInfosByText(targetText ?: "")
                val target = nodes.firstOrNull { it.isClickable } ?: nodes.firstOrNull()
                val clicked = target?.performAction(AccessibilityNodeInfo.ACTION_CLICK) ?: false
                return JSONObject().put("success", clicked).put("message", "Clicked on $targetText").toString()
            }
            "type" -> {
                val focused = rootNode.findFocus(AccessibilityNodeInfo.FOCUS_INPUT)
                if (focused != null) {
                    val arguments = android.os.Bundle()
                    arguments.putCharSequence(AccessibilityNodeInfo.ACTION_ARGUMENT_SET_TEXT_CHARSEQUENCE, targetText)
                    val typed = focused.performAction(AccessibilityNodeInfo.ACTION_SET_TEXT, arguments)
                    return JSONObject().put("success", typed).put("message", "Typed text").toString()
                }
            }
            "back" -> {
                performGlobalAction(GLOBAL_ACTION_BACK)
                return JSONObject().put("success", true).put("message", "Navigated back").toString()
            }
        }
        return JSONObject().put("success", false).put("error", "Action failed").toString()
    }

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {}
    override fun onInterrupt() {}
}`,

    manifest: `<!-- AndroidManifest.xml - C2 Permissions & Declarations -->
<manifest xmlns:android="http://schemas.android.com/apk/res/android"
    package="ai.c2.agent">

    <!-- Essential Android Permissions -->
    <uses-permission android:name="android.permission.INTERNET" />
    <uses-permission android:name="android.permission.RECORD_AUDIO" />
    <uses-permission android:name="android.permission.QUERY_ALL_PACKAGES" />
    <uses-permission android:name="android.permission.READ_MEDIA_DOCUMENTS" />
    <uses-permission android:name="android.permission.READ_MEDIA_IMAGES" />
    <uses-permission android:name="android.permission.MANAGE_EXTERNAL_STORAGE" />
    <uses-permission android:name="android.permission.MEDIA_CONTENT_CONTROL" />

    <application
        android:allowBackup="false"
        android:label="C2 Personal AI"
        android:theme="@style/Theme.C2Agent">

        <!-- Accessibility Service Registration -->
        <service
            android:name=".accessibility.C2AccessibilityService"
            android:permission="android.permission.BIND_ACCESSIBILITY_SERVICE"
            android:exported="false">
            <intent-filter>
                <action android:name="android.accessibilityservice.AccessibilityService" />
            </intent-filter>
            <meta-data
                android:name="android.accessibilityservice"
                android:resource="@xml/accessibility_service_config" />
        </service>

    </application>
</manifest>`,

    risk: `// RiskManager.kt - Independent Security Evaluator
package ai.c2.agent.security

enum class RiskLevel { LOW, MEDIUM, HIGH }

object RiskManager {
    fun evaluate(tool: String): RiskLevel = when (tool) {
        "open_app", "media_control", "open_settings", "find_file" -> RiskLevel.LOW
        "rename_file", "move_file", "take_screenshot", "accessibility_action" -> RiskLevel.MEDIUM
        "delete_file", "send_message", "purchase", "account_change" -> RiskLevel.HIGH
        else -> RiskLevel.HIGH
    }

    // Safety Directive: Never allow the LLM alone to bypass or downgrade risk!
    fun requiresExplicitUserConfirmation(tool: String): Boolean {
        return evaluate(tool) == RiskLevel.HIGH
    }
}`
  };

  const copyToClipboard = () => {
    navigator.clipboard.writeText(codeSnippets[activeTab]);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/60 backdrop-blur-xs">
      <div className="bg-slate-900 rounded-2xl max-w-3xl w-full max-h-[85vh] flex flex-col shadow-2xl border border-slate-700 overflow-hidden text-white animate-in fade-in zoom-in-95 duration-150">
        {/* Header */}
        <div className="px-6 py-4 border-b border-slate-800 flex items-center justify-between bg-slate-950">
          <div className="flex items-center gap-3">
            <div className="w-8 h-8 rounded-lg bg-emerald-600 text-white flex items-center justify-center">
              <Code2 className="w-4 h-4" />
            </div>
            <div>
              <h3 className="font-semibold text-white text-base">Android Production Integration Specification</h3>
              <p className="text-xs text-slate-400">
                Turnkey Kotlin architecture for physical device APK deployment
              </p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-1.5 rounded-lg text-slate-400 hover:text-white hover:bg-slate-800 transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Tabs */}
        <div className="flex border-b border-slate-800 bg-slate-950/60 px-6 gap-2">
          <button
            onClick={() => setActiveTab('bridge')}
            className={`py-3 px-3 text-xs font-medium border-b-2 transition-colors ${
              activeTab === 'bridge'
                ? 'border-emerald-500 text-emerald-400'
                : 'border-transparent text-slate-400 hover:text-slate-200'
            }`}
          >
            AndroidBridge.kt
          </button>
          <button
            onClick={() => setActiveTab('accessibility')}
            className={`py-3 px-3 text-xs font-medium border-b-2 transition-colors ${
              activeTab === 'accessibility'
                ? 'border-emerald-500 text-emerald-400'
                : 'border-transparent text-slate-400 hover:text-slate-200'
            }`}
          >
            C2AccessibilityService.kt
          </button>
          <button
            onClick={() => setActiveTab('risk')}
            className={`py-3 px-3 text-xs font-medium border-b-2 transition-colors ${
              activeTab === 'risk'
                ? 'border-emerald-500 text-emerald-400'
                : 'border-transparent text-slate-400 hover:text-slate-200'
            }`}
          >
            RiskManager.kt
          </button>
          <button
            onClick={() => setActiveTab('manifest')}
            className={`py-3 px-3 text-xs font-medium border-b-2 transition-colors ${
              activeTab === 'manifest'
                ? 'border-emerald-500 text-emerald-400'
                : 'border-transparent text-slate-400 hover:text-slate-200'
            }`}
          >
            AndroidManifest.xml
          </button>
        </div>

        {/* Code View */}
        <div className="flex-1 overflow-y-auto p-6 bg-slate-950 font-mono text-xs text-slate-300 relative">
          <button
            onClick={copyToClipboard}
            className="absolute top-4 right-4 flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-slate-800 text-slate-300 hover:text-white hover:bg-slate-700 text-xs border border-slate-700 transition-colors"
          >
            {copied ? <Check className="w-3.5 h-3.5 text-emerald-400" /> : <Copy className="w-3.5 h-3.5" />}
            <span>{copied ? 'Copied' : 'Copy Code'}</span>
          </button>
          <pre className="leading-relaxed select-text whitespace-pre-wrap">
            {codeSnippets[activeTab]}
          </pre>
        </div>

        {/* Footer info */}
        <div className="px-6 py-3 border-t border-slate-800 bg-slate-950 flex items-center justify-between text-xs text-slate-400">
          <div className="flex items-center gap-2">
            <ShieldCheck className="w-4 h-4 text-emerald-400" />
            <span>Strict tool allowlisting — never generates arbitrary shell/code execution on device.</span>
          </div>
          <span className="text-[11px] font-mono text-slate-500">Google Play Policy Compliant</span>
        </div>
      </div>
    </div>
  );
};
