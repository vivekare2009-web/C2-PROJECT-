import React, { useState } from 'react';
import { X, Code2, Copy, Check, Terminal } from 'lucide-react';

interface AndroidCodeModalProps {
  isOpen: boolean;
  onClose: () => void;
}

export const AndroidCodeModal: React.FC<AndroidCodeModalProps> = ({
  isOpen,
  onClose,
}) => {
  const [activeTab, setActiveTab] = useState<'bridge' | 'accessibility' | 'risk' | 'manifest'>('bridge');
  const [copied, setCopied] = useState(false);

  if (!isOpen) return null;

  const codeSnippets = {
    bridge: `// AndroidBridge.kt - Native Android Bridge for C2
package com.c2.agent.android

import android.content.Context
import android.content.Intent
import android.net.Uri
import android.provider.MediaStore
import android.provider.DocumentsContract
import android.media.session.MediaSessionManager
import android.media.session.PlaybackState

class AndroidBridge(private val context: Context) {

    /**
     * Executes allowlisted tool 'open_app'
     */
    fun openApp(appName: String): ToolResult {
        val packageManager = context.packageManager
        val packageName = resolvePackageForApp(appName) 
            ?: return ToolResult(false, "App '$appName' is not installed.")

        val launchIntent = packageManager.getLaunchIntentForPackage(packageName)
            ?: return ToolResult(false, "No launchable activity found for $packageName.")
            
        launchIntent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        context.startActivity(launchIntent)
        return ToolResult(true, "$appName opened successfully.")
    }

    /**
     * Scoped Storage file finder (Scoped MediaStore query)
     */
    fun findFile(filename: String): ToolResult {
        val projection = arrayOf(
            MediaStore.Files.FileColumns._ID,
            MediaStore.Files.FileColumns.DISPLAY_NAME,
            MediaStore.Files.FileColumns.SIZE,
            MediaStore.Files.FileColumns.RELATIVE_PATH
        )
        val selection = "\${MediaStore.Files.FileColumns.DISPLAY_NAME} LIKE ?"
        val selectionArgs = arrayOf("%$filename%")

        context.contentResolver.query(
            MediaStore.Files.getContentUri("external"),
            projection, selection, selectionArgs, null
        )?.use { cursor ->
            val matches = mutableListOf<FileMetadata>()
            while (cursor.moveToNext()) {
                val id = cursor.getString(0)
                val name = cursor.getString(1)
                val size = cursor.getLong(2)
                val path = cursor.getString(3)
                matches.add(FileMetadata(id, name, path, size))
            }
            return ToolResult(true, "Found \${matches.size} files.", matches)
        }
        return ToolResult(false, "File search failed.")
    }
}`,
    accessibility: `// C2AccessibilityService.kt - Controlled UI Automation
package com.c2.agent.accessibility

import android.accessibilityservice.AccessibilityService
import android.view.accessibility.AccessibilityEvent
import android.view.accessibility.AccessibilityNodeInfo
import android.os.Bundle

class C2AccessibilityService : AccessibilityService() {

    companion object {
        var instance: C2AccessibilityService? = null
    }

    override fun onServiceConnected() {
        super.onServiceConnected()
        instance = this
    }

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {
        // Observes foreground package and window changes without unauthorized logging
    }

    override fun onInterrupt() {}

    /**
     * Safe Click by Element ID or Text target
     */
    fun performClick(targetText: String): Boolean {
        val rootNode = rootInActiveWindow ?: return false
        val nodes = rootNode.findAccessibilityNodeInfosByText(targetText)
        for (node in nodes) {
            if (node.isClickable && node.performAction(AccessibilityNodeInfo.ACTION_CLICK)) {
                return true
            }
            // Bubble to clickable parent
            var parent = node.parent
            while (parent != null) {
                if (parent.isClickable && parent.performAction(AccessibilityNodeInfo.ACTION_CLICK)) {
                    return true
                }
                parent = parent.parent
            }
        }
        return false
    }

    /**
     * Safe Type text into focused input
     */
    fun performType(text: String): Boolean {
        val rootNode = rootInActiveWindow ?: return false
        val focused = rootNode.findFocus(AccessibilityNodeInfo.FOCUS_INPUT) ?: return false
        val arguments = Bundle().apply {
            putCharSequence(AccessibilityNodeInfo.ACTION_ARGUMENT_SET_TEXT_CHARSEQUENCE, text)
        }
        return focused.performAction(AccessibilityNodeInfo.ACTION_SET_TEXT, arguments)
    }
}`,
    risk: `// RiskManager.kt - Independent Security Gate
package com.c2.agent.security

enum class RiskLevel { LOW, MEDIUM, HIGH }

object RiskManager {
    private val toolRisks = mapOf(
        "open_app" to RiskLevel.LOW,
        "find_file" to RiskLevel.LOW,
        "media_control" to RiskLevel.LOW,
        "open_settings" to RiskLevel.LOW,
        "rename_file" to RiskLevel.MEDIUM,
        "move_file" to RiskLevel.MEDIUM,
        "take_screenshot" to RiskLevel.MEDIUM,
        "accessibility_action" to RiskLevel.MEDIUM,
        "delete_file" to RiskLevel.HIGH,
        "send_message" to RiskLevel.HIGH
    )

    fun getRisk(toolName: String): RiskLevel = toolRisks[toolName] ?: RiskLevel.HIGH

    /**
     * CRITICAL RULE: High risk tools MUST require explicit user confirmation.
     * The LLM alone can NEVER bypass this check.
     */
    fun requiresUserConfirmation(toolName: String): Boolean {
        return getRisk(toolName) == RiskLevel.HIGH
    }
}`,
    manifest: `<!-- AndroidManifest.xml snippet for C2 Native App -->
<manifest xmlns:android="http://schemas.android.com/apk/res/android"
    package="com.c2.agent">

    <uses-permission android:name="android.permission.RECORD_AUDIO" />
    <uses-permission android:name="android.permission.READ_MEDIA_DOCUMENTS" />
    <uses-permission android:name="android.permission.READ_MEDIA_IMAGES" />
    <uses-permission android:name="android.permission.MEDIA_CONTENT_CONTROL" />
    <uses-permission android:name="android.permission.QUERY_ALL_PACKAGES" />

    <application
        android:label="C2 Personal AI"
        android:icon="@mipmap/ic_launcher">

        <!-- Accessibility Service for automated gestures -->
        <service
            android:name=".accessibility.C2AccessibilityService"
            android:permission="android.permission.BIND_ACCESSIBILITY_SERVICE"
            android:exported="false">
            <intent-filter>
                <action android:name="android.accessibilityservice.AccessibilityService" />
            </intent-filter>
            <meta-data
                android:name="android.accessibilityservice"
                android:resource="@xml/accessibility_service_config" />
        </service>
    </application>
</manifest>`,
  };

  const handleCopy = () => {
    navigator.clipboard.writeText(codeSnippets[activeTab]);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/60 backdrop-blur-xs">
      <div className="bg-slate-900 text-slate-100 rounded-2xl max-w-3xl w-full max-h-[85vh] flex flex-col shadow-2xl border border-slate-800 overflow-hidden animate-in fade-in zoom-in-95 duration-150">
        {/* Header */}
        <div className="px-6 py-4 border-b border-slate-800 flex items-center justify-between bg-slate-950">
          <div className="flex items-center gap-2.5">
            <div className="w-8 h-8 rounded-lg bg-emerald-600 text-white flex items-center justify-center">
              <Code2 className="w-4 h-4" />
            </div>
            <div>
              <h3 className="font-semibold text-white text-base">Android Integration Specification</h3>
              <p className="text-xs text-slate-400">
                Phase 7/8 Native Kotlin & AccessibilityService Implementation Specs
              </p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-1 rounded-lg text-slate-400 hover:text-white hover:bg-slate-800 transition-colors cursor-pointer"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Tab switcher */}
        <div className="flex items-center gap-2 px-6 pt-3 bg-slate-950 border-b border-slate-800 text-xs">
          <button
            onClick={() => setActiveTab('bridge')}
            className={`px-3 py-1.5 font-medium border-b-2 transition-colors cursor-pointer ${
              activeTab === 'bridge'
                ? 'border-emerald-500 text-emerald-400'
                : 'border-transparent text-slate-400 hover:text-slate-200'
            }`}
          >
            AndroidBridge.kt
          </button>
          <button
            onClick={() => setActiveTab('accessibility')}
            className={`px-3 py-1.5 font-medium border-b-2 transition-colors cursor-pointer ${
              activeTab === 'accessibility'
                ? 'border-emerald-500 text-emerald-400'
                : 'border-transparent text-slate-400 hover:text-slate-200'
            }`}
          >
            AccessibilityService.kt
          </button>
          <button
            onClick={() => setActiveTab('risk')}
            className={`px-3 py-1.5 font-medium border-b-2 transition-colors cursor-pointer ${
              activeTab === 'risk'
                ? 'border-emerald-500 text-emerald-400'
                : 'border-transparent text-slate-400 hover:text-slate-200'
            }`}
          >
            RiskManager.kt
          </button>
          <button
            onClick={() => setActiveTab('manifest')}
            className={`px-3 py-1.5 font-medium border-b-2 transition-colors cursor-pointer ${
              activeTab === 'manifest'
                ? 'border-emerald-500 text-emerald-400'
                : 'border-transparent text-slate-400 hover:text-slate-200'
            }`}
          >
            AndroidManifest.xml
          </button>
        </div>

        {/* Code Content */}
        <div className="relative flex-1 p-4 overflow-y-auto bg-slate-950 font-mono text-xs text-slate-300">
          <button
            onClick={handleCopy}
            className="absolute top-4 right-4 flex items-center gap-1 px-2.5 py-1 bg-slate-800 hover:bg-slate-700 text-slate-300 rounded text-[11px] transition-colors cursor-pointer"
          >
            {copied ? <Check className="w-3.5 h-3.5 text-emerald-400" /> : <Copy className="w-3.5 h-3.5" />}
            <span>{copied ? 'Copied' : 'Copy'}</span>
          </button>
          <pre className="whitespace-pre-wrap leading-relaxed">
            {codeSnippets[activeTab]}
          </pre>
        </div>

        {/* Footer */}
        <div className="px-6 py-3 bg-slate-950 border-t border-slate-800 flex items-center justify-between text-xs text-slate-400">
          <span>Target Platform: Android 14+ (API 34) Scoped Storage & MediaController</span>
          <button
            onClick={onClose}
            className="px-4 py-1.5 bg-emerald-600 hover:bg-emerald-500 text-white rounded-lg text-xs font-semibold transition-colors cursor-pointer"
          >
            Close
          </button>
        </div>
      </div>
    </div>
  );
};
