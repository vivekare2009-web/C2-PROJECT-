import React, { useEffect, useRef } from 'react';
import { AtmosphereTheme } from '../types';

interface AtmosphereBackgroundProps {
  theme: AtmosphereTheme;
  intensity: number; // 0 to 100 based on audio activity
}

export const AtmosphereBackground: React.FC<AtmosphereBackgroundProps> = ({
  theme,
  intensity,
}) => {
  const canvasRef = useRef<HTMLCanvasElement | null>(null);
  const intensityRef = useRef(intensity);
  intensityRef.current = intensity;

  const themeRef = useRef(theme);
  themeRef.current = theme;

  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;

    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    let animId: number;
    let width = (canvas.width = window.innerWidth || 1280);
    let height = (canvas.height = window.innerHeight || 800);

    const handleResize = () => {
      if (!canvas) return;
      width = canvas.width = window.innerWidth || 1280;
      height = canvas.height = window.innerHeight || 800;
    };

    window.addEventListener('resize', handleResize);

    // Particle nodes allocated ONCE
    const particleCount = 40;
    const particles = Array.from({ length: particleCount }, () => ({
      x: Math.random() * width,
      y: Math.random() * height,
      radius: Math.random() * 1.6 + 0.6,
      vx: (Math.random() - 0.5) * 0.35,
      vy: (Math.random() - 0.5) * 0.35,
      alpha: Math.random() * 0.5 + 0.2,
    }));

    let tick = 0;

    const render = () => {
      try {
        tick++;
        ctx.clearRect(0, 0, width, height);

        const currentIntensity = intensityRef.current || 0;
        const currentTheme = themeRef.current || 'nebula';
        const maxDim = Math.max(width, height, 200);

        // Draw futuristic ambient background gradient safely
        const gradient = ctx.createRadialGradient(
          width / 2,
          height / 2,
          50,
          width / 2,
          height / 2,
          maxDim * 0.8
        );

        const boost = (currentIntensity / 100) * 0.3;

        if (currentTheme === 'cyberpunk') {
          gradient.addColorStop(0, `rgba(217, 70, 239, ${0.12 + boost})`);
          gradient.addColorStop(0.5, `rgba(6, 182, 212, ${0.06 + boost * 0.5})`);
          gradient.addColorStop(1, 'rgba(3, 7, 18, 0.98)');
        } else if (currentTheme === 'aurora') {
          gradient.addColorStop(0, `rgba(16, 185, 129, ${0.14 + boost})`);
          gradient.addColorStop(0.5, `rgba(14, 165, 233, ${0.08 + boost * 0.5})`);
          gradient.addColorStop(1, 'rgba(2, 6, 23, 0.98)');
        } else if (currentTheme === 'midnight') {
          gradient.addColorStop(0, `rgba(99, 102, 241, ${0.12 + boost})`);
          gradient.addColorStop(0.5, `rgba(30, 41, 59, ${0.15 + boost * 0.5})`);
          gradient.addColorStop(1, 'rgba(2, 4, 10, 0.99)');
        } else {
          // nebula (default)
          gradient.addColorStop(0, `rgba(139, 92, 246, ${0.15 + boost})`);
          gradient.addColorStop(0.5, `rgba(236, 72, 153, ${0.08 + boost * 0.5})`);
          gradient.addColorStop(1, 'rgba(5, 5, 16, 0.98)');
        }

        ctx.fillStyle = gradient;
        ctx.fillRect(0, 0, width, height);

        // Draw subtle futuristic cyber grid lines
        ctx.strokeStyle = 'rgba(255, 255, 255, 0.012)';
        ctx.lineWidth = 1;
        const gridSize = 60;
        const xOffset = (tick * 0.15) % gridSize;

        for (let x = xOffset; x < width; x += gridSize) {
          ctx.beginPath();
          ctx.moveTo(x, 0);
          ctx.lineTo(x, height);
          ctx.stroke();
        }

        // Draw Floating stardust particles
        for (let idx = 0; idx < particles.length; idx++) {
          const p = particles[idx];
          p.x += p.vx * (1 + boost * 1.5);
          p.y += p.vy * (1 + boost * 1.5);

          if (p.x < 0) p.x = width;
          if (p.x > width) p.x = 0;
          if (p.y < 0) p.y = height;
          if (p.y > height) p.y = 0;

          const pAlpha = p.alpha * (0.6 + Math.sin((tick + idx * 10) * 0.05) * 0.4);
          ctx.fillStyle = `rgba(255, 255, 255, ${pAlpha})`;
          ctx.beginPath();
          ctx.arc(p.x, p.y, p.radius + boost * 1.2, 0, Math.PI * 2);
          ctx.fill();
        }
      } catch (e) {
        console.warn('[AtmosphereBackground] render warning:', e);
      }

      animId = requestAnimationFrame(render);
    };

    render();

    return () => {
      window.removeEventListener('resize', handleResize);
      cancelAnimationFrame(animId);
    };
  }, []); // Run ONCE on mount

  return (
    <div className="fixed inset-0 pointer-events-none -z-10 overflow-hidden bg-[#030712]">
      <canvas ref={canvasRef} className="w-full h-full block" />
      {/* Vignette border for cinematic look */}
      <div className="absolute inset-0 shadow-[inset_0_0_120px_rgba(0,0,0,0.85)]" />
    </div>
  );
};

