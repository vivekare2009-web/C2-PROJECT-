import React from 'react';
import { AgentStatus, EmotionalState } from '../types';
import { VoiceEngineStatus } from './VoiceEngineStatus';
import { 
  Bot, 
  Mic, 
  Cpu, 
  CheckCircle2, 
  AlertTriangle, 
  XCircle, 
  Clock, 
  Smartphone, 
  Database, 
  Code2, 
  UserCircle 
} from 'lucide-react';

interface HeaderProps {
  status: AgentStatus;
  emotionalState: EmotionalState;
  activeUser: string;
  isMemoryEnabled: boolean;
  isListening?: boolean;
  onOpenVoiceMode: () => void;
  onOpenMemory: () => void;
  onOpenDevice: () => void;
  onOpenAndroidDocs: () => void;
  isDeviceViewOpen: boolean;
}

export const Header: React.FC<HeaderProps> = ({
  status,
  emotionalState,
  activeUser,
  isMemoryEnabled,
  isListening = false,
  onOpenVoiceMode,
  onOpenMemory,
  onOpenDevice,
  onOpenAndroidDocs,
  isDeviceViewOpen,
}) => {
  const getStatusConfig = (st: AgentStatus) => {
    switch (st) {
      case 'listening':
        return { label: 'Listening...', color: 'text-amber-600 bg-amber-50 border-amber-200', icon: Mic, pulse: true };
      case 'thinking':
        return { label: 'Thinking...', color: 'text-sky-600 bg-sky-50 border-sky-200', icon: Cpu, pulse: true };
      case 'executing':
        return { label: 'Executing Tool...', color: 'text-indigo-600 bg-indigo-50 border-indigo-200', icon: Clock, pulse: true };
      case 'waiting_confirmation':
        return { label: 'Waiting for Confirmation', color: 'text-rose-600 bg-rose-50 border-rose-200', icon: AlertTriangle, pulse: true };
      case 'completed':
        return { label: 'Completed', color: 'text-emerald-600 bg-emerald-50 border-emerald-200', icon: CheckCircle2, pulse: false };
      case 'failed':
        return { label: 'Failed', color: 'text-red-600 bg-red-50 border-red-200', icon: XCircle, pulse: false };
      default:
        return { label: 'Idle / Ready', color: 'text-slate-600 bg-slate-100 border-slate-200', icon: Bot, pulse: false };
    }
  };

  const statusInfo = getStatusConfig(status);
  const StatusIcon = statusInfo.icon;

  const emotionEmojis: Record<EmotionalState, string> = {
    neutral: '⚪ Neutral',
    happy: '😊 Happy',
    excited: '✨ Excited',
    curious: '🔍 Curious',
    concerned: '⚠️ Concerned',
    surprised: '😲 Surprised',
    focused: '🎯 Focused',
    calm: '🌿 Calm',
    confident: '💎 Confident',
    frustrated: '😤 Frustrated',
    relief: '😮‍💨 Relieved',
    amused: '😄 Amused',
    empathetic: '🤝 Empathetic',
  };

  return (
    <header className="w-full bg-white border-b border-slate-200 sticky top-0 z-30 px-4 sm:px-6 py-3 shadow-xs">
      <div className="max-w-7xl mx-auto flex flex-col sm:flex-row sm:items-center justify-between gap-3">
        {/* Logo & Identity */}
        <div className="flex items-center gap-3">
          <div className="relative">
            <div className="w-10 h-10 rounded-xl bg-gradient-to-tr from-indigo-700 via-purple-700 to-pink-600 flex items-center justify-center text-white font-bold tracking-tight shadow-sm">
              C2
            </div>
            <span className="absolute -bottom-1 -right-1 flex h-3 w-3">
              <span className={`animate-ping absolute inline-flex h-full w-full rounded-full ${status === 'idle' ? 'bg-emerald-400 opacity-75' : 'bg-sky-400 opacity-75'}`}></span>
              <span className={`relative inline-flex rounded-full h-3 w-3 ${status === 'idle' ? 'bg-emerald-500' : 'bg-sky-500'}`}></span>
            </span>
          </div>

          <div>
            <div className="flex items-center gap-2">
              <h1 className="text-lg font-semibold tracking-tight text-slate-900">C2</h1>
              <span className="text-xs font-medium uppercase tracking-wider px-2 py-0.5 rounded-full bg-slate-100 text-slate-600 border border-slate-200">
                Personal AI Agent
              </span>
            </div>
            <p className="text-xs text-slate-700 flex items-center gap-2">
              <span>Persona: Female AI</span>
              <span>•</span>
              <span className="text-slate-600 font-medium">Emotion: {emotionEmojis[emotionalState]}</span>
            </p>
          </div>
        </div>

        {/* Live Status Badge & Navigation buttons */}
        <div className="flex items-center flex-wrap gap-2">
          {/* GPT-SoVITS Voice Engine Status */}
          <VoiceEngineStatus />

          {/* Status badge */}
          <div id="c2-agent-status-badge" className={`flex items-center gap-1.5 px-3 py-1.5 rounded-lg border text-xs font-medium ${statusInfo.color}`}>
            <StatusIcon className={`w-3.5 h-3.5 ${statusInfo.pulse ? 'animate-spin' : ''}`} />
            <span>{statusInfo.label}</span>
          </div>

          {/* Talk to C2 Voice Mode Button */}
          <button
            id="header-talk-to-c2-btn"
            onClick={onOpenVoiceMode}
            className={`flex items-center gap-1.5 px-3.5 py-1.5 rounded-lg text-xs font-semibold transition-all shadow-xs cursor-pointer ${
              isListening
                ? 'bg-rose-600 hover:bg-rose-700 text-white ring-2 ring-rose-300 animate-pulse'
                : 'bg-indigo-600 hover:bg-indigo-700 text-white'
            }`}
            title="Open Live Voice Mode to talk with C2"
          >
            <Mic className={`w-3.5 h-3.5 ${isListening ? 'animate-bounce' : ''}`} />
            <span>Talk to C2</span>
          </button>

          {/* Device toggle */}
          <button
            id="toggle-device-view-btn"
            onClick={onOpenDevice}
            className={`flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-xs font-medium transition-colors border ${
              isDeviceViewOpen
                ? 'bg-indigo-50 text-indigo-700 border-indigo-300'
                : 'bg-white text-slate-700 border-slate-200 hover:bg-slate-50'
            }`}
          >
            <Smartphone className="w-3.5 h-3.5 text-indigo-600" />
            <span className="hidden sm:inline">Android</span> Device
          </button>

          {/* Memory Modal button */}
          <button
            id="open-memory-vault-btn"
            onClick={onOpenMemory}
            className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-xs font-medium bg-white text-slate-700 border border-slate-200 hover:bg-slate-50 transition-colors"
          >
            <Database className="w-3.5 h-3.5 text-purple-600" />
            <span>Memory</span>
            {!isMemoryEnabled && <span className="text-rose-500 font-bold">(Off)</span>}
          </button>

          {/* Android Kotlin architecture docs button */}
          <button
            id="open-android-architecture-btn"
            onClick={onOpenAndroidDocs}
            className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-xs font-medium bg-white text-slate-700 border border-slate-200 hover:bg-slate-50 transition-colors"
          >
            <Code2 className="w-3.5 h-3.5 text-emerald-600" />
            <span className="hidden md:inline">Android</span> Spec
          </button>

          {/* Active user badge */}
          <div className="flex items-center gap-1 px-2.5 py-1.5 rounded-lg bg-slate-50 border border-slate-200 text-xs text-slate-600 font-medium">
            <UserCircle className="w-3.5 h-3.5 text-slate-500" />
            <span className="max-w-[80px] truncate">{activeUser}</span>
          </div>
        </div>
      </div>
    </header>
  );
};
