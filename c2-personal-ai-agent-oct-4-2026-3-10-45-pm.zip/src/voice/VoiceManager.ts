export class VoiceManager {
  private recognition: any = null;
  private isListening: boolean = false;
  private isSpeaking: boolean = false;
  private isContinuousMode: boolean = false;
  private currentLang: string = 'en-IN';
  private onTranscriptCallback: ((transcript: string, isFinal: boolean) => void) | null = null;
  private onStatusChangeCallback: ((listening: boolean, speaking: boolean) => void) | null = null;
  private onErrorCallback: ((errorMsg: string) => void) | null = null;
  private onAudioLevelCallback: ((level: number) => void) | null = null;

  // Web Audio API for real-time waveform visualization
  private audioCtx: AudioContext | null = null;
  private analyser: AnalyserNode | null = null;
  private micStream: MediaStream | null = null;
  private animFrameId: number | null = null;
  private permissionStatus: 'prompt' | 'granted' | 'denied' | 'unsupported' = 'prompt';

  constructor() {
    if (typeof window !== 'undefined') {
      const SpeechRecognition =
        (window as any).SpeechRecognition || (window as any).webkitSpeechRecognition;

      if (SpeechRecognition) {
        this.recognition = new SpeechRecognition();
        this.recognition.continuous = false;
        this.recognition.interimResults = true;
        this.recognition.lang = 'en-IN';

        this.recognition.onstart = () => {
          this.isListening = true;
          this.playChime('start');
          this.startAudioAnalysis();
          this.notifyStatus();
        };

        this.recognition.onresult = (event: any) => {
          let interimTranscript = '';
          let finalTranscript = '';

          for (let i = event.resultIndex; i < event.results.length; ++i) {
            const transcript = event.results[i][0].transcript;
            if (event.results[i].isFinal) {
              finalTranscript += transcript;
            } else {
              interimTranscript += transcript;
            }
          }

          if (finalTranscript && this.onTranscriptCallback) {
            this.onTranscriptCallback(finalTranscript.trim(), true);
          } else if (interimTranscript && this.onTranscriptCallback) {
            this.onTranscriptCallback(interimTranscript.trim(), false);
          }
        };

        this.recognition.onerror = (event: any) => {
          console.warn('Speech recognition error:', event.error);
          if (event.error === 'not-allowed' || event.error === 'service-not-allowed') {
            this.permissionStatus = 'denied';
            this.onErrorCallback?.('Microphone access was denied. Please allow microphone permissions in your browser.');
          } else if (event.error === 'no-speech') {
            // Ignored - quiet period
          } else {
            this.onErrorCallback?.(`Voice recognition issue: ${event.error}`);
          }
          this.isListening = false;
          this.stopAudioAnalysis();
          this.notifyStatus();
        };

        this.recognition.onend = () => {
          this.isListening = false;
          this.stopAudioAnalysis();
          this.notifyStatus();

          // If continuous mode is active and we're not speaking, restart listening after a pause
          if (this.isContinuousMode && !this.isSpeaking) {
            setTimeout(() => {
              if (this.isContinuousMode && !this.isListening && !this.isSpeaking) {
                this.startListening(this.currentLang);
              }
            }, 600);
          }
        };
      } else {
        this.permissionStatus = 'unsupported';
      }

      // Preload speech synthesis voices
      if ('speechSynthesis' in window) {
        window.speechSynthesis.onvoiceschanged = () => {
          // Voices ready in cache
        };
      }
    }
  }

  public isSupported(): boolean {
    return this.recognition !== null;
  }

  public getPermissionStatus(): 'prompt' | 'granted' | 'denied' | 'unsupported' {
    return this.permissionStatus;
  }

  public setContinuousMode(enabled: boolean) {
    this.isContinuousMode = enabled;
  }

  public getContinuousMode(): boolean {
    return this.isContinuousMode;
  }

  public setCallbacks(
    onTranscript: (transcript: string, isFinal: boolean) => void,
    onStatusChange: (listening: boolean, speaking: boolean) => void,
    onError?: (errorMsg: string) => void,
    onAudioLevel?: (level: number) => void
  ) {
    this.onTranscriptCallback = onTranscript;
    this.onStatusChangeCallback = onStatusChange;
    if (onError) this.onErrorCallback = onError;
    if (onAudioLevel) this.onAudioLevelCallback = onAudioLevel;
  }

  public async requestMicrophonePermission(): Promise<boolean> {
    if (typeof navigator === 'undefined' || !navigator.mediaDevices?.getUserMedia) {
      return false;
    }
    try {
      const stream = await navigator.mediaDevices.getUserMedia({ audio: true });
      // Stream acquired successfully
      this.permissionStatus = 'granted';
      // Release initial probe stream
      stream.getTracks().forEach((track) => track.stop());
      return true;
    } catch (err: any) {
      console.warn('Microphone permission request error:', err);
      this.permissionStatus = 'denied';
      this.onErrorCallback?.('Microphone permission denied. Please click the lock or camera/mic icon in the browser address bar to allow.');
      return false;
    }
  }

  public async startListening(lang: string = 'en-IN') {
    if (!this.recognition) {
      this.onErrorCallback?.('Speech recognition is not supported in this browser. Please use Chrome, Edge, or Safari.');
      return;
    }
    try {
      this.currentLang = lang;
      this.stopSpeaking();
      this.recognition.lang = lang;
      this.recognition.start();
    } catch (err: any) {
      // If already started or another instance is running
      if (err.name !== 'InvalidStateError') {
        console.warn('Recognition start exception:', err);
      }
    }
  }

  public stopListening() {
    if (!this.recognition) return;
    try {
      this.isContinuousMode = false;
      this.recognition.stop();
      this.isListening = false;
      this.stopAudioAnalysis();
      this.playChime('stop');
      this.notifyStatus();
    } catch (err) {
      console.warn('Recognition stop exception:', err);
    }
  }

  public speak(
    text: string,
    language: 'English' | 'Hindi' | 'Hinglish' = 'English',
    onEnd?: () => void
  ) {
    if (typeof window === 'undefined' || !('speechSynthesis' in window)) {
      onEnd?.();
      return;
    }

    // Stop current speaking
    window.speechSynthesis.cancel();

    // Clean text of markdown, asterisks, brackets or URLs for a smooth, natural spoken audio
    const cleanText = text
      .replace(/[*_#`]/g, '')
      .replace(/https?:\/\/\S+/g, '')
      .replace(/\{[^}]+\}/g, '')
      .replace(/\[[^\]]+\]/g, '')
      .replace(/\s+/g, ' ')
      .trim();

    if (!cleanText) {
      onEnd?.();
      return;
    }

    const utterance = new SpeechSynthesisUtterance(cleanText);

    // Get available voices and select a high quality female voice
    const voices = window.speechSynthesis.getVoices();
    let selectedVoice: SpeechSynthesisVoice | null = null;

    if (language === 'Hindi' || language === 'Hinglish') {
      selectedVoice =
        voices.find(
          (v) =>
            v.lang.startsWith('hi') &&
            (v.name.includes('Female') || v.name.includes('Google') || v.name.includes('Kalpana'))
        ) ||
        voices.find(
          (v) =>
            v.lang.includes('IN') &&
            (v.name.includes('Female') || v.name.includes('Zira') || v.name.includes('Heera'))
        ) ||
        voices.find((v) => v.name.toLowerCase().includes('female')) ||
        null;
    }

    if (!selectedVoice) {
      selectedVoice =
        voices.find(
          (v) =>
            (v.name.includes('Samantha') ||
              v.name.includes('Victoria') ||
              v.name.includes('Karen') ||
              v.name.includes('Zira') ||
              v.name.includes('Google US English') ||
              v.name.includes('Natural')) &&
            !v.name.toLowerCase().includes('male')
        ) ||
        voices.find(
          (v) => v.name.toLowerCase().includes('female') || v.name.toLowerCase().includes('woman')
        ) ||
        voices[0] ||
        null;
    }

    if (selectedVoice) {
      utterance.voice = selectedVoice;
    }

    // Characteristics: Natural, clear, confident, warm, female persona
    utterance.pitch = 1.08;
    utterance.rate = 1.03;

    this.isSpeaking = true;
    this.notifyStatus();

    utterance.onend = () => {
      this.isSpeaking = false;
      this.notifyStatus();
      onEnd?.();

      // If continuous mode was active, resume listening after C2 finishes speaking
      if (this.isContinuousMode && !this.isListening) {
        setTimeout(() => {
          if (this.isContinuousMode && !this.isSpeaking) {
            this.startListening(this.currentLang);
          }
        }, 500);
      }
    };

    utterance.onerror = (e) => {
      console.warn('SpeechSynthesis error:', e);
      this.isSpeaking = false;
      this.notifyStatus();
      onEnd?.();
    };

    window.speechSynthesis.speak(utterance);
  }

  public stopSpeaking() {
    if (typeof window !== 'undefined' && 'speechSynthesis' in window) {
      window.speechSynthesis.cancel();
      this.isSpeaking = false;
      this.notifyStatus();
    }
  }

  // Web Audio API: Connect real microphone for responsive visualizer
  private async startAudioAnalysis() {
    if (typeof window === 'undefined' || !navigator.mediaDevices?.getUserMedia) return;

    try {
      if (!this.audioCtx) {
        const AudioContextClass = window.AudioContext || (window as any).webkitAudioContext;
        this.audioCtx = new AudioContextClass();
      }

      if (this.audioCtx.state === 'suspended') {
        await this.audioCtx.resume();
      }

      if (!this.micStream) {
        this.micStream = await navigator.mediaDevices.getUserMedia({ audio: true });
      }

      this.analyser = this.audioCtx.createAnalyser();
      this.analyser.fftSize = 64;
      this.analyser.smoothingTimeConstant = 0.8;

      const source = this.audioCtx.createMediaStreamSource(this.micStream);
      source.connect(this.analyser);

      const bufferLength = this.analyser.frequencyBinCount;
      const dataArray = new Uint8Array(bufferLength);

      const updateLoop = () => {
        if (!this.isListening || !this.analyser) return;

        this.analyser.getByteFrequencyData(dataArray);
        let sum = 0;
        for (let i = 0; i < bufferLength; i++) {
          sum += dataArray[i];
        }
        const average = sum / bufferLength;
        // Normalized 0 to 100
        const level = Math.min(100, Math.round((average / 255) * 100 * 1.8));

        this.onAudioLevelCallback?.(level);
        this.animFrameId = requestAnimationFrame(updateLoop);
      };

      this.animFrameId = requestAnimationFrame(updateLoop);
    } catch (e) {
      // Microphone audio visualization fallback (synthetic random pulse if user speaks)
      console.warn('Audio visualization analyser init note:', e);
    }
  }

  private stopAudioAnalysis() {
    if (this.animFrameId) {
      cancelAnimationFrame(this.animFrameId);
      this.animFrameId = null;
    }
    if (this.micStream) {
      this.micStream.getTracks().forEach((track) => track.stop());
      this.micStream = null;
    }
    this.onAudioLevelCallback?.(0);
  }

  // Soft subtle auditory cues for listening state transitions
  public playChime(type: 'start' | 'stop') {
    try {
      if (typeof window === 'undefined') return;
      const AudioCtx = window.AudioContext || (window as any).webkitAudioContext;
      if (!AudioCtx) return;
      const ctx = new AudioCtx();
      const osc = ctx.createOscillator();
      const gain = ctx.createGain();

      osc.type = 'sine';
      if (type === 'start') {
        osc.frequency.setValueAtTime(520, ctx.currentTime);
        osc.frequency.exponentialRampToValueAtTime(780, ctx.currentTime + 0.12);
      } else {
        osc.frequency.setValueAtTime(680, ctx.currentTime);
        osc.frequency.exponentialRampToValueAtTime(440, ctx.currentTime + 0.12);
      }

      gain.gain.setValueAtTime(0.04, ctx.currentTime);
      gain.gain.exponentialRampToValueAtTime(0.0001, ctx.currentTime + 0.18);

      osc.connect(gain);
      gain.connect(ctx.destination);

      osc.start();
      osc.stop(ctx.currentTime + 0.2);
    } catch (err) {
      // Non-critical chime error
    }
  }

  private notifyStatus() {
    if (this.onStatusChangeCallback) {
      this.onStatusChangeCallback(this.isListening, this.isSpeaking);
    }
  }
}

