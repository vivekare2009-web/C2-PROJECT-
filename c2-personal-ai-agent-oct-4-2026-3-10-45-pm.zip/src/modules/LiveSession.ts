/**
 * LiveSession
 * Manages WebSocket connection to the server's Gemini Live API bridge.
 * Coordinates AudioStreamer, AudioPlayer, ToolManager, and StateManager.
 * Enforces the complete State Machine:
 * disconnected -> connecting -> listening <-> speaking / thinking / error
 */

import { AudioStreamer } from './AudioStreamer';
import { AudioPlayer } from './AudioPlayer';
import { ToolManager } from './ToolManager';
import { StateManager } from './StateManager';
import { gptSoVITSProvider } from '../services/GPTSoVITSProvider';
import { avatarVideoStateManager } from './avatar/AvatarVideoStateManager';

export interface LiveSessionOptions {
  voice?: string;
}

export class LiveSession {
  private ws: WebSocket | null = null;
  private streamer: AudioStreamer;
  private player: AudioPlayer;
  private toolManager: ToolManager;
  private stateManager: StateManager;

  private isConnected: boolean = false;
  private isConnecting: boolean = false;
  private isExplicitDisconnect: boolean = false;
  private engineMode: 'gemini_live' | 'local_brain' = 'gemini_live';
  private pingInterval: number | null = null;
  private lastPingTime: number = 0;
  private speechStartTime: number = 0;
  private firstAudioChunkReceived: boolean = false;

  private recognition: any = null;
  private isSpeechRecognitionActive: boolean = false;
  private speechAnimInterval: number | null = null;
  private speechResponseListeners: Set<(text: string, language: string) => void> = new Set();
  private quotaListeners: Set<(message: string) => void> = new Set();

  constructor(
    streamer: AudioStreamer,
    player: AudioPlayer,
    toolManager: ToolManager,
    stateManager: StateManager
  ) {
    this.streamer = streamer;
    this.player = player;
    this.toolManager = toolManager;
    this.stateManager = stateManager;

    // Connect AudioStreamer chunks to WebSocket
    this.streamer.setCallbacks(
      (base64Audio) => {
        if (this.engineMode === 'gemini_live') {
          this.sendAudioChunk(base64Audio);
        }
      },
      (level) => {
        this.stateManager.setInputLevel(level);

        // Track user speech activity for latency measurement
        if (level > 20) {
          if (this.speechStartTime === 0) {
            this.speechStartTime = performance.now();
            this.firstAudioChunkReceived = false;
          }
        }

        // Natural user interruption: if user speaks loudly while C2 is speaking
        const isSpeaking =
          this.player.getIsSpeaking() ||
          (typeof window !== 'undefined' && window.speechSynthesis && window.speechSynthesis.speaking);

        if (level > 35 && isSpeaking) {
          console.log('[VOICE] User speaking detected while C2 is speaking. Interrupting.');
          this.interrupt();
        }
      }
    );

    // Connect AudioPlayer speaking state to StateManager and AvatarVideoStateManager
    this.player.setCallbacks(
      (speaking) => {
        if (speaking) {
          avatarVideoStateManager.onSpeechStarted();
        } else {
          avatarVideoStateManager.onSpeechFinished();
        }

        if (this.isConnected && this.engineMode === 'gemini_live') {
          const currentState = this.stateManager.getState().connectionState;
          if (speaking) {
            this.stateManager.setConnectionState('speaking');
          } else if (currentState === 'speaking') {
            this.stateManager.setConnectionState('listening');
          }
        }
      },
      (level) => {
        if (this.engineMode === 'gemini_live') {
          this.stateManager.setOutputLevel(level);
        }
      }
    );

    // Tool event listener
    this.toolManager.onToolEvent((event) => {
      this.stateManager.recordToolEvent(event);
    });

    this.toolManager.onAtmosphereChange((theme) => {
      this.stateManager.setAtmosphere(theme);
    });
  }

  /**
   * Connect to Gemini Live Session
   */
  public async connect(): Promise<boolean> {
    // Prevent duplicate sessions
    if (this.isConnected || this.isConnecting) {
      console.log('[LIVE] Session already connecting or connected. Ignoring duplicate connect call.');
      return true;
    }

    console.log('[LIVE] Initializing connection to C2 Voice System...');
    this.isConnecting = true;
    this.isExplicitDisconnect = false;
    this.firstAudioChunkReceived = false;
    this.speechStartTime = 0;
    this.stateManager.setConnectionState('connecting');
    this.stateManager.setError(null);

    // 1. Request microphone access
    const micResult = await this.streamer.start();
    if (!micResult.success) {
      if (micResult.isPermissionDenied) {
        console.warn('[LIVE] Microphone permission denied or blocked. Connecting in Speaker & Text mode...');
        this.stateManager.setMicPermission('denied');
        this.stateManager.setNotice(
          'Microphone permission is blocked or denied. Connected in Speaker & Text mode — you can type commands and hear C2 speak.'
        );
      } else {
        console.warn('[VOICE] Microphone initialization notice:', micResult.error);
        this.stateManager.setNotice(
          micResult.error || 'Microphone unavailable. Connected in Speaker & Text mode.'
        );
      }
    } else {
      this.stateManager.setMicPermission('granted');
    }

    // 2. Establish WebSocket connection to /live endpoint
    const protocol = window.location.protocol === 'https:' ? 'wss:' : 'ws:';
    const host = window.location.host;
    const wsUrl = `${protocol}//${host}/live`;

    try {
      console.log(`[LIVE] Opening WebSocket connection to ${wsUrl}...`);
      this.ws = new WebSocket(wsUrl);

      return new Promise<boolean>((resolve) => {
        const connectionTimeout = window.setTimeout(() => {
          if (this.isConnecting) {
            console.error('[LIVE] WebSocket connection timed out after 12s');
            this.cleanup();
            this.stateManager.setConnectionState('error');
            this.stateManager.setError('Connection to C2 Live service timed out.');
            resolve(false);
          }
        }, 12000);

        this.ws!.onopen = () => {
          console.log('[LIVE] WebSocket connection established. Sending initialization payload...');
          clearTimeout(connectionTimeout);
          this.isConnected = true;
          this.isConnecting = false;

          // Send init handshake with chosen voice, userId, & tool configuration
          const state = this.stateManager.getState();
          const currentVoice = state.selectedVoice || 'Aoede';
          const userId = state.currentUser?.id;
          if (userId) {
            this.toolManager.setCurrentUserId(userId);
          }

          this.sendMessage({
            type: 'init',
            voice: currentVoice,
            userId,
            tools: ToolManager.getFunctionDeclarations(),
          });

          this.stateManager.setConnectionState('listening');
          this.startHeartbeat();
          resolve(true);
        };

        this.ws!.onmessage = (event) => {
          this.handleServerMessage(event.data);
        };

        this.ws!.onerror = (err) => {
          console.warn('[LIVE] WebSocket error event encountered:', err);
        };

        this.ws!.onclose = (event) => {
          console.log(`[LIVE] WebSocket closed. Code: ${event.code}, Reason: "${event.reason || 'None'}"`);
          clearTimeout(connectionTimeout);

          const wasConnecting = this.isConnecting;
          const currentErr = this.stateManager.getState().lastError;

          this.cleanup();

          if (this.isExplicitDisconnect) {
            this.stateManager.setConnectionState('disconnected');
          } else if (currentErr) {
            this.stateManager.setConnectionState('error');
          } else {
            this.stateManager.setConnectionState('disconnected');
          }

          if (wasConnecting) {
            resolve(false);
          }
        };
      });
    } catch (err: any) {
      console.error('[LIVE] Error opening WebSocket:', err);
      this.cleanup();
      this.stateManager.setConnectionState('error');
      this.stateManager.setError(err?.message || 'Failed to initialize voice session.');
      return false;
    }
  }

  /**
   * Handle server messages from the Live API proxy
   */
  private async handleServerMessage(rawData: string) {
    try {
      const msg = JSON.parse(rawData);

      switch (msg.type) {
        case 'connected': {
          console.log('[LIVE] C2 Live Session Connected:', msg.model);
          const isLocal = msg.engine === 'local_brain';
          this.engineMode = isLocal ? 'local_brain' : 'gemini_live';
          this.stateManager.setEngineMode(this.engineMode);
          this.stateManager.setConnectionState('listening');
          if (msg.notice) {
            this.stateManager.setNotice(msg.notice);
          }
          if (isLocal) {
            this.startSpeechRecognition();
          }
          break;
        }

        case 'fallback_mode': {
          console.log('[LIVE] Switched to C2 Local Voice Engine:', msg.notice);
          this.engineMode = 'local_brain';
          this.stateManager.setEngineMode('local_brain');
          this.stateManager.setConnectionState('listening');
          if (msg.notice) {
            this.stateManager.setNotice(msg.notice);
          }
          this.startSpeechRecognition();
          break;
        }

        case 'speech_response': {
          console.log('[LIVE] Speech response received:', msg.text);
          this.speechResponseListeners.forEach((fn) => {
            try {
              fn(msg.text, msg.language || 'English');
            } catch (_) {}
          });

          // Record executed tools
          if (Array.isArray(msg.tools)) {
            for (const t of msg.tools) {
              this.stateManager.recordToolEvent({
                id: `local_tc_${Date.now()}_${Math.random().toString(36).substring(7)}`,
                name: t.tool,
                args: t.args || {},
                result: t.result,
                timestamp: Date.now(),
                status: t.result?.success !== false ? 'completed' : 'failed',
              });
            }
          }

          // Update user profile/memories if returned
          if (msg.user) {
            this.stateManager.setCurrentUser(msg.user, msg.memories || []);
          }

          this.speakText(msg.text, msg.language || 'English');
          break;
        }

        case 'audio': {
          if (msg.data) {
            // Log response latency on first chunk
            if (!this.firstAudioChunkReceived && this.speechStartTime > 0) {
              const latency = Math.round(performance.now() - this.speechStartTime);
              console.log(`[PERFORMANCE] Gemini Live speech latency: ${latency}ms`);
              this.firstAudioChunkReceived = true;
            }
            this.player.playChunk(msg.data);
          }
          break;
        }

        case 'interrupted': {
          console.log('[LIVE] Interruption signal received from server.');
          this.player.interrupt();
          this.stateManager.setConnectionState('listening');
          break;
        }

        case 'turn_complete': {
          // Model finished speaking turn
          break;
        }

        case 'tool_call': {
          console.log('[LIVE] Tool call requested by model:', msg.functionCalls);
          this.stateManager.setConnectionState('thinking');

          if (Array.isArray(msg.functionCalls)) {
            const responses = [];

            for (const call of msg.functionCalls) {
              const callId = call.id || `tc_${Date.now()}`;
              const toolName = call.name;
              const toolArgs = call.args || {};

              console.log(`[LIVE] Executing tool: ${toolName}`, toolArgs);
              const toolOutput = await this.toolManager.executeTool(toolName, toolArgs, callId);

              responses.push({
                name: toolName,
                id: callId,
                response: { output: toolOutput },
              });
            }

            // Immediately send tool response back to Gemini Live
            this.sendMessage({
              type: 'tool_response',
              functionResponses: responses,
            });
          }
          break;
        }

        case 'pong': {
          if (this.lastPingTime > 0) {
            const rtt = Date.now() - this.lastPingTime;
            this.stateManager.setLatency(Math.max(12, rtt));
          }
          break;
        }

        case 'key_rotated': {
          console.log('[LIVE] Gemini API key rotated to backup:', msg.message);
          this.stateManager.setNotice(
            msg.message || 'Primary Gemini key quota reached. Automatically switched to backup key.'
          );
          break;
        }

        case 'quota_exhausted': {
          console.warn('[LIVE] Gemini API quota exhausted:', msg.message);
          this.stateManager.setNotice(
            msg.message || 'Gemini API key quota has been exhausted. Please enter another key.'
          );
          this.quotaListeners.forEach((listener) => listener(msg.message || 'Quota exhausted.'));
          break;
        }

        case 'error': {
          console.warn('[LIVE] Server emitted notice:', msg.message);
          avatarVideoStateManager.onTaskError(msg.message);
          // If API key or quota issue, gracefully switch to C2 Local Voice Engine
          if (
            msg.message &&
            (msg.message.includes('API key') ||
              msg.message.includes('API_KEY_INVALID') ||
              msg.message.includes('quota') ||
              msg.message.includes('RESOURCE_EXHAUSTED'))
          ) {
            console.log('[LIVE] Operating on C2 Local Voice Engine (key advisory).');
            this.engineMode = 'local_brain';
            this.stateManager.setEngineMode('local_brain');
            this.stateManager.setNotice(
              'Operating on C2 Local Voice Engine. (Verify GEMINI_API_KEY in Settings > Secrets for Gemini Live 24kHz stream).'
            );
            this.stateManager.setConnectionState('listening');
            this.startSpeechRecognition();
          } else {
            this.stateManager.setError(msg.message || 'Voice session notice.');
            this.stateManager.setConnectionState('error');
          }
          break;
        }
      }
    } catch (err) {
      console.error('[LIVE] Failed to parse server message:', err);
    }
  }

  /**
   * Sends audio PCM chunk to the server
   */
  private sendAudioChunk(base64Pcm: string) {
    if (!this.isConnected || !this.ws || this.ws.readyState !== WebSocket.OPEN) return;

    this.sendMessage({
      type: 'audio',
      data: base64Pcm,
    });
  }

  /**
   * Sends user speech transcript to C2 Local Voice Engine
   */
  public sendSpeechInput(text: string) {
    if (!text.trim() || !this.isConnected) return;
    this.stateManager.setConnectionState('thinking');
    avatarVideoStateManager.onTaskStarted(text.trim());
    this.sendMessage({
      type: 'user_speech',
      text: text.trim(),
    });
  }

  /**
   * Sends text input command to C2 Engine
   */
  public sendTextMessage(text: string) {
    if (!text.trim() || !this.isConnected) return;
    this.stateManager.setConnectionState('thinking');
    avatarVideoStateManager.onTaskStarted(text.trim());
    this.sendMessage({
      type: 'text_input',
      text: text.trim(),
    });
  }

  /**
   * Subscribe to C2 speech responses
   */
  public onSpeechResponse(callback: (text: string, language: string) => void): () => void {
    this.speechResponseListeners.add(callback);
    return () => this.speechResponseListeners.delete(callback);
  }

  /**
   * User interrupts C2 speaking
   */
  public interrupt() {
    gptSoVITSProvider.cancelSpeech();
    gptSoVITSProvider.setSpeaking(false);
    avatarVideoStateManager.onSpeechInterrupted();

    if (typeof window !== 'undefined' && window.speechSynthesis) {
      window.speechSynthesis.cancel();
    }
    if (this.speechAnimInterval !== null) {
      clearInterval(this.speechAnimInterval);
      this.speechAnimInterval = null;
    }

    this.player.interrupt();
    this.stateManager.setOutputLevel(0);

    if (this.isConnected) {
      this.stateManager.setConnectionState('listening');
      if (this.engineMode === 'local_brain') {
        this.startSpeechRecognition();
      }
    }

    if (this.isConnected && this.ws && this.ws.readyState === WebSocket.OPEN) {
      this.sendMessage({
        type: 'interrupt',
      });
    }
  }

  /**
   * Browser SpeechRecognition integration for Local Voice Mode
   */
  private startSpeechRecognition() {
    if (typeof window === 'undefined') return;
    const SpeechRecognition =
      (window as any).SpeechRecognition || (window as any).webkitSpeechRecognition;

    if (!SpeechRecognition) {
      console.log('[LIVE] Browser SpeechRecognition not available; voice input via microphone level active.');
      return;
    }

    if (this.isSpeechRecognitionActive) return;

    try {
      if (this.recognition) {
        try {
          this.recognition.abort();
        } catch (_) {}
      }

      const recognition = new SpeechRecognition();
      this.recognition = recognition;
      recognition.continuous = false;
      recognition.interimResults = true;
      recognition.maxAlternatives = 1;
      recognition.lang = 'en-US';

      recognition.onstart = () => {
        this.isSpeechRecognitionActive = true;
        console.log('[LIVE] SpeechRecognition active. Listening for user...');
      };

      recognition.onresult = (event: any) => {
        let interim = '';
        let final = '';

        for (let i = event.resultIndex; i < event.results.length; ++i) {
          if (event.results[i].isFinal) {
            final += event.results[i][0].transcript;
          } else {
            interim += event.results[i][0].transcript;
          }
        }

        if (interim) {
          this.stateManager.setInputLevel(Math.min(85, 30 + interim.length * 2));
        }

        if (final.trim()) {
          console.log('[LIVE] SpeechRecognition final result:', final);
          this.sendSpeechInput(final.trim());
        }
      };

      recognition.onerror = (event: any) => {
        if (event.error !== 'no-speech') {
          console.warn('[LIVE] SpeechRecognition notice:', event.error);
        }
        this.isSpeechRecognitionActive = false;
      };

      recognition.onend = () => {
        this.isSpeechRecognitionActive = false;
        const st = this.stateManager.getState().connectionState;
        if (this.isConnected && this.engineMode === 'local_brain' && st === 'listening') {
          window.setTimeout(() => {
            if (
              this.isConnected &&
              this.engineMode === 'local_brain' &&
              !this.isSpeechRecognitionActive &&
              this.stateManager.getState().connectionState === 'listening'
            ) {
              this.startSpeechRecognition();
            }
          }, 300);
        }
      };

      recognition.start();
    } catch (err) {
      console.warn('[LIVE] Could not start SpeechRecognition:', err);
      this.isSpeechRecognitionActive = false;
    }
  }

  private stopSpeechRecognition() {
    if (this.recognition) {
      try {
        this.recognition.abort();
      } catch (_) {}
      this.recognition = null;
    }
    this.isSpeechRecognitionActive = false;
  }

  /**
   * C2 Voice Output:
   * Generates speech via GPT-SoVITS with the authorized Euphemiya reference voice.
   * If GPT-SoVITS is offline or unreachable, seamlessly uses existing fallback voice.
   */
  private async speakText(text: string, language: string = 'English', onComplete?: () => void) {
    // Cancel any previous speech immediately
    gptSoVITSProvider.cancelSpeech();
    this.player.interrupt();
    if (typeof window !== 'undefined' && window.speechSynthesis) {
      window.speechSynthesis.cancel();
    }
    if (this.speechAnimInterval !== null) {
      clearInterval(this.speechAnimInterval);
      this.speechAnimInterval = null;
    }

    this.stopSpeechRecognition();

    const isSovitsUsable =
      gptSoVITSProvider.getStatus() === 'GPT-SOVITS READY' ||
      gptSoVITSProvider.getStatus() === 'GPT-SOVITS CONNECTING';

    if (isSovitsUsable) {
      try {
        this.stateManager.setConnectionState('thinking');
        const audioData = await gptSoVITSProvider.generateSpeech(text, { language });
        if (audioData && audioData.byteLength > 44) {
          this.stateManager.setConnectionState('speaking');
          gptSoVITSProvider.setSpeaking(true);
          const played = await this.player.playWavAudio(audioData);
          gptSoVITSProvider.setSpeaking(false);

          if (played) {
            if (this.isConnected) {
              this.stateManager.setConnectionState('listening');
              if (this.engineMode === 'local_brain') {
                this.startSpeechRecognition();
              }
            }
            onComplete?.();
            return;
          }
        }
      } catch (sovitsErr) {
        console.warn('[LIVE] GPT-SoVITS speech synthesis error, using fallback voice:', sovitsErr);
        gptSoVITSProvider.setSpeaking(false);
      }
    }

    // Fallback: Browser SpeechSynthesis for natural voice output
    this.fallbackSpeakText(text, language, onComplete);
  }

  private fallbackSpeakText(text: string, language: string = 'English', onComplete?: () => void) {
    if (typeof window === 'undefined' || !window.speechSynthesis) {
      onComplete?.();
      return;
    }

    // Cancel any previous speech
    window.speechSynthesis.cancel();
    if (this.speechAnimInterval !== null) {
      clearInterval(this.speechAnimInterval);
      this.speechAnimInterval = null;
    }

    this.stopSpeechRecognition();
    this.stateManager.setConnectionState('speaking');
    avatarVideoStateManager.onSpeechStarted();

    // Visual waveform pulse animation during speech output
    this.speechAnimInterval = window.setInterval(() => {
      const randomLevel = Math.floor(Math.random() * 55) + 35;
      this.stateManager.setOutputLevel(randomLevel);
    }, 90);

    const utterance = new SpeechSynthesisUtterance(text);
    utterance.rate = 1.02;
    utterance.pitch = 1.08;

    // Select optimal natural female voice
    const voices = window.speechSynthesis.getVoices();
    const preferredVoice =
      voices.find(
        (v) =>
          v.name.includes('Google') ||
          v.name.includes('Samantha') ||
          v.name.includes('Zira') ||
          v.name.includes('Kalpana') ||
          (v.name.toLowerCase().includes('female') && v.lang.startsWith('en'))
      ) || voices.find((v) => v.lang.startsWith('en'));

    if (preferredVoice) {
      utterance.voice = preferredVoice;
    }

    const finishSpeaking = () => {
      avatarVideoStateManager.onSpeechFinished();
      if (this.speechAnimInterval !== null) {
        clearInterval(this.speechAnimInterval);
        this.speechAnimInterval = null;
      }
      this.stateManager.setOutputLevel(0);
      if (this.isConnected) {
        this.stateManager.setConnectionState('listening');
        if (this.engineMode === 'local_brain') {
          this.startSpeechRecognition();
        }
      }
      onComplete?.();
    };

    utterance.onend = finishSpeaking;
    utterance.onerror = (e) => {
      console.warn('[LIVE] Speech synthesis notice:', e);
      finishSpeaking();
    };

    window.speechSynthesis.speak(utterance);
  }

  /**
   * Toggles microphone mute
   */
  public toggleMute(): boolean {
    const nextMute = !this.streamer.isMutedState();
    this.streamer.setMute(nextMute);
    this.stateManager.setMuted(nextMute);
    return nextMute;
  }

  /**
   * Retries initiating microphone capture (e.g. after user grants permission in browser)
   */
  public async retryMicrophone(): Promise<{ success: boolean; error?: string }> {
    console.log('[LIVE] Retrying microphone permission and stream initialization...');
    const result = await this.streamer.start();
    if (result.success) {
      this.stateManager.setMicPermission('granted');
      this.stateManager.setError(null);
      this.stateManager.setNotice(null);
      return { success: true };
    } else {
      if (result.isPermissionDenied) {
        this.stateManager.setMicPermission('denied');
      }
      return { success: false, error: result.error };
    }
  }

  /**
   * Disconnect the active live session safely
   */
  public disconnect() {
    console.log('[LIVE] User requested disconnect.');
    this.isExplicitDisconnect = true;

    if (this.ws) {
      try {
        if (this.ws.readyState === WebSocket.OPEN) {
          this.sendMessage({ type: 'close' });
        }
        this.ws.close();
      } catch (_) {}
    }

    this.cleanup();
    this.stateManager.setConnectionState('disconnected');
  }

  private cleanup() {
    this.isConnected = false;
    this.isConnecting = false;
    this.engineMode = 'gemini_live';

    this.stopSpeechRecognition();
    if (typeof window !== 'undefined' && window.speechSynthesis) {
      window.speechSynthesis.cancel();
    }
    if (this.speechAnimInterval !== null) {
      clearInterval(this.speechAnimInterval);
      this.speechAnimInterval = null;
    }

    if (this.pingInterval !== null) {
      clearInterval(this.pingInterval);
      this.pingInterval = null;
    }

    this.streamer.stop();
    this.player.stop();
    this.ws = null;
    this.speechStartTime = 0;
    this.firstAudioChunkReceived = false;
  }

  private startHeartbeat() {
    if (this.pingInterval !== null) clearInterval(this.pingInterval);

    this.pingInterval = window.setInterval(() => {
      if (this.isConnected && this.ws && this.ws.readyState === WebSocket.OPEN) {
        this.lastPingTime = Date.now();
        this.sendMessage({ type: 'ping' });
      }
    }, 4000);
  }

  private sendMessage(obj: Record<string, any>) {
    if (this.ws && this.ws.readyState === WebSocket.OPEN) {
      try {
        this.ws.send(JSON.stringify(obj));
      } catch (err) {
        console.error('[LIVE] Error sending WS message:', err);
      }
    }
  }

  public onQuotaExhausted(listener: (message: string) => void): () => void {
    this.quotaListeners.add(listener);
    return () => {
      this.quotaListeners.delete(listener);
    };
  }
}
