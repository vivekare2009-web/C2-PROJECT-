/**
 * StateManager
 * Observable reactive state store for C2 Voice Assistant.
 * Coordinates connection state, audio levels, tool telemetry, and session stats.
 */

import { AtmosphereTheme, LiveConnectionState, MemoryItem, ToolExecutionEvent, UserProfile } from '../types';

export interface AssistantState {
  connectionState: LiveConnectionState;
  engineMode: 'gemini_live' | 'local_brain';
  inputLevel: number;
  outputLevel: number;
  isMuted: boolean;
  atmosphere: AtmosphereTheme;
  activeTool: ToolExecutionEvent | null;
  toolHistory: ToolExecutionEvent[];
  latencyMs: number;
  sessionStartTime: number | null;
  sessionSeconds: number;
  lastError: string | null;
  notice: string | null;
  micPermission: 'prompt' | 'granted' | 'denied';
  selectedVoice: string;
  currentUser: UserProfile | null;
  memories: MemoryItem[];
  greeting: string;
  isFirstLogin: boolean;
}

export type StateListener = (state: AssistantState) => void;

export class StateManager {
  private state: AssistantState;
  private listeners: Set<StateListener> = new Set();
  private timerId: number | null = null;

  constructor() {
    this.state = {
      connectionState: 'disconnected',
      engineMode: 'gemini_live',
      inputLevel: 0,
      outputLevel: 0,
      isMuted: false,
      atmosphere: 'nebula',
      activeTool: null,
      toolHistory: [],
      latencyMs: 42,
      sessionStartTime: null,
      sessionSeconds: 0,
      lastError: null,
      notice: null,
      micPermission: 'prompt',
      selectedVoice: 'Aoede',
      currentUser: null,
      memories: [],
      greeting: "Hey Master, good to see you again.",
      isFirstLogin: false,
    };
  }

  public getState(): AssistantState {
    return this.state;
  }

  public setCurrentUser(user: UserProfile, memories: MemoryItem[] = [], greeting?: string) {
    this.state = {
      ...this.state,
      currentUser: user,
      memories,
      isFirstLogin: user.isFirstLogin ?? false,
      greeting: greeting || (user.isFirstLogin
        ? "Hey! I'm C2. Nice to meet you. You can call me whenever you need me. What should I call you?"
        : `Hey ${user.preferredName || 'Master'}, good to see you again.`),
    };
    this.notify();
  }

  public setMemories(memories: MemoryItem[]) {
    this.state = { ...this.state, memories };
    this.notify();
  }

  public setGreeting(greeting: string) {
    this.state = { ...this.state, greeting };
    this.notify();
  }

  public subscribe(listener: StateListener): () => void {
    this.listeners.add(listener);
    listener(this.state);
    return () => this.listeners.delete(listener);
  }

  private notify() {
    this.listeners.forEach((listener) => {
      try {
        listener(this.state);
      } catch (e) {
        console.error('State notification error:', e);
      }
    });
  }

  public setConnectionState(connectionState: LiveConnectionState) {
    if (this.state.connectionState === connectionState) return;

    this.state = {
      ...this.state,
      connectionState,
    };

    if (connectionState === 'listening' || connectionState === 'speaking') {
      if (!this.state.sessionStartTime) {
        this.startSessionTimer();
      }
    } else if (connectionState === 'disconnected') {
      this.stopSessionTimer();
    }

    this.notify();
  }

  public setInputLevel(level: number) {
    if (this.state.inputLevel === level) return;
    this.state = {
      ...this.state,
      inputLevel: level,
    };
    this.notify();
  }

  public setOutputLevel(level: number) {
    if (this.state.outputLevel === level) return;
    this.state = {
      ...this.state,
      outputLevel: level,
    };
    this.notify();
  }

  public setMuted(isMuted: boolean) {
    this.state = {
      ...this.state,
      isMuted,
    };
    this.notify();
  }

  public setAtmosphere(atmosphere: AtmosphereTheme) {
    this.state = {
      ...this.state,
      atmosphere,
    };
    this.notify();
  }

  public setSelectedVoice(voice: string) {
    this.state = {
      ...this.state,
      selectedVoice: voice,
    };
    this.notify();
  }

  public recordToolEvent(event: ToolExecutionEvent) {
    const updatedHistory = [event, ...this.state.toolHistory.slice(0, 9)];
    this.state = {
      ...this.state,
      activeTool: event,
      toolHistory: updatedHistory,
    };
    this.notify();

    // Clear active tool badge after 5 seconds if completed
    if (event.status !== 'running') {
      setTimeout(() => {
        if (this.state.activeTool?.id === event.id) {
          this.state = {
            ...this.state,
            activeTool: null,
          };
          this.notify();
        }
      }, 5000);
    }
  }

  public setLatency(ms: number) {
    this.state = {
      ...this.state,
      latencyMs: ms,
    };
    this.notify();
  }

  public setError(error: string | null) {
    this.state = {
      ...this.state,
      lastError: error,
    };
    this.notify();
  }

  public setNotice(notice: string | null) {
    this.state = {
      ...this.state,
      notice,
    };
    this.notify();
  }

  public setMicPermission(micPermission: 'prompt' | 'granted' | 'denied') {
    this.state = {
      ...this.state,
      micPermission,
    };
    this.notify();
  }

  public setEngineMode(engineMode: 'gemini_live' | 'local_brain') {
    this.state = {
      ...this.state,
      engineMode,
    };
    this.notify();
  }

  private startSessionTimer() {
    this.state.sessionStartTime = Date.now();
    this.state.sessionSeconds = 0;

    if (this.timerId !== null) clearInterval(this.timerId);

    this.timerId = window.setInterval(() => {
      if (this.state.sessionStartTime) {
        const secs = Math.floor((Date.now() - this.state.sessionStartTime) / 1000);
        this.state = {
          ...this.state,
          sessionSeconds: secs,
        };
        this.notify();
      }
    }, 1000);
  }

  private stopSessionTimer() {
    if (this.timerId !== null) {
      clearInterval(this.timerId);
      this.timerId = null;
    }
    this.state = {
      ...this.state,
      sessionStartTime: null,
      sessionSeconds: 0,
      inputLevel: 0,
      outputLevel: 0,
    };
    this.notify();
  }
}
