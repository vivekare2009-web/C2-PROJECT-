/**
 * AudioStreamer
 * Captures microphone audio, downsamples/converts to 16kHz PCM16,
 * and streams base64 chunks for Gemini Live API.
 */

export type AudioChunkCallback = (base64Audio: string) => void;
export type LevelCallback = (level: number) => void;

export class AudioStreamer {
  private audioContext: AudioContext | null = null;
  private mediaStream: MediaStream | null = null;
  private sourceNode: MediaStreamAudioSourceNode | null = null;
  private processorNode: ScriptProcessorNode | null = null;
  private analyserNode: AnalyserNode | null = null;
  private silentGainNode: GainNode | null = null;

  private onAudioChunk: AudioChunkCallback | null = null;
  private onLevel: LevelCallback | null = null;

  private isStreaming: boolean = false;
  private isMuted: boolean = false;
  private animationFrameId: number | null = null;
  private lastReportedLevel: number = 0;
  private lastLevelReportTime: number = 0;

  constructor() {}

  public setCallbacks(onAudioChunk: AudioChunkCallback, onLevel?: LevelCallback) {
    this.onAudioChunk = onAudioChunk;
    if (onLevel) this.onLevel = onLevel;
  }

  public async start(): Promise<{ success: boolean; error?: string; isPermissionDenied?: boolean }> {
    if (this.isStreaming) return { success: true };

    if (typeof navigator === 'undefined' || !navigator.mediaDevices || !navigator.mediaDevices.getUserMedia) {
      console.warn('[VOICE] navigator.mediaDevices.getUserMedia is unavailable in current browser context.');
      return {
        success: false,
        error: 'Microphone API is unavailable in this embedded browser view. You can open in a new tab or use Speaker & Text mode.',
        isPermissionDenied: true,
      };
    }

    try {
      console.log('[VOICE] Requesting microphone permission...');
      // Request mic permission with voice-optimized settings, fallback to standard audio if rejected
      let stream: MediaStream;
      try {
        stream = await navigator.mediaDevices.getUserMedia({
          audio: {
            channelCount: 1,
            echoCancellation: true,
            noiseSuppression: true,
            autoGainControl: true,
          },
        });
      } catch (constraintErr: any) {
        const isDenied =
          constraintErr?.name === 'NotAllowedError' ||
          constraintErr?.name === 'PermissionDeniedError' ||
          constraintErr?.message?.toLowerCase().includes('permission') ||
          constraintErr?.message?.toLowerCase().includes('denied');

        if (isDenied) {
          throw constraintErr;
        }

        console.warn('[VOICE] Voice-optimized audio constraints rejected, falling back to basic audio:', constraintErr);
        stream = await navigator.mediaDevices.getUserMedia({ audio: true });
      }

      console.log('[VOICE] Microphone permission granted, media stream active.');
      this.mediaStream = stream;

      const AudioContextClass = window.AudioContext || (window as any).webkitAudioContext;
      if (!AudioContextClass) {
        throw new Error('Web Audio API is not supported in this browser.');
      }

      // Try 16000Hz directly; if unsupported by hardware, fallback to default rate and resample
      try {
        this.audioContext = new AudioContextClass({ sampleRate: 16000 });
      } catch (rateErr) {
        console.warn('[VOICE] AudioContext 16kHz requested was rejected by hardware, falling back to default sampleRate:', rateErr);
        this.audioContext = new AudioContextClass();
      }

      if (this.audioContext.state === 'suspended') {
        console.log('[AUDIO] AudioContext suspended, resuming on user gesture...');
        await this.audioContext.resume();
      }

      console.log(`[AUDIO] AudioContext initialized at ${this.audioContext.sampleRate}Hz, state: ${this.audioContext.state}`);

      this.sourceNode = this.audioContext.createMediaStreamSource(stream);

      // Analyser for real-time waveform and audio level
      this.analyserNode = this.audioContext.createAnalyser();
      this.analyserNode.fftSize = 256;
      this.analyserNode.smoothingTimeConstant = 0.3;
      this.sourceNode.connect(this.analyserNode);

      // ScriptProcessor for PCM extraction (bufferSize 2048 or 4096 = ~128-256ms of audio)
      const bufferSize = 2048;
      this.processorNode = this.audioContext.createScriptProcessor(bufferSize, 1, 1);

      const actualSampleRate = this.audioContext.sampleRate;
      const targetSampleRate = 16000;
      const needsResampling = actualSampleRate !== targetSampleRate;

      let chunkCounter = 0;

      this.processorNode.onaudioprocess = (e) => {
        if (!this.isStreaming || this.isMuted) return;

        const inputData = e.inputBuffer.getChannelData(0);
        let audioToSend: Float32Array;

        if (needsResampling) {
          audioToSend = this.resampleLinear(inputData, actualSampleRate, targetSampleRate);
        } else {
          audioToSend = inputData;
        }

        const pcm16 = this.floatTo16BitPCM(audioToSend);
        const base64 = this.pcm16ToBase64(pcm16);

        if (this.onAudioChunk && base64) {
          chunkCounter++;
          if (chunkCounter % 30 === 1) {
            console.log(`[AUDIO] Streaming input audio chunk #${chunkCounter} (${pcm16.length} samples, 16kHz PCM16)`);
          }
          this.onAudioChunk(base64);
        }
      };

      // Connect through a silent gain node to destination so audio processing runs without echo
      this.silentGainNode = this.audioContext.createGain();
      this.silentGainNode.gain.value = 0;

      this.sourceNode.connect(this.processorNode);
      this.processorNode.connect(this.silentGainNode);
      this.silentGainNode.connect(this.audioContext.destination);

      this.isStreaming = true;
      this.startLevelLoop();

      console.log('[VOICE] Microphone stream started successfully.');
      return { success: true };
    } catch (err: any) {
      const isPermissionDenied =
        err?.name === 'NotAllowedError' ||
        err?.name === 'PermissionDeniedError' ||
        err?.message?.toLowerCase().includes('permission') ||
        err?.message?.toLowerCase().includes('denied');

      // Log as warning rather than console.error so user-level permission rejection doesn't trip fatal error telemetry
      if (isPermissionDenied) {
        console.warn('[VOICE] Microphone permission not granted by user or browser policy:', err?.message || err);
      } else {
        console.warn('[VOICE] Failed to start microphone stream:', err?.message || err);
      }
      this.stop();

      return {
        success: false,
        error: isPermissionDenied
          ? 'Microphone permission was not granted. C2 is ready in Speaker & Text mode.'
          : (err?.message || 'Microphone capture failed.'),
        isPermissionDenied,
      };
    }
  }

  public stop() {
    console.log('[VOICE] Stopping microphone stream...');
    this.isStreaming = false;

    if (this.animationFrameId !== null) {
      cancelAnimationFrame(this.animationFrameId);
      this.animationFrameId = null;
    }

    if (this.processorNode) {
      this.processorNode.disconnect();
      this.processorNode.onaudioprocess = null;
      this.processorNode = null;
    }

    if (this.silentGainNode) {
      this.silentGainNode.disconnect();
      this.silentGainNode = null;
    }

    if (this.analyserNode) {
      this.analyserNode.disconnect();
      this.analyserNode = null;
    }

    if (this.sourceNode) {
      this.sourceNode.disconnect();
      this.sourceNode = null;
    }

    if (this.mediaStream) {
      this.mediaStream.getTracks().forEach((track) => track.stop());
      this.mediaStream = null;
    }

    if (this.audioContext && this.audioContext.state !== 'closed') {
      this.audioContext.close().catch(() => {});
      this.audioContext = null;
    }

    this.lastReportedLevel = 0;
    if (this.onLevel) {
      this.onLevel(0);
    }
    console.log('[VOICE] Microphone stream stopped.');
  }

  public setMute(muted: boolean) {
    this.isMuted = muted;
    if (this.mediaStream) {
      this.mediaStream.getAudioTracks().forEach((t) => {
        t.enabled = !muted;
      });
    }
  }

  public isMutedState(): boolean {
    return this.isMuted;
  }

  public getIsStreaming(): boolean {
    return this.isStreaming;
  }

  private startLevelLoop() {
    const checkLevel = () => {
      if (!this.isStreaming || !this.analyserNode) {
        if (this.lastReportedLevel !== 0 && this.onLevel) {
          this.lastReportedLevel = 0;
          this.onLevel(0);
        }
        return;
      }

      const now = performance.now();
      // Throttle level notifications to ~20 FPS (every 50ms) to prevent React re-render churn
      if (now - this.lastLevelReportTime >= 50) {
        this.lastLevelReportTime = now;
        const dataArray = new Uint8Array(this.analyserNode.frequencyBinCount);
        this.analyserNode.getByteFrequencyData(dataArray);

        let sum = 0;
        for (let i = 0; i < dataArray.length; i++) {
          sum += dataArray[i];
        }
        const avg = sum / dataArray.length;
        const normalized = Math.min(100, Math.round((avg / 128) * 100));
        const effectiveLevel = this.isMuted ? 0 : normalized;

        if (Math.abs(effectiveLevel - this.lastReportedLevel) >= 2 || effectiveLevel === 0) {
          this.lastReportedLevel = effectiveLevel;
          if (this.onLevel) {
            this.onLevel(effectiveLevel);
          }
        }
      }

      this.animationFrameId = requestAnimationFrame(checkLevel);
    };

    this.animationFrameId = requestAnimationFrame(checkLevel);
  }

  /**
   * Resamples Float32 audio buffer using linear interpolation
   */
  private resampleLinear(input: Float32Array, fromRate: number, toRate: number): Float32Array {
    if (fromRate === toRate) return input;
    const ratio = fromRate / toRate;
    const outputLength = Math.round(input.length / ratio);
    const output = new Float32Array(outputLength);

    for (let i = 0; i < outputLength; i++) {
      const position = i * ratio;
      const index = Math.floor(position);
      const frac = position - index;
      const s0 = input[index] || 0;
      const s1 = input[index + 1] !== undefined ? input[index + 1] : s0;
      output[i] = s0 + (s1 - s0) * frac;
    }

    return output;
  }

  private floatTo16BitPCM(input: Float32Array): Int16Array {
    const output = new Int16Array(input.length);
    for (let i = 0; i < input.length; i++) {
      const s = Math.max(-1, Math.min(1, input[i]));
      output[i] = s < 0 ? s * 0x8000 : s * 0x7fff;
    }
    return output;
  }

  /**
   * Fast chunked conversion from Int16Array to base64 string
   */
  private pcm16ToBase64(pcm16: Int16Array): string {
    const bytes = new Uint8Array(pcm16.buffer);
    const len = bytes.byteLength;
    let binary = '';
    const chunkSize = 4096;

    for (let i = 0; i < len; i += chunkSize) {
      const sub = bytes.subarray(i, Math.min(i + chunkSize, len));
      binary += String.fromCharCode.apply(null, sub as unknown as number[]);
    }

    return window.btoa(binary);
  }
}

