/**
 * C2 Avatar Video State System Types & Configuration Definitions
 */

export type AvatarVideoState =
  | 'IDLE'
  | 'THINKING'
  | 'TALKING'
  | 'UPSET'
  | 'PERSONAL_BOUNDARY';

export interface TouchZone {
  id: string;
  name: string;
  description: string;
  x: number; // normalized 0..1
  y: number; // normalized 0..1
  width: number; // normalized 0..1
  height: number; // normalized 0..1
  enabled: boolean;
}

export interface AvatarConfig {
  touchCooldownMs: number;
  boundaryTouchInterruptsSpeech: boolean;
  upsetVideoEnabled: boolean;
  upsetDisplayDurationMs: number;
  upsetTriggerThreshold: number;
  thinkingTimeoutMs: number;
  boundaryDisplayDurationMs: number;
  debugTouchZones: boolean;
  videoAudioMode: 'muted' | 'baked-in' | 'external-only';
}

export interface VideoAssetInfo {
  state: AvatarVideoState;
  filename: string;
  primaryUrl: string;
  fallbackUrls: string[];
  loop: boolean;
  title: string;
}

export const DEFAULT_TOUCH_ZONES: TouchZone[] = [
  {
    id: 'chest_zone',
    name: 'Chest / Torso Zone',
    description: 'Personal upper body space boundary',
    x: 0.35,
    y: 0.25,
    width: 0.30,
    height: 0.20,
    enabled: true,
  },
  {
    id: 'hip_zone',
    name: 'Hip Zone',
    description: 'Personal mid body space boundary',
    x: 0.25,
    y: 0.45,
    width: 0.50,
    height: 0.20,
    enabled: true,
  },
  {
    id: 'gluteal_zone',
    name: 'Gluteal / Lower Zone',
    description: 'Personal lower body space boundary',
    x: 0.25,
    y: 0.60,
    width: 0.50,
    height: 0.20,
    enabled: true,
  },
];

export const DEFAULT_AVATAR_CONFIG: AvatarConfig = {
  touchCooldownMs: 2500,
  boundaryTouchInterruptsSpeech: false,
  upsetVideoEnabled: true,
  upsetDisplayDurationMs: 4000,
  upsetTriggerThreshold: 0.7,
  thinkingTimeoutMs: 15000,
  boundaryDisplayDurationMs: 4500,
  debugTouchZones: false,
  videoAudioMode: 'baked-in', // Video audio permanently muted at player level
};

export const AVATAR_STATE_PRIORITY: Record<AvatarVideoState, number> = {
  PERSONAL_BOUNDARY: 5,
  UPSET: 4,
  TALKING: 3,
  THINKING: 2,
  IDLE: 1,
};

export const VIDEO_ASSET_MAP: Record<AvatarVideoState, VideoAssetInfo> = {
  IDLE: {
    state: 'IDLE',
    filename: 'Character_idle_loop_animation_20260919112236.mp4',
    primaryUrl: '/assets/videos/Character_idle_loop_animation_20260919112236.mp4',
    fallbackUrls: [
      '/videos/Character_idle_loop_animation_20260919112236.mp4',
      '/Character_idle_loop_animation_20260919112236.mp4',
    ],
    loop: true,
    title: 'Idle Animation Loop',
  },
  THINKING: {
    state: 'THINKING',
    filename: 'thinking.mp4',
    primaryUrl: '/assets/videos/thinking.mp4',
    fallbackUrls: ['/videos/thinking.mp4', '/thinking.mp4'],
    loop: true,
    title: 'Thinking / Processing',
  },
  TALKING: {
    state: 'TALKING',
    filename: 'talking.mp4',
    primaryUrl: '/assets/videos/talking.mp4',
    fallbackUrls: ['/videos/talking.mp4', '/talking.mp4'],
    loop: true,
    title: 'Speaking Response',
  },
  UPSET: {
    state: 'UPSET',
    filename: 'upset.mp4',
    primaryUrl: '/assets/videos/upset.mp4',
    fallbackUrls: ['/videos/upset.mp4', '/upset.mp4'],
    loop: false,
    title: 'Upset Reaction',
  },
  PERSONAL_BOUNDARY: {
    state: 'PERSONAL_BOUNDARY',
    filename: 'personal boundaries.mp4',
    primaryUrl: '/assets/videos/personal%20boundaries.mp4',
    fallbackUrls: [
      '/assets/videos/personal_boundaries.mp4',
      '/videos/personal boundaries.mp4',
      '/videos/personal_boundaries.mp4',
      '/personal%20boundaries.mp4',
      '/personal_boundaries.mp4',
    ],
    loop: false,
    title: 'Personal Boundary Reaction',
  },
};
