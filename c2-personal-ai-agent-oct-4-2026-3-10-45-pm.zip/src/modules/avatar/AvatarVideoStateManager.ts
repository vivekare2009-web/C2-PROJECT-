/**
 * AvatarVideoStateManager
 * 
 * Centralized State Machine for C2 Animated Character Video.
 * Handles priority-based state transitions, minimum display durations,
 * touch zone coordinate detection, speech lifecycle binding, and fallback recovery.
 */

import {
  AvatarConfig,
  AvatarVideoState,
  AVATAR_STATE_PRIORITY,
  DEFAULT_AVATAR_CONFIG,
  DEFAULT_TOUCH_ZONES,
  TouchZone,
} from './types';
import { classifyUserMessage } from './abuseClassifier';
import { safeStorage } from '../../utils/safeStorage';

export type AvatarStateListener = (
  state: AvatarVideoState,
  info: {
    previousState: AvatarVideoState;
    reason: string;
    timestamp: number;
    activeZone?: TouchZone;
  }
) => void;

const STORAGE_KEY_ZONES = 'c2_avatar_touch_zones_v1';
const STORAGE_KEY_CONFIG = 'c2_avatar_config_v1';

export class AvatarVideoStateManager {
  private currentState: AvatarVideoState = 'IDLE';
  private previousState: AvatarVideoState = 'IDLE';
  private listeners: Set<AvatarStateListener> = new Set();

  private config: AvatarConfig = { ...DEFAULT_AVATAR_CONFIG };
  private touchZones: TouchZone[] = [...DEFAULT_TOUCH_ZONES];

  private stateTimerId: number | null = null;
  private thinkingTimerId: number | null = null;
  private lastTouchTime: number = 0;
  private isSpeechActive: boolean = false;
  private currentSessionId: number = 0;

  constructor() {
    this.loadPersistedData();
  }

  private loadPersistedData() {
    try {
      const savedZones = safeStorage.getItem(STORAGE_KEY_ZONES);
      if (savedZones) {
        const parsed = JSON.parse(savedZones);
        if (Array.isArray(parsed) && parsed.length > 0) {
          this.touchZones = parsed;
        }
      }

      const savedConfig = safeStorage.getItem(STORAGE_KEY_CONFIG);
      if (savedConfig) {
        const parsed = JSON.parse(savedConfig);
        this.config = { ...this.config, ...parsed };
      }
    } catch (e) {
      console.warn('[AVATAR] Error loading persisted avatar settings:', e);
    }
  }

  public persistData() {
    try {
      safeStorage.setItem(STORAGE_KEY_ZONES, JSON.stringify(this.touchZones));
      safeStorage.setItem(STORAGE_KEY_CONFIG, JSON.stringify(this.config));
    } catch (e) {
      console.warn('[AVATAR] Error saving avatar settings:', e);
    }
  }

  public getState(): AvatarVideoState {
    return this.currentState;
  }

  public getConfig(): AvatarConfig {
    return { ...this.config };
  }

  public updateConfig(newConfig: Partial<AvatarConfig>) {
    this.config = { ...this.config, ...newConfig };
    this.persistData();
  }

  public getTouchZones(): TouchZone[] {
    return [...this.touchZones];
  }

  public setTouchZones(zones: TouchZone[]) {
    this.touchZones = zones;
    this.persistData();
  }

  public resetTouchZonesToDefault() {
    this.touchZones = [...DEFAULT_TOUCH_ZONES];
    this.persistData();
  }

  public subscribe(listener: AvatarStateListener): () => void {
    this.listeners.add(listener);
    listener(this.currentState, {
      previousState: this.previousState,
      reason: 'initial_subscription',
      timestamp: Date.now(),
    });
    return () => this.listeners.delete(listener);
  }

  private notify(reason: string, activeZone?: TouchZone) {
    const timestamp = Date.now();
    this.listeners.forEach((listener) => {
      try {
        listener(this.currentState, {
          previousState: this.previousState,
          reason,
          timestamp,
          activeZone,
        });
      } catch (err) {
        console.error('[AVATAR] State listener error:', err);
      }
    });
  }

  /**
   * Internal transition function enforcing state priorities and timeouts
   */
  private transitionTo(
    nextState: AvatarVideoState,
    reason: string,
    options?: { activeZone?: TouchZone; durationMs?: number; force?: boolean }
  ): boolean {
    const currentPriority = AVATAR_STATE_PRIORITY[this.currentState];
    const nextPriority = AVATAR_STATE_PRIORITY[nextState];

    // Priority Check: Can only transition if nextPriority >= currentPriority OR if current state is completing / forced
    if (!options?.force && nextPriority < currentPriority) {
      // High-priority state (e.g. PERSONAL_BOUNDARY or UPSET) is active
      console.log(
        `[AVATAR] Transition to ${nextState} suppressed because active state ${this.currentState} has higher priority (${currentPriority} vs ${nextPriority})`
      );
      return false;
    }

    // Cancel existing temporary timers
    if (this.stateTimerId !== null) {
      clearTimeout(this.stateTimerId);
      this.stateTimerId = null;
    }

    const prev = this.currentState;
    this.previousState = prev;
    this.currentState = nextState;
    const sessionId = ++this.currentSessionId;

    // Timeout handling for temporary states
    if (nextState === 'THINKING') {
      // Timeout to ensure thinking doesn't freeze forever
      if (this.thinkingTimerId !== null) clearTimeout(this.thinkingTimerId);
      this.thinkingTimerId = window.setTimeout(() => {
        if (this.currentState === 'THINKING' && this.currentSessionId === sessionId) {
          console.warn('[AVATAR] Thinking state timed out. Returning to IDLE.');
          this.transitionTo('IDLE', 'thinking_timeout', { force: true });
        }
      }, this.config.thinkingTimeoutMs);
    } else {
      if (this.thinkingTimerId !== null) {
        clearTimeout(this.thinkingTimerId);
        this.thinkingTimerId = null;
      }
    }

    if (nextState === 'PERSONAL_BOUNDARY') {
      const duration = options?.durationMs ?? this.config.boundaryDisplayDurationMs;
      this.stateTimerId = window.setTimeout(() => {
        if (this.currentState === 'PERSONAL_BOUNDARY' && this.currentSessionId === sessionId) {
          const fallback = this.isSpeechActive ? 'TALKING' : 'IDLE';
          this.transitionTo(fallback, 'boundary_duration_complete', { force: true });
        }
      }, duration);
    } else if (nextState === 'UPSET') {
      const duration = options?.durationMs ?? this.config.upsetDisplayDurationMs;
      this.stateTimerId = window.setTimeout(() => {
        if (this.currentState === 'UPSET' && this.currentSessionId === sessionId) {
          const fallback = this.isSpeechActive ? 'TALKING' : 'IDLE';
          this.transitionTo(fallback, 'upset_duration_complete', { force: true });
        }
      }, duration);
    }

    this.notify(reason, options?.activeZone);
    return true;
  }

  // -------------------------------------------------------------
  // Public Lifecycle Handlers
  // -------------------------------------------------------------

  /**
   * Called when user sends a prompt or voice input processing begins
   */
  public onTaskStarted(userInputText?: string): { isUpset: boolean } {
    if (userInputText && this.config.upsetVideoEnabled) {
      const classification = classifyUserMessage(
        userInputText,
        this.config.upsetTriggerThreshold
      );
      if (classification.isAbusive) {
        console.log(`[AVATAR] Abusive language detected (${classification.reason}). Activating UPSET video.`);
        this.transitionTo('UPSET', 'abusive_language_detected', {
          durationMs: this.config.upsetDisplayDurationMs,
          force: true,
        });
        return { isUpset: true };
      }
    }

    this.transitionTo('THINKING', 'task_processing_started');
    return { isUpset: false };
  }

  /**
   * Called when C2 begins actual audio playback
   */
  public onSpeechStarted() {
    this.isSpeechActive = true;
    if (this.currentState !== 'PERSONAL_BOUNDARY' && this.currentState !== 'UPSET') {
      this.transitionTo('TALKING', 'speech_playback_started');
    }
  }

  /**
   * Called while C2 audio is actively playing
   */
  public onSpeechPlaying() {
    this.isSpeechActive = true;
    if (this.currentState === 'IDLE' || this.currentState === 'THINKING') {
      this.transitionTo('TALKING', 'speech_playing_active');
    }
  }

  /**
   * Called when C2 audio playback genuinely completes
   */
  public onSpeechFinished() {
    this.isSpeechActive = false;
    if (this.currentState === 'TALKING') {
      this.transitionTo('IDLE', 'speech_playback_finished', { force: true });
    }
  }

  /**
   * Called when C2 audio playback is interrupted by user or system
   */
  public onSpeechInterrupted() {
    this.isSpeechActive = false;
    if (this.currentState === 'TALKING') {
      this.transitionTo('IDLE', 'speech_interrupted', { force: true });
    }
  }

  /**
   * Called when C2 audio playback encounters an error
   */
  public onSpeechError(err?: any) {
    this.isSpeechActive = false;
    console.warn('[AVATAR] Speech error reported to AvatarStateManager:', err);
    if (this.currentState === 'TALKING') {
      this.transitionTo('IDLE', 'speech_error_fallback', { force: true });
    }
  }

  /**
   * Called when task execution fails or network drops
   */
  public onTaskError(errorMsg?: string) {
    console.warn('[AVATAR] Task error:', errorMsg);
    if (this.currentState === 'THINKING') {
      this.transitionTo('IDLE', 'task_error_recovery', { force: true });
    }
  }

  /**
   * Touch event processing
   * Receives normalized coordinates (0..1) relative to character video rect
   */
  public handleTouch(
    normX: number,
    normY: number
  ): {
    triggered: boolean;
    zone?: TouchZone;
    cooldownRemainingMs?: number;
  } {
    const now = Date.now();
    const elapsed = now - this.lastTouchTime;

    if (elapsed < this.config.touchCooldownMs) {
      return {
        triggered: false,
        cooldownRemainingMs: this.config.touchCooldownMs - elapsed,
      };
    }

    // Find touched zone
    const matchedZone = this.touchZones.find((z) => {
      if (!z.enabled) return false;
      return (
        normX >= z.x &&
        normX <= z.x + z.width &&
        normY >= z.y &&
        normY <= z.y + z.height
      );
    });

    if (!matchedZone) {
      return { triggered: false };
    }

    // Zone touched!
    this.lastTouchTime = now;
    console.log(
      `[AVATAR] Touch detected in zone: ${matchedZone.name} at (${normX.toFixed(2)}, ${normY.toFixed(2)})`
    );

    this.transitionTo('PERSONAL_BOUNDARY', `touched_zone_${matchedZone.id}`, {
      activeZone: matchedZone,
      durationMs: this.config.boundaryDisplayDurationMs,
      force: true,
    });

    return {
      triggered: true,
      zone: matchedZone,
    };
  }

  /**
   * Reset to IDLE
   */
  public resetToIdle() {
    this.isSpeechActive = false;
    this.transitionTo('IDLE', 'manual_reset', { force: true });
  }
}

// Global Singleton Instance
export const avatarVideoStateManager = new AvatarVideoStateManager();
