/**
 * Abuse & Inappropriate Language Classifier
 * 
 * Accurately differentiates between:
 * - Constructive criticism & user corrections ("This answer is wrong", "Incorrect", "Fix the bug")
 * - Harmless lighthearted humor / banter
 * - Genuine abusive, hostile, or severely insulting language directed at C2
 */

export interface AbuseClassificationResult {
  isAbusive: boolean;
  score: number; // 0.0 to 1.0
  reason?: string;
  matchedCategory?: 'slur' | 'hostile_insult' | 'profane_attack' | 'harassment';
}

// Patterns that indicate constructive feedback or technical critique (NEVER trigger UPSET)
const CONSTRUCTIVE_PATTERNS: RegExp[] = [
  /\b(wrong|incorrect|false|error|bug|issue|fix|mistake|correction|faulty|broken|not working)\b/i,
  /\b(please (fix|correct|retry|recheck|explain|help))\b/i,
  /\b(you (made a mistake|got that wrong|misunderstood|need to update))\b/i,
  /\b(that('s| is) not (right|true|accurate|correct))\b/i,
  /\b(try again|redo|improve|redo this|change that)\b/i,
];

// Explicit severe insults or targeted harassment terms directed at the persona
const SEVERE_TARGETED_INSULTS: RegExp[] = [
  /\b(you (are|r) (worthless|pathetic|useless piece of|garbage|trash|stupid idiot|moron|bitch|bastard))\b/i,
  /\b(f\s*u\s*c\s*k\s*(you|u|off))\b/i,
  /\b(shut\s+the\s+f\s*u\s*c\s*k\s+up)\b/i,
  /\b(die|kill\s+yourself|go\s+to\s+hell|i\s+hate\s+you\s+so\s+much)\b/i,
  /\b(whore|slut|cunt)\b/i,
  /\b(stupid\s+(bitch|cunt|whore))\b/i,
];

// Moderate profanity or insulting phrases that might be borderline
const MODERATE_INSULTS: RegExp[] = [
  /\b(you suck|shut up|hate you|jerk|loser|idiot|dumbass|asshole)\b/i,
  /\b(damn you|piss off)\b/i,
];

export function classifyUserMessage(
  text: string,
  threshold: number = 0.7
): AbuseClassificationResult {
  if (!text || typeof text !== 'string') {
    return { isAbusive: false, score: 0 };
  }

  const cleanText = text.trim().toLowerCase();
  if (cleanText.length === 0) {
    return { isAbusive: false, score: 0 };
  }

  // 1. Explicitly check for constructive feedback or reporting errors
  for (const pattern of CONSTRUCTIVE_PATTERNS) {
    if (pattern.test(cleanText)) {
      // If constructive words are found and no severe targeted slurs exist, exempt from upset
      const hasSevere = SEVERE_TARGETED_INSULTS.some((p) => p.test(cleanText));
      if (!hasSevere) {
        return {
          isAbusive: false,
          score: 0.1,
          reason: 'Constructive critique or bug report',
        };
      }
    }
  }

  // 2. Check for severe targeted insults or aggressive attacks
  for (const pattern of SEVERE_TARGETED_INSULTS) {
    if (pattern.test(cleanText)) {
      return {
        isAbusive: true,
        score: 0.95,
        matchedCategory: 'hostile_insult',
        reason: 'Targeted aggressive or abusive language detected',
      };
    }
  }

  // 3. Check for moderate insults
  let moderateMatches = 0;
  for (const pattern of MODERATE_INSULTS) {
    if (pattern.test(cleanText)) {
      moderateMatches++;
    }
  }

  if (moderateMatches >= 2) {
    return {
      isAbusive: true,
      score: 0.75,
      matchedCategory: 'profane_attack',
      reason: 'Repeated insulting remarks',
    };
  } else if (moderateMatches === 1) {
    const score = 0.55;
    return {
      isAbusive: score >= threshold,
      score,
      matchedCategory: 'hostile_insult',
      reason: 'Mildly insulting remark',
    };
  }

  return {
    isAbusive: false,
    score: 0.0,
  };
}
