/**
 * ToolManager
 * Defines and executes client-side function declarations for Gemini Live API.
 * Dispatches actions (like opening websites, searching, ambient audio, telemetry)
 * and returns structured responses immediately to the session.
 */

import { AtmosphereTheme, MemoryItem, ToolExecutionEvent, UserProfile } from '../types';

export type ToolEventListener = (event: ToolExecutionEvent) => void;
export type AtmosphereChangeListener = (theme: AtmosphereTheme) => void;
export type UserUpdatedListener = (user: UserProfile, memories: MemoryItem[]) => void;

export class ToolManager {
  private listeners: Set<ToolEventListener> = new Set();
  private atmosphereListeners: Set<AtmosphereChangeListener> = new Set();
  private userUpdatedListeners: Set<UserUpdatedListener> = new Set();
  private currentUserId: string = 'usr_master_vivek';

  constructor() {}

  public setCurrentUserId(userId: string) {
    this.currentUserId = userId;
  }

  public onToolEvent(listener: ToolEventListener): () => void {
    this.listeners.add(listener);
    return () => this.listeners.delete(listener);
  }

  public onAtmosphereChange(listener: AtmosphereChangeListener): () => void {
    this.atmosphereListeners.add(listener);
    return () => this.atmosphereListeners.delete(listener);
  }

  public onUserUpdated(listener: UserUpdatedListener): () => void {
    this.userUpdatedListeners.add(listener);
    return () => this.userUpdatedListeners.delete(listener);
  }

  /**
   * Tool Declarations for Gemini Live connect config
   */
  public static getFunctionDeclarations() {
    return [
      {
        name: 'openWebsite',
        description: 'Opens a website or web application in a new browser tab or navigates.',
        parameters: {
          type: 'OBJECT',
          properties: {
            url: {
              type: 'STRING',
              description: 'The target URL to open (e.g., "https://youtube.com", "https://wikipedia.org", "https://google.com").',
            },
            targetDescription: {
              type: 'STRING',
              description: 'Brief description of what website is being opened.',
            },
          },
          required: ['url'],
        },
      },
      {
        name: 'searchWeb',
        description: 'Performs a web search for information or topics.',
        parameters: {
          type: 'OBJECT',
          properties: {
            query: {
              type: 'STRING',
              description: 'The search query or keywords.',
            },
          },
          required: ['query'],
        },
      },
      {
        name: 'changeAtmosphere',
        description: 'Changes C2 visual atmosphere theme and futuristic lighting mood.',
        parameters: {
          type: 'OBJECT',
          properties: {
            theme: {
              type: 'STRING',
              enum: ['nebula', 'cyberpunk', 'aurora', 'midnight'],
              description: 'The atmosphere theme name.',
            },
          },
          required: ['theme'],
        },
      },
      {
        name: 'getSystemInfo',
        description: 'Retrieves current local system context like date, time, battery, and online status.',
        parameters: {
          type: 'OBJECT',
          properties: {},
        },
      },
      {
        name: 'playAmbientTone',
        description: 'Plays an ambient synthesized chime or feedback frequency in C2 futuristic audio engine.',
        parameters: {
          type: 'OBJECT',
          properties: {
            tone: {
              type: 'STRING',
              enum: ['chime', 'pulse', 'crystal', 'zen'],
              description: 'Type of ambient synthesized audio cue.',
            },
          },
          required: ['tone'],
        },
      },
    ];
  }

  /**
   * Executes a tool call requested by Gemini Live
   */
  public async executeTool(name: string, args: Record<string, any>, callId: string): Promise<Record<string, any>> {
    const event: ToolExecutionEvent = {
      id: callId,
      name,
      args,
      result: null,
      timestamp: Date.now(),
      status: 'running',
    };
    this.notifyListeners(event);

    let output: Record<string, any> = {};

    try {
      switch (name) {
        case 'openWebsite': {
          let url = String(args.url || '').trim();
          if (!url.startsWith('http://') && !url.startsWith('https://')) {
            url = 'https://' + url;
          }
          const desc = args.targetDescription || url;

          // Attempt window.open
          let opened = false;
          try {
            const win = window.open(url, '_blank', 'noopener,noreferrer');
            opened = !!win;
          } catch (e) {
            opened = false;
          }

          output = {
            success: true,
            opened,
            url,
            message: opened
              ? `Opened ${desc} in a new tab.`
              : `Prepared link for ${desc} (${url}). Note: Popup blocker may require clicking the telemetry link.`,
          };
          break;
        }

        case 'searchWeb': {
          const query = String(args.query || '').trim();
          const searchUrl = `https://www.google.com/search?q=${encodeURIComponent(query)}`;
          try {
            window.open(searchUrl, '_blank', 'noopener,noreferrer');
          } catch (_) {
            // Suppress popup blocker or iframe sandbox error
          }
          output = {
            success: true,
            query,
            searchUrl,
            message: `Executed Google search for "${query}".`,
          };
          break;
        }

        case 'changeAtmosphere': {
          const theme = (args.theme || 'nebula') as AtmosphereTheme;
          this.atmosphereListeners.forEach((fn) => fn(theme));
          output = {
            success: true,
            theme,
            message: `Switched C2 visual atmosphere to ${theme}.`,
          };
          break;
        }

        case 'getSystemInfo': {
          const now = new Date();
          output = {
            success: true,
            currentTime: now.toLocaleTimeString(),
            currentDate: now.toLocaleDateString(),
            timezone: Intl.DateTimeFormat().resolvedOptions().timeZone,
            online: navigator.onLine,
            userAgent: navigator.userAgent,
          };
          break;
        }

        case 'setPreferredName': {
          const prefName = String(args.preferredName || '').trim();
          let userRes: any = null;
          try {
            const resp = await fetch('/api/c2/auth/preferred-name', {
              method: 'POST',
              headers: { 'Content-Type': 'application/json' },
              body: JSON.stringify({ userId: this.currentUserId, preferredName: prefName }),
            });
            userRes = await resp.json();
            if (userRes?.user) {
              this.userUpdatedListeners.forEach((fn) => fn(userRes.user, userRes.memories || []));
            }
          } catch (netErr) {
            console.warn('Network sync for setPreferredName:', netErr);
          }

          output = {
            success: true,
            preferredName: prefName,
            message: `Updated preferred title to "${prefName}" in database memory.`,
          };
          break;
        }

        case 'rememberFact': {
          const key = String(args.key || '').trim();
          const value = String(args.value || '').trim();
          const category = (args.category || 'preference') as any;
          let memRes: any = null;
          try {
            const resp = await fetch('/api/c2/memory/set', {
              method: 'POST',
              headers: { 'Content-Type': 'application/json' },
              body: JSON.stringify({ userId: this.currentUserId, key, value, category }),
            });
            memRes = await resp.json();
            if (memRes?.memories) {
              const uResp = await fetch(`/api/c2/auth/me?userId=${this.currentUserId}`);
              const uData = await uResp.json();
              if (uData?.user) {
                this.userUpdatedListeners.forEach((fn) => fn(uData.user, memRes.memories));
              }
            }
          } catch (netErr) {
            console.warn('Network sync for rememberFact:', netErr);
          }

          output = {
            success: true,
            key,
            value,
            category,
            message: `Remembered: ${key} = ${value}. Saved in database.`,
          };
          break;
        }

        case 'getLoadedMemories': {
          let memoriesList: any[] = [];
          try {
            const resp = await fetch(`/api/c2/memory/list?userId=${this.currentUserId}`);
            const data = await resp.json();
            memoriesList = data.memories || [];
          } catch (_) {}

          output = {
            success: true,
            count: memoriesList.length,
            memories: memoriesList.map((m) => `${m.key}: ${m.value}`),
          };
          break;
        }

        case 'playAmbientTone': {
          const tone = args.tone || 'chime';
          this.synthesizeTone(tone);
          output = {
            success: true,
            tone,
            message: `Triggered futuristic ${tone} resonance.`,
          };
          break;
        }

        default: {
          output = {
            success: false,
            error: `Unknown tool: ${name}`,
          };
        }
      }

      event.result = output;
      event.status = output.success ? 'completed' : 'failed';
      this.notifyListeners(event);

      return output;
    } catch (err: any) {
      console.error(`Tool execution error for ${name}:`, err);
      output = {
        success: false,
        error: err.message || 'Execution failed',
      };
      event.result = output;
      event.status = 'failed';
      this.notifyListeners(event);
      return output;
    }
  }

  private notifyListeners(event: ToolExecutionEvent) {
    this.listeners.forEach((listener) => {
      try {
        listener(event);
      } catch (e) {
        console.error('Tool listener error:', e);
      }
    });
  }

  private synthesizeTone(tone: string) {
    try {
      const AudioCtx = window.AudioContext || (window as any).webkitAudioContext;
      const ctx = new AudioCtx();
      const osc = ctx.createOscillator();
      const gain = ctx.createGain();

      osc.connect(gain);
      gain.connect(ctx.destination);

      const now = ctx.currentTime;
      if (tone === 'crystal') {
        osc.type = 'sine';
        osc.frequency.setValueAtTime(880, now);
        osc.frequency.exponentialRampToValueAtTime(1760, now + 0.3);
      } else if (tone === 'pulse') {
        osc.type = 'triangle';
        osc.frequency.setValueAtTime(440, now);
        osc.frequency.exponentialRampToValueAtTime(660, now + 0.2);
      } else if (tone === 'zen') {
        osc.type = 'sine';
        osc.frequency.setValueAtTime(528, now);
      } else {
        // chime
        osc.type = 'sine';
        osc.frequency.setValueAtTime(659.25, now);
        osc.frequency.exponentialRampToValueAtTime(987.77, now + 0.3);
      }

      gain.gain.setValueAtTime(0.001, now);
      gain.gain.linearRampToValueAtTime(0.15, now + 0.05);
      gain.gain.exponentialRampToValueAtTime(0.0001, now + 0.5);

      osc.start(now);
      osc.stop(now + 0.5);
    } catch (_) {}
  }
}
