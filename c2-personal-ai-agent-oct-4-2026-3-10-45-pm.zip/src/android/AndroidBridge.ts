import {
  AndroidAccessibilityLog,
  AndroidDeviceState,
  AndroidFile,
  ToolCallResult,
} from '../types';

export const INITIAL_ANDROID_FILES: AndroidFile[] = [
  {
    file_id: 'doc_101',
    filename: 'workout.pdf',
    location: 'Downloads/workout.pdf',
    size: '2.4 MB',
    modified_date: '2026-09-04 14:20',
  },
  {
    file_id: 'doc_102',
    filename: 'homework.pdf',
    location: 'Downloads/homework.pdf',
    size: '1.2 MB',
    modified_date: '2026-09-06 09:15',
  },
  {
    file_id: 'doc_103',
    filename: 'annual_report.pdf',
    location: 'Documents/annual_report.pdf',
    size: '4.8 MB',
    modified_date: '2026-09-07 18:40',
  },
  {
    file_id: 'media_201',
    filename: 'trip_photo.jpg',
    location: 'DCIM/Camera/trip_photo.jpg',
    size: '3.6 MB',
    modified_date: '2026-08-28 11:05',
  },
  {
    file_id: 'doc_104',
    filename: 'notes.txt',
    location: 'Documents/notes.txt',
    size: '14 KB',
    modified_date: '2026-09-08 08:30',
  },
];

const PLAYLIST = [
  { trackTitle: 'Weightless', artist: 'Marconi Union', album: 'Ambient 1' },
  { trackTitle: 'Resonance', artist: 'HOME', album: 'Odyssey' },
  { trackTitle: 'Solaris', artist: 'Chicane', album: 'The Whole Nine Yards' },
  { trackTitle: 'Midnight City', artist: 'M83', album: 'Hurry Up, We\'re Dreaming' },
];

export class AndroidBridge {
  private state: AndroidDeviceState;

  constructor(initialCustomState?: Partial<AndroidDeviceState>) {
    this.state = {
      currentApp: 'Home',
      currentScreenTitle: 'Android Home Screen',
      activeInputQuery: '',
      mediaState: {
        isPlaying: false,
        trackTitle: PLAYLIST[0].trackTitle,
        artist: PLAYLIST[0].artist,
        album: PLAYLIST[0].album,
        trackIndex: 0,
      },
      settings: {
        wifi: true,
        bluetooth: false,
        soundVolume: 80,
        currentSection: 'main',
        accessibilityGranted: true,
        storagePermissionGranted: true,
      },
      files: [...INITIAL_ANDROID_FILES],
      accessibilityLogs: [],
      ...initialCustomState,
    };
  }

  public getState(): AndroidDeviceState {
    return { ...this.state };
  }

  public resetState() {
    this.state = {
      currentApp: 'Home',
      currentScreenTitle: 'Android Home Screen',
      activeInputQuery: '',
      mediaState: {
        isPlaying: false,
        trackTitle: PLAYLIST[0].trackTitle,
        artist: PLAYLIST[0].artist,
        album: PLAYLIST[0].album,
        trackIndex: 0,
      },
      settings: {
        wifi: true,
        bluetooth: false,
        soundVolume: 80,
        currentSection: 'main',
        accessibilityGranted: true,
        storagePermissionGranted: true,
      },
      files: [...INITIAL_ANDROID_FILES],
      accessibilityLogs: [],
    };
  }

  /**
   * Tool: open_app
   */
  public openApp(appName: string): ToolCallResult {
    const normalized = appName.trim().toLowerCase();
    const installed = ['youtube', 'chrome', 'spotify', 'files', 'settings', 'camera', 'messages', 'browser', 'music'];

    let targetApp = appName;
    if (normalized.includes('youtube')) targetApp = 'YouTube';
    else if (normalized.includes('chrome') || normalized === 'browser') targetApp = 'Chrome';
    else if (normalized.includes('spotify') || normalized === 'music') targetApp = 'Spotify';
    else if (normalized.includes('file')) targetApp = 'Files';
    else if (normalized.includes('setting')) targetApp = 'Settings';
    else if (normalized.includes('camera')) targetApp = 'Camera';
    else if (normalized.includes('message')) targetApp = 'Messages';

    const isRecognized = installed.some((app) => normalized.includes(app));

    if (!isRecognized && !['home'].includes(normalized)) {
      return {
        success: false,
        error: `App '${appName}' is not installed on this Android device.`,
      };
    }

    this.state.currentApp = targetApp;
    this.state.currentScreenTitle = `${targetApp} Main Screen`;
    this.state.activeInputQuery = '';

    return {
      success: true,
      message: `${targetApp} opened successfully on Android OS.`,
      data: { app: targetApp, status: 'RUNNING_FOREGROUND' },
    };
  }

  /**
   * Tool: find_file
   */
  public findFile(filename: string): ToolCallResult {
    const query = filename.trim().toLowerCase();
    const matches = this.state.files.filter((f) =>
      f.filename.toLowerCase().includes(query) || f.location.toLowerCase().includes(query)
    );

    if (matches.length === 0) {
      return {
        success: false,
        error: `No files matching '${filename}' were found in storage.`,
        data: { matches: [] },
      };
    }

    return {
      success: true,
      message: `Found ${matches.length} file${matches.length > 1 ? 's' : ''} matching '${filename}'.`,
      data: {
        matches,
        primary: matches[0],
      },
    };
  }

  /**
   * Tool: rename_file
   */
  public renameFile(fileId: string, newName: string): ToolCallResult {
    const fileIndex = this.state.files.findIndex((f) => f.file_id === fileId);
    if (fileIndex === -1) {
      return {
        success: false,
        error: `File with ID '${fileId}' not found in Android MediaStore.`,
      };
    }

    const oldName = this.state.files[fileIndex].filename;
    const oldLocation = this.state.files[fileIndex].location;
    const pathParts = oldLocation.split('/');
    pathParts[pathParts.length - 1] = newName;
    const newLocation = pathParts.join('/');

    this.state.files[fileIndex] = {
      ...this.state.files[fileIndex],
      filename: newName,
      location: newLocation,
      modified_date: new Date().toISOString().replace('T', ' ').substring(0, 16),
    };

    return {
      success: true,
      message: `Successfully renamed '${oldName}' to '${newName}'.`,
      data: { file: this.state.files[fileIndex] },
    };
  }

  /**
   * Tool: delete_file (HIGH RISK - executed only after confirmation)
   */
  public deleteFile(fileId: string): ToolCallResult {
    const file = this.state.files.find((f) => f.file_id === fileId);
    if (!file) {
      return {
        success: false,
        error: `File ID '${fileId}' could not be located. It may have already been deleted.`,
      };
    }

    this.state.files = this.state.files.filter((f) => f.file_id !== fileId);

    return {
      success: true,
      message: `Deleted '${file.filename}' from ${file.location}.`,
      data: { deletedFileId: fileId, filename: file.filename },
    };
  }

  /**
   * Tool: move_file
   */
  public moveFile(fileId: string, destination: string): ToolCallResult {
    const fileIndex = this.state.files.findIndex((f) => f.file_id === fileId);
    if (fileIndex === -1) {
      return {
        success: false,
        error: `File with ID '${fileId}' not found.`,
      };
    }

    const cleanDest = destination.endsWith('/') ? destination.slice(0, -1) : destination;
    const filename = this.state.files[fileIndex].filename;
    const newLocation = `${cleanDest}/${filename}`;

    this.state.files[fileIndex] = {
      ...this.state.files[fileIndex],
      location: newLocation,
      modified_date: new Date().toISOString().replace('T', ' ').substring(0, 16),
    };

    return {
      success: true,
      message: `Moved '${filename}' to '${newLocation}'.`,
      data: { file: this.state.files[fileIndex] },
    };
  }

  /**
   * Tool: media_control
   */
  public mediaControl(action: 'play' | 'pause' | 'next' | 'previous'): ToolCallResult {
    const current = this.state.mediaState;
    if (action === 'play') {
      this.state.mediaState = { ...current, isPlaying: true };
      return {
        success: true,
        message: `Now playing "${current.trackTitle}" by ${current.artist}.`,
        data: this.state.mediaState,
      };
    } else if (action === 'pause') {
      this.state.mediaState = { ...current, isPlaying: false };
      return {
        success: true,
        message: `Media playback paused.`,
        data: this.state.mediaState,
      };
    } else if (action === 'next') {
      const nextIdx = (current.trackIndex + 1) % PLAYLIST.length;
      const nextTrack = PLAYLIST[nextIdx];
      this.state.mediaState = {
        isPlaying: true,
        trackTitle: nextTrack.trackTitle,
        artist: nextTrack.artist,
        album: nextTrack.album,
        trackIndex: nextIdx,
      };
      return {
        success: true,
        message: `Skipped to next: "${nextTrack.trackTitle}" by ${nextTrack.artist}.`,
        data: this.state.mediaState,
      };
    } else if (action === 'previous') {
      const prevIdx = (current.trackIndex - 1 + PLAYLIST.length) % PLAYLIST.length;
      const prevTrack = PLAYLIST[prevIdx];
      this.state.mediaState = {
        isPlaying: true,
        trackTitle: prevTrack.trackTitle,
        artist: prevTrack.artist,
        album: prevTrack.album,
        trackIndex: prevIdx,
      };
      return {
        success: true,
        message: `Returned to: "${prevTrack.trackTitle}" by ${prevTrack.artist}.`,
        data: this.state.mediaState,
      };
    }

    return { success: false, error: `Unknown media action '${action}'.` };
  }

  /**
   * Tool: open_settings
   */
  public openSettings(section: string): ToolCallResult {
    const sec = section.toLowerCase().trim();
    this.state.currentApp = 'Settings';
    this.state.settings.currentSection = sec;
    this.state.currentScreenTitle = `Android Settings > ${sec.toUpperCase()}`;

    let message = `Opened Settings (${section}).`;
    if (sec.includes('wifi') || sec.includes('wi-fi') || sec.includes('network')) {
      message = 'Opened Wi-Fi & Network Settings.';
    } else if (sec.includes('bluetooth')) {
      message = 'Opened Bluetooth & Connected Devices.';
    } else if (sec.includes('sound') || sec.includes('audio')) {
      message = 'Opened Sound & Vibration Settings.';
    } else if (sec.includes('accessibility')) {
      message = 'Opened Accessibility Services Settings.';
    }

    return {
      success: true,
      message,
      data: { section: sec, settings: this.state.settings },
    };
  }

  /**
   * Tool: take_screenshot
   */
  public takeScreenshot(): ToolCallResult {
    const timestamp = new Date().toISOString();
    const caption = `Screenshot of ${this.state.currentApp} (${this.state.currentScreenTitle})`;
    this.state.recentScreenshot = `Simulated screenshot generated at ${timestamp.substring(11, 19)}`;

    return {
      success: true,
      message: `Captured screenshot of ${this.state.currentApp}.`,
      data: {
        timestamp,
        caption,
        app: this.state.currentApp,
      },
    };
  }

  /**
   * Tool: accessibility_action
   */
  public accessibilityAction(action: 'click' | 'scroll' | 'swipe' | 'type' | 'back', target?: string): ToolCallResult {
    const log: AndroidAccessibilityLog = {
      id: 'acc_' + Date.now(),
      timestamp: new Date().toISOString().substring(11, 19),
      action,
      target: target || 'screen',
      success: true,
    };

    if (action === 'back') {
      if (this.state.currentApp !== 'Home') {
        this.state.currentApp = 'Home';
        this.state.currentScreenTitle = 'Android Home Screen';
      }
      this.state.accessibilityLogs.unshift(log);
      return {
        success: true,
        message: 'Navigated back to previous screen.',
        data: { newScreen: this.state.currentScreenTitle },
      };
    }

    if (action === 'type' && target) {
      this.state.activeInputQuery = target;
      if (this.state.currentApp === 'YouTube') {
        this.state.currentScreenTitle = `YouTube Search: "${target}"`;
      } else if (this.state.currentApp === 'Chrome') {
        this.state.currentScreenTitle = `Google: "${target}"`;
      }
      this.state.accessibilityLogs.unshift(log);
      return {
        success: true,
        message: `Typed "${target}" into active input field.`,
        data: { input: target },
      };
    }

    if (action === 'click') {
      const targetStr = target || 'focused element';
      if (targetStr.toLowerCase().includes('search')) {
        this.state.currentScreenTitle = `${this.state.currentApp} Search Active`;
      }
      this.state.accessibilityLogs.unshift(log);
      return {
        success: true,
        message: `Clicked on "${targetStr}".`,
        data: { target: targetStr },
      };
    }

    if (action === 'scroll' || action === 'swipe') {
      this.state.accessibilityLogs.unshift(log);
      return {
        success: true,
        message: `${action === 'scroll' ? 'Scrolled' : 'Swiped'} on screen.`,
        data: { action, target: target || 'viewport' },
      };
    }

    return {
      success: false,
      error: `Unsupported accessibility action '${action}'.`,
    };
  }
}
