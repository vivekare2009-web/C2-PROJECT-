/**
 * C2 Voice Configuration — GPT-SoVITS Voice Architecture
 * Authorized Reference Voice: Euphemiya
 * Characteristics: Cute anime-inspired style, bright vocal character,
 * soft/light vocal quality, expressive, friendly, lively, clear pronunciation,
 * natural conversational pacing, gentle emotional variation.
 */

export type GPTSoVITSStatus =
  | 'GPT-SOVITS NOT CONFIGURED'
  | 'GPT-SOVITS CONNECTING'
  | 'GPT-SOVITS READY'
  | 'GPT-SOVITS GENERATING'
  | 'GPT-SOVITS SPEAKING'
  | 'GPT-SOVITS OFFLINE'
  | 'GPT-SOVITS ERROR';

export type VoiceEmotion = 'happy' | 'curious' | 'calm' | 'surprised' | 'concerned' | 'neutral';

export interface VoiceEngineConfig {
  endpoint: string;
  refAudioPath: string;
  promptText: string;
  promptLang: string;
  defaultTextLang: string;
  characterProfile: {
    name: string;
    style: string;
    vocalQuality: string;
    personality: string;
    emotionalVariation: string;
  };
}

export const DEFAULT_VOICE_CONFIG: VoiceEngineConfig = {
  endpoint: '',
  refAudioPath: 'voice/euphemiya_reference.wav',
  promptText: 'Yeh painting, mujhe yeh wali painting achi lagi. Aisa hai to is painting ko yahan rakhna hi nahi.',
  promptLang: 'hi',
  defaultTextLang: 'en',
  characterProfile: {
    name: 'C2 (Euphemiya Voice Architecture)',
    style: 'cute anime-inspired style, bright and energetic',
    vocalQuality: 'soft, light, clear pronunciation, warm resonance',
    personality: 'expressive, friendly, lively, empathetic, loyal assistant',
    emotionalVariation: 'subtle, conversational pauses, natural intonation',
  },
};

/**
 * Clean & normalize text for GPT-SoVITS speech synthesis
 * Strips markdown symbols, URLs, asterisks, brackets, and prepares natural punctuation.
 */
export function normalizeTextForSpeech(rawText: string): string {
  if (!rawText) return '';

  let text = rawText
    // Remove code blocks and inline code
    .replace(/```[\s\S]*?```/g, '')
    .replace(/`([^`]+)`/g, '$1')
    // Remove markdown links but keep text
    .replace(/\[([^\]]+)\]\([^)]+\)/g, '$1')
    // Remove URLs
    .replace(/https?:\/\/\S+/g, '')
    // Remove markdown formatting like bold/italic asterisks or underscores
    .replace(/[*_~#]/g, '')
    // Remove curly braces or bracket metadata
    .replace(/\{[^}]+\}/g, '')
    .replace(/\[[^\]]+\]/g, '')
    // Remove HTML tags
    .replace(/<[^>]+>/g, '')
    // Replace multiple spaces or newlines with a single space
    .replace(/\s+/g, ' ')
    .trim();

  // Ensure trailing punctuation for natural sentence end
  if (text && !/[.!?]$/.test(text)) {
    text += '.';
  }

  return text;
}

/**
 * Detect primary language of text to route correctly to GPT-SoVITS text_lang
 */
export function detectLanguageForTTS(text: string): 'en' | 'hi' | 'ja' | 'zh' {
  // Check for Devanagari script (Hindi)
  if (/[\u0900-\u097F]/.test(text)) {
    return 'hi';
  }
  // Check for Japanese characters (Hiragana / Katakana / Kanji)
  if (/[\u3040-\u30ff\u3400-\u4dbf\u4e00-\u9fff]/.test(text)) {
    return 'ja';
  }
  // Check for Chinese characters
  if (/[\u4e00-\u9fa5]/.test(text)) {
    return 'zh';
  }
  // Default to English (or Hinglish written in Latin alphabet)
  return 'en';
}
