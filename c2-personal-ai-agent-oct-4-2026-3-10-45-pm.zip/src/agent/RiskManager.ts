import { RiskLevel, ToolDefinition } from '../types';

export const TOOL_DEFINITIONS: Record<string, ToolDefinition> = {
  open_app: {
    name: 'open_app',
    description: 'Launch an installed application on the Android device.',
    parameters: {
      app_name: {
        type: 'string',
        description: 'Name of the application (e.g., YouTube, Chrome, Settings, Spotify, Files).',
        required: true,
      },
    },
    risk: 'LOW',
    requiresConfirmation: false,
    category: 'app',
    permissions: ['android.permission.QUERY_ALL_PACKAGES'],
    executionMethod: 'Intent / PackageManager.getLaunchIntentForPackage()',
  },
  find_file: {
    name: 'find_file',
    description: 'Search for files by name in Android storage and return file metadata.',
    parameters: {
      filename: {
        type: 'string',
        description: 'Name or partial name of the file to locate (e.g., workout.pdf, homework.pdf).',
        required: true,
      },
    },
    risk: 'LOW',
    requiresConfirmation: false,
    category: 'files',
    permissions: ['android.permission.READ_MEDIA_DOCUMENTS', 'android.permission.READ_MEDIA_IMAGES'],
    executionMethod: 'MediaStore / ContentResolver query with scoped storage ID',
  },
  rename_file: {
    name: 'rename_file',
    description: 'Rename an existing file identified by its file_id.',
    parameters: {
      file_id: {
        type: 'string',
        description: 'Unique file ID returned by find_file.',
        required: true,
      },
      new_name: {
        type: 'string',
        description: 'New file name including extension (e.g., training.pdf).',
        required: true,
      },
    },
    risk: 'MEDIUM',
    requiresConfirmation: false,
    category: 'files',
    permissions: ['android.permission.MANAGE_EXTERNAL_STORAGE'],
    executionMethod: 'DocumentsContract.renameDocument()',
  },
  delete_file: {
    name: 'delete_file',
    description: 'Permanently remove a file from device storage. HIGH risk destructive action.',
    parameters: {
      file_id: {
        type: 'string',
        description: 'Unique file ID returned by find_file.',
        required: true,
      },
    },
    risk: 'HIGH',
    requiresConfirmation: true,
    category: 'files',
    permissions: ['android.permission.MANAGE_EXTERNAL_STORAGE'],
    executionMethod: 'DocumentsContract.deleteDocument() / MediaStore delete intent',
  },
  move_file: {
    name: 'move_file',
    description: 'Relocate a file to a new target folder.',
    parameters: {
      file_id: {
        type: 'string',
        description: 'Unique file ID returned by find_file.',
        required: true,
      },
      destination: {
        type: 'string',
        description: 'Destination directory path (e.g., Documents/Archived, Downloads).',
        required: true,
      },
    },
    risk: 'MEDIUM',
    requiresConfirmation: false,
    category: 'files',
    permissions: ['android.permission.MANAGE_EXTERNAL_STORAGE'],
    executionMethod: 'DocumentsContract.moveDocument()',
  },
  media_control: {
    name: 'media_control',
    description: 'Control media playback (play, pause, next, previous track).',
    parameters: {
      action: {
        type: 'string',
        enum: ['play', 'pause', 'next', 'previous'],
        description: 'Playback command to send to active media session.',
        required: true,
      },
    },
    risk: 'LOW',
    requiresConfirmation: false,
    category: 'media',
    permissions: ['android.permission.MEDIA_CONTENT_CONTROL'],
    executionMethod: 'MediaSessionManager / MediaControllerCompat.getTransportControls()',
  },
  open_settings: {
    name: 'open_settings',
    description: 'Navigate directly to a specific section of Android Settings.',
    parameters: {
      section: {
        type: 'string',
        description: 'Settings sub-section (e.g., wifi, bluetooth, display, sound, apps, accessibility).',
        required: true,
      },
    },
    risk: 'LOW',
    requiresConfirmation: false,
    category: 'settings',
    permissions: [],
    executionMethod: 'Intent(Settings.ACTION_*)',
  },
  take_screenshot: {
    name: 'take_screenshot',
    description: 'Capture an instant screenshot of the current Android screen.',
    parameters: {},
    risk: 'MEDIUM',
    requiresConfirmation: false,
    category: 'system',
    permissions: ['android.permission.FOREGROUND_SERVICE_MEDIA_PROJECTION'],
    executionMethod: 'MediaProjectionManager / AccessibilityService.takeScreenshot()',
  },
  accessibility_action: {
    name: 'accessibility_action',
    description: 'Perform an accessibility interaction on current UI (click, scroll, swipe, type, back).',
    parameters: {
      action: {
        type: 'string',
        enum: ['click', 'scroll', 'swipe', 'type', 'back'],
        description: 'Accessibility gesture or UI action.',
        required: true,
      },
      target: {
        type: 'string',
        description: 'Target UI element description, text, or node ID (e.g. "Search field", "home workout").',
        required: false,
      },
    },
    risk: 'MEDIUM',
    requiresConfirmation: false,
    category: 'accessibility',
    permissions: ['android.permission.BIND_ACCESSIBILITY_SERVICE'],
    executionMethod: 'AccessibilityNodeInfo.performAction() / dispatchGesture()',
  },
  // Future tools catalog
  send_message: {
    name: 'send_message',
    description: 'Send an SMS or chat message to a contact (High Risk).',
    parameters: {
      recipient: { type: 'string', required: true },
      message: { type: 'string', required: true },
    },
    risk: 'HIGH',
    requiresConfirmation: true,
    category: 'system',
    permissions: ['android.permission.SEND_SMS'],
    executionMethod: 'SmsManager.getDefault().sendTextMessage()',
  },
  create_folder: {
    name: 'create_folder',
    description: 'Create a new folder in device storage.',
    parameters: {
      path: { type: 'string', required: true },
      name: { type: 'string', required: true },
    },
    risk: 'LOW',
    requiresConfirmation: false,
    category: 'files',
    permissions: ['android.permission.MANAGE_EXTERNAL_STORAGE'],
    executionMethod: 'DocumentsContract.createDocument()',
  },
  list_files: {
    name: 'list_files',
    description: 'List contents of a directory.',
    parameters: {
      folder: { type: 'string', required: true },
    },
    risk: 'LOW',
    requiresConfirmation: false,
    category: 'files',
    permissions: ['android.permission.READ_EXTERNAL_STORAGE'],
    executionMethod: 'ContentResolver query',
  },
};

export class RiskManager {
  /**
   * Determine the risk level of an action.
   * Safety rule: Never allow LLM alone to bypass or downgrade risk.
   */
  public static evaluateRisk(toolName: string): RiskLevel {
    const def = TOOL_DEFINITIONS[toolName];
    if (!def) {
      return 'HIGH'; // Unknown tools are treated as high risk
    }
    return def.risk;
  }

  public static requiresConfirmation(toolName: string, args: Record<string, any>): boolean {
    const def = TOOL_DEFINITIONS[toolName];
    if (!def) return true;
    if (def.requiresConfirmation) return true;
    if (toolName === 'delete_file') return true;
    if (toolName === 'send_message') return true;
    return false;
  }

  public static validateArguments(toolName: string, args: Record<string, any>): { valid: boolean; error?: string } {
    const def = TOOL_DEFINITIONS[toolName];
    if (!def) {
      return { valid: false, error: `Unrecognized tool: ${toolName}. Only registered tools are permitted.` };
    }

    for (const [paramName, spec] of Object.entries(def.parameters)) {
      if (spec.required && (args[paramName] === undefined || args[paramName] === null || args[paramName] === '')) {
        return { valid: false, error: `Missing required argument '${paramName}' for tool '${toolName}'.` };
      }
    }

    return { valid: true };
  }
}
