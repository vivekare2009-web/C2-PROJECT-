import React, { useEffect, useState, useRef, useCallback } from 'react';
import { AtmosphereBackground } from './components/AtmosphereBackground';
import { TopStatusBar } from './components/TopStatusBar';
import { VoiceCore } from './components/VoiceCore';
import { WaveformVisualizer } from './components/WaveformVisualizer';
import { ToolActivityHud } from './components/ToolActivityHud';
import { VoicePrompts } from './components/VoicePrompts';
import { IdentityMemoryModal } from './components/IdentityMemoryModal';
import { GeminiDiagnosticModal } from './components/GeminiDiagnosticModal';
import { GeminiKeyManagerModal, KeyModalMode } from './components/GeminiKeyManagerModal';
import { AvatarVideoPlayer } from './components/avatar/AvatarVideoPlayer';
import { AvatarSettingsModal } from './components/avatar/AvatarSettingsModal';
import { avatarVideoStateManager } from './modules/avatar/AvatarVideoStateManager';
import { safeStorage } from './utils/safeStorage';

import { AudioStreamer } from './modules/AudioStreamer';
import { AudioPlayer } from './modules/AudioPlayer';
import { ToolManager } from './modules/ToolManager';
import { StateManager, AssistantState } from './modules/StateManager';
import { LiveSession } from './modules/LiveSession';
import { AtmosphereTheme, UserProfile, ApiKeyStatus } from './types';
import { AlertTriangle, Sparkles, User, Database, CheckCircle2, Volume2, Send, Mic, MicOff, ExternalLink } from 'lucide-react';

export default function App() {
  const [state, setState] = useState<AssistantState>({
    connectionState: 'disconnected',
    inputLevel: 0,
    outputLevel: 0,
    isMuted: false,
    atmosphere: 'nebula',
    activeTool: null,
    toolHistory: [],
    latencyMs: 38,
    sessionStartTime: null,
    sessionSeconds: 0,
    lastError: null,
    micPermission: 'prompt',
    selectedVoice: 'Aoede',
    currentUser: null,
    memories: [],
    greeting: 'Hey Master, good to see you again.',
    isFirstLogin: false,
    engineMode: 'gemini_live',
    notice: null,
  });

  const [allUsers, setAllUsers] = useState<UserProfile[]>([]);
  const [isIdentityModalOpen, setIsIdentityModalOpen] = useState(false);
  const [isGeminiDiagnosticOpen, setIsGeminiDiagnosticOpen] = useState(false);
  const [isAvatarSettingsOpen, setIsAvatarSettingsOpen] = useState(false);
  const [keyStatus, setKeyStatus] = useState<ApiKeyStatus | null>(null);
  const [isKeyModalOpen, setIsKeyModalOpen] = useState(false);
  const [keyModalMode, setKeyModalMode] = useState<KeyModalMode>('onboarding');
  const [greetingNotification, setGreetingNotification] = useState<string | null>(null);
  const [lastResponse, setLastResponse] = useState<{ text: string; language: string } | null>(null);
  const [isSpeakingResponse, setIsSpeakingResponse] = useState(false);
  const [typedMessage, setTypedMessage] = useState('');
  const [isSendingChat, setIsSendingChat] = useState(false);

  // Module singletons held in refs
  const streamerRef = useRef<AudioStreamer | null>(null);
  const playerRef = useRef<AudioPlayer | null>(null);
  const toolManagerRef = useRef<ToolManager | null>(null);
  const stateManagerRef = useRef<StateManager | null>(null);
  const liveSessionRef = useRef<LiveSession | null>(null);

  // Load persistent user profile & memories from server database
  const loadUserSession = useCallback(async (targetUserId?: string) => {
    try {
      const storedId = targetUserId || safeStorage.getItem('c2_user_id') || '';
      const query = storedId ? `?userId=${encodeURIComponent(storedId)}` : '';
      const res = await fetch(`/api/c2/auth/me${query}`);
      const data = await res.json();

      if (data.success && data.user) {
        safeStorage.setItem('c2_user_id', data.user.id);
        if (stateManagerRef.current) {
          stateManagerRef.current.setCurrentUser(data.user, data.memories || [], data.greeting);
        }
        if (toolManagerRef.current) {
          toolManagerRef.current.setCurrentUserId(data.user.id);
        }
        if (data.allUsers) {
          setAllUsers(data.allUsers);
        }

        // Show C2's initial recognition greeting
        setGreetingNotification(data.greeting);
      }
    } catch (err) {
      console.warn('Could not load persistent user session:', err);
    }
  }, []);

  // Fetch key status & check if onboarding or quota prompt is needed
  const fetchKeyStatus = useCallback(async () => {
    try {
      const res = await fetch('/api/c2/keys/status');
      const data: ApiKeyStatus = await res.json();
      setKeyStatus(data);

      const onboardingDone = safeStorage.getItem('c2_api_key_onboarding_completed') === 'true';

      if (data.quotaExhausted) {
        setKeyModalMode('quota_exhausted');
        setIsKeyModalOpen(true);
      } else if (!data.hasKey && !onboardingDone) {
        // Ask once when the user opens/downloads the app
        setKeyModalMode('onboarding');
        setIsKeyModalOpen(true);
      }
    } catch (e) {
      console.error('Error fetching key status:', e);
    }
  }, []);

  // Initialize Modules & Handlers
  useEffect(() => {
    const streamer = new AudioStreamer();
    const player = new AudioPlayer();
    const toolManager = new ToolManager();
    const stateManager = new StateManager();

    const liveSession = new LiveSession(streamer, player, toolManager, stateManager);

    streamerRef.current = streamer;
    playerRef.current = player;
    toolManagerRef.current = toolManager;
    stateManagerRef.current = stateManager;
    liveSessionRef.current = liveSession;

    // Subscribe to observable state
    const unsubscribe = stateManager.subscribe((newState) => {
      setState({ ...newState });
    });

    // Subscribe to speech responses from live session
    const unsubSpeech = liveSession.onSpeechResponse((text, language) => {
      setLastResponse({ text, language });
    });

    // Listen to real-time tool updates of user profile/memories
    const unsubUser = toolManager.onUserUpdated((user, memories) => {
      stateManager.setCurrentUser(user, memories);
      safeStorage.setItem('c2_user_id', user.id);
      loadUserSession(user.id);
    });

    // Load initial user session
    loadUserSession();
    fetchKeyStatus();

    // Listen to quota exhaustion events from live session to trigger key input
    const unsubQuota = liveSession.onQuotaExhausted(() => {
      setKeyModalMode('quota_exhausted');
      setIsKeyModalOpen(true);
      fetchKeyStatus();
    });

    return () => {
      unsubscribe();
      unsubSpeech();
      unsubUser();
      unsubQuota();
      liveSession.disconnect();
    };
  }, [loadUserSession, fetchKeyStatus]);

  const handleToggleConnection = async () => {
    if (!liveSessionRef.current) return;

    if (state.connectionState === 'disconnected' || state.connectionState === 'error') {
      await liveSessionRef.current.connect();
    } else {
      liveSessionRef.current.disconnect();
    }
  };

  const handleToggleMute = () => {
    if (liveSessionRef.current) {
      liveSessionRef.current.toggleMute();
    }
  };

  const handleInterrupt = () => {
    if (liveSessionRef.current) {
      liveSessionRef.current.interrupt();
    }
  };

  const handleRequestMic = async () => {
    if (liveSessionRef.current) {
      const res = await liveSessionRef.current.retryMicrophone();
      if (!res.success) {
        console.warn('[VOICE] User retry microphone result:', res.error);
      }
    } else if (streamerRef.current) {
      const res = await streamerRef.current.start();
      if (res.success && stateManagerRef.current) {
        stateManagerRef.current.setMicPermission('granted');
      }
    }
  };

  const handleAtmosphereChange = (theme: AtmosphereTheme) => {
    if (stateManagerRef.current) {
      stateManagerRef.current.setAtmosphere(theme);
    }
  };

  const handleVoiceChange = (voice: string) => {
    if (stateManagerRef.current) {
      stateManagerRef.current.setSelectedVoice(voice);
    }
  };

  // Switch User Account
  const handleSwitchUser = async (userId: string) => {
    try {
      const res = await fetch('/api/c2/auth/login', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ identifier: userId }),
      });
      const data = await res.json();
      if (data.success && data.user) {
        safeStorage.setItem('c2_user_id', data.user.id);
        if (stateManagerRef.current) {
          stateManagerRef.current.setCurrentUser(data.user, data.memories || [], data.greeting);
        }
        if (toolManagerRef.current) {
          toolManagerRef.current.setCurrentUserId(data.user.id);
        }
        setGreetingNotification(data.greeting);

        // If session was connected, reconnect with new user context
        if (state.connectionState !== 'disconnected' && liveSessionRef.current) {
          liveSessionRef.current.disconnect();
          setTimeout(() => liveSessionRef.current?.connect(), 400);
        }
      }
    } catch (e) {
      console.error('Error switching user:', e);
    }
  };

  // Create New User Account (Test First Login Flow)
  const handleCreateUser = async (email: string, displayName: string, preferredName: string) => {
    try {
      const res = await fetch('/api/c2/auth/register', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ email, displayName, preferredName }),
      });
      const data = await res.json();
      if (data.success && data.user) {
        safeStorage.setItem('c2_user_id', data.user.id);
        if (stateManagerRef.current) {
          stateManagerRef.current.setCurrentUser(data.user, data.memories || [], data.greeting);
        }
        if (toolManagerRef.current) {
          toolManagerRef.current.setCurrentUserId(data.user.id);
        }
        setGreetingNotification(data.greeting);
        loadUserSession(data.user.id);

        if (state.connectionState !== 'disconnected' && liveSessionRef.current) {
          liveSessionRef.current.disconnect();
          setTimeout(() => liveSessionRef.current?.connect(), 400);
        }
      }
    } catch (e) {
      console.error('Error creating user:', e);
    }
  };

  // Update Preferred Name / Title
  const handleUpdatePreferredName = async (name: string) => {
    if (!state.currentUser) return;
    try {
      const res = await fetch('/api/c2/auth/preferred-name', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ userId: state.currentUser.id, preferredName: name }),
      });
      const data = await res.json();
      if (data.success && data.user) {
        if (stateManagerRef.current) {
          stateManagerRef.current.setCurrentUser(data.user, data.memories || []);
        }
      }
    } catch (e) {
      console.error('Error updating preferred title:', e);
    }
  };

  // Add Memory Manually
  const handleAddMemory = async (category: string, key: string, value: string) => {
    if (!state.currentUser) return;
    try {
      const res = await fetch('/api/c2/memory/set', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ userId: state.currentUser.id, category, key, value }),
      });
      const data = await res.json();
      if (data.success && data.memories) {
        if (stateManagerRef.current) {
          stateManagerRef.current.setMemories(data.memories);
        }
      }
    } catch (e) {
      console.error('Error adding memory:', e);
    }
  };

  // Delete Memory
  const handleDeleteMemory = async (id: string) => {
    try {
      const res = await fetch('/api/c2/memory/delete', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ id }),
      });
      const data = await res.json();
      if (data.success && data.memories) {
        if (stateManagerRef.current) {
          stateManagerRef.current.setMemories(data.memories);
        }
      }
    } catch (e) {
      console.error('Error deleting memory:', e);
    }
  };

  // Clear All Memories
  const handleClearMemories = async () => {
    try {
      const res = await fetch('/api/c2/memory/clear', { method: 'POST' });
      const data = await res.json();
      if (data.success) {
        if (stateManagerRef.current) {
          stateManagerRef.current.setMemories([]);
        }
      }
    } catch (e) {
      console.error('Error clearing memories:', e);
    }
  };

  // C2 Voice Speech Synthesizer
  const speakResponse = (text: string, language: string = 'English') => {
    if (typeof window === 'undefined' || !('speechSynthesis' in window)) return;
    try {
      window.speechSynthesis.cancel();
      const clean = text.replace(/[*_#`]/g, '').replace(/https?:\/\/\S+/g, '').trim();
      if (!clean) return;

      const utterance = new SpeechSynthesisUtterance(clean);
      const voices = window.speechSynthesis.getVoices();
      const isHindi = language.toLowerCase().includes('hi');
      const selectedVoice =
        voices.find(v => isHindi && (v.lang.startsWith('hi') || v.name.includes('Female') || v.name.includes('Kalpana'))) ||
        voices.find(v => (v.name.includes('Samantha') || v.name.includes('Victoria') || v.name.includes('Natural') || v.name.includes('Google US English')) && !v.name.toLowerCase().includes('male')) ||
        voices.find(v => v.name.toLowerCase().includes('female')) ||
        voices[0];

      if (selectedVoice) utterance.voice = selectedVoice;
      utterance.pitch = 1.08;
      utterance.rate = 1.03;

      setIsSpeakingResponse(true);
      avatarVideoStateManager.onSpeechStarted();

      utterance.onend = () => {
        setIsSpeakingResponse(false);
        avatarVideoStateManager.onSpeechFinished();
      };
      utterance.onerror = (e) => {
        setIsSpeakingResponse(false);
        avatarVideoStateManager.onSpeechError(e);
      };
      window.speechSynthesis.speak(utterance);
    } catch (err) {
      console.warn('SpeechSynthesis error:', err);
      setIsSpeakingResponse(false);
      avatarVideoStateManager.onSpeechError(err);
    }
  };

  // Send Prompt to C2 Brain (Voice engine or fallback)
  const handlePromptSubmit = async (promptText: string) => {
    const text = promptText.trim();
    if (!text || isSendingChat) return;

    setTypedMessage('');

    // Trigger thinking or upset reaction on character video
    const taskResult = avatarVideoStateManager.onTaskStarted(text);

    // If live session is active, route directly through live session WebSocket
    if (state.connectionState !== 'disconnected' && state.connectionState !== 'error' && liveSessionRef.current) {
      liveSessionRef.current.sendTextMessage(text);
      return;
    }

    setIsSendingChat(true);
    try {
      const res = await fetch('/api/c2/chat', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ message: text }),
      });
      const data = await res.json();
      if (data.text) {
        setLastResponse({ text: data.text, language: data.language || 'English' });
        speakResponse(data.text, data.language || 'English');
        if (data.notice && stateManagerRef.current) {
          stateManagerRef.current.setNotice(data.notice);
        }
        if (data.engine && stateManagerRef.current) {
          stateManagerRef.current.setEngineMode(data.engine);
        }
        // Reload persistent user state & memories
        loadUserSession();
      } else {
        avatarVideoStateManager.resetToIdle();
      }
    } catch (err) {
      console.error('Error communicating with C2:', err);
      avatarVideoStateManager.onTaskError(String(err));
    } finally {
      setIsSendingChat(false);
    }
  };

  const activeLevel = state.connectionState === 'speaking' ? state.outputLevel : state.inputLevel;

  return (
    <div className="relative min-h-screen w-full flex flex-col justify-between text-white font-sans overflow-x-hidden selection:bg-violet-500 selection:text-white">
      {/* 3D Atmosphere Canvas Background */}
      <AtmosphereBackground theme={state.atmosphere} intensity={activeLevel} />

      {/* Top Status & Controls Header */}
      <TopStatusBar
        connectionState={state.connectionState}
        latencyMs={state.latencyMs}
        sessionSeconds={state.sessionSeconds}
        atmosphere={state.atmosphere}
        selectedVoice={state.selectedVoice}
        currentUser={state.currentUser}
        memoryCount={state.memories.length}
        keyStatus={keyStatus}
        onAtmosphereChange={handleAtmosphereChange}
        onVoiceChange={handleVoiceChange}
        onOpenIdentityModal={() => setIsIdentityModalOpen(true)}
        onOpenGeminiDiagnostic={() => setIsGeminiDiagnosticOpen(true)}
        onOpenKeyModal={() => {
          setKeyModalMode('settings');
          setIsKeyModalOpen(true);
        }}
      />

      {/* Main Voice Space (Voice Only, No Text Chat) */}
      <main className="flex-1 w-full max-w-2xl mx-auto px-4 flex flex-col items-center justify-center relative z-20 py-2">
        {/* Error / Alert Banner */}
        {state.lastError && (
          <div className="w-full max-w-md mx-auto mb-4 p-3 rounded-xl bg-rose-950/80 border border-rose-500/40 backdrop-blur-xl flex items-start gap-2.5 text-xs text-rose-200 shadow-xl animate-in fade-in">
            <AlertTriangle className="w-4 h-4 text-rose-400 shrink-0 mt-0.5" />
            <div className="flex-1">
              <span className="font-semibold block mb-0.5">Connection Notice</span>
              <span className="leading-relaxed">{state.lastError}</span>
              <div className="mt-2 flex items-center gap-2">
                <button
                  id="c2-reconnect-btn"
                  onClick={handleToggleConnection}
                  className="px-2.5 py-1 rounded-md bg-rose-500/20 hover:bg-rose-500/30 text-rose-200 text-[11px] font-medium transition-colors"
                >
                  Reconnect Voice
                </button>
                <button
                  onClick={() => setIsGeminiDiagnosticOpen(true)}
                  className="px-2.5 py-1 rounded-md bg-white/10 hover:bg-white/15 text-slate-300 text-[11px] transition-colors"
                >
                  Diagnostic Details
                </button>
              </div>
            </div>
            <button
              onClick={() => stateManagerRef.current?.setError(null)}
              className="text-rose-400 hover:text-white text-xs font-mono px-1.5 py-0.5"
            >
              ✕
            </button>
          </div>
        )}

        {/* C2 Engine Notice / Fallback Banner */}
        {state.notice && (
          <div className="w-full max-w-md mx-auto mb-3 p-2.5 rounded-xl bg-amber-950/40 border border-amber-500/30 backdrop-blur-xl flex items-center justify-between gap-3 text-xs shadow-lg animate-in fade-in">
            <div className="flex items-center gap-2 min-w-0">
              <div className="w-5 h-5 rounded-full bg-amber-500/20 border border-amber-400/40 flex items-center justify-center shrink-0 text-amber-300 text-[10px]">
                ⚡
              </div>
              <div className="truncate">
                <div className="text-[10px] uppercase font-mono tracking-wider text-amber-300 font-semibold">
                  Local Engine Active
                </div>
                <div className="text-slate-300 text-[11px] leading-tight truncate">
                  {state.notice}
                </div>
              </div>
            </div>
            <button
              onClick={() => setIsGeminiDiagnosticOpen(true)}
              className="text-amber-300 hover:text-white text-[10px] px-2 py-1 rounded bg-amber-500/20 border border-amber-400/30 shrink-0 font-medium transition-colors"
            >
              Secrets Info
            </button>
          </div>
        )}

        {/* Microphone Permission Notice Banner */}
        {state.micPermission === 'denied' && (
          <div className="w-full max-w-md mx-auto mb-3 p-3 rounded-xl bg-amber-950/70 border border-amber-500/40 backdrop-blur-xl text-xs text-amber-200 shadow-xl animate-in fade-in">
            <div className="flex items-start gap-2.5">
              <MicOff className="w-4 h-4 text-amber-400 shrink-0 mt-0.5" />
              <div className="flex-1">
                <span className="font-semibold block mb-0.5 text-amber-100">
                  Microphone Access Blocked
                </span>
                <span className="text-amber-200/90 leading-relaxed block mb-2">
                  C2 is currently in <strong>Speaker & Text Mode</strong>. You can type commands below and hear C2 speak. To speak with your voice, grant microphone access.
                </span>

                <div className="flex flex-wrap items-center gap-2">
                  <button
                    id="grant-mic-permission-btn"
                    onClick={handleRequestMic}
                    className="px-3 py-1 rounded-md bg-amber-500 hover:bg-amber-400 text-slate-950 font-semibold text-[11px] transition-colors cursor-pointer flex items-center gap-1"
                  >
                    <Mic className="w-3 h-3" />
                    Grant Microphone
                  </button>

                  <a
                    href={window.location.href}
                    target="_blank"
                    rel="noreferrer"
                    className="px-2.5 py-1 rounded-md bg-white/10 hover:bg-white/15 text-slate-200 text-[11px] transition-colors cursor-pointer flex items-center gap-1"
                    title="Open app in a standalone tab for direct browser permissions"
                  >
                    <ExternalLink className="w-3 h-3" />
                    Open in New Tab
                  </a>
                </div>

                <div className="mt-2.5 pt-2 border-t border-amber-500/20 text-[10px] text-amber-300/80 leading-normal">
                  💡 <strong>Tip for Android Chrome:</strong> Tap the lock 🔒 or site settings icon next to the address bar → <em>Permissions</em> → set <em>Microphone</em> to <em>Allow</em>, then tap <em>Grant Microphone</em>.
                </div>
              </div>

              <button
                onClick={() => stateManagerRef.current?.setMicPermission('prompt')}
                className="text-amber-400 hover:text-white text-xs font-mono px-1 shrink-0"
                title="Dismiss banner"
              >
                ✕
              </button>
            </div>
          </div>
        )}

        {/* C2 Recognition & Memory Banner */}
        {greetingNotification && (
          <div className="w-full max-w-md mx-auto mb-3 p-3 rounded-xl bg-violet-950/50 border border-violet-500/30 backdrop-blur-xl flex items-center justify-between gap-3 text-xs shadow-lg animate-in fade-in">
            <div className="flex items-center gap-2.5 min-w-0">
              <div className="w-6 h-6 rounded-full bg-violet-600/40 border border-violet-400/40 flex items-center justify-center shrink-0 text-violet-300">
                <Sparkles className="w-3.5 h-3.5" />
              </div>
              <div className="truncate">
                <div className="text-[10px] uppercase font-mono tracking-wider text-violet-300 font-semibold">
                  {state.isFirstLogin ? 'First Login Onboarding' : 'Returning User Recognized'}
                </div>
                <div className="text-slate-200 truncate italic">
                  "{greetingNotification}"
                </div>
              </div>
            </div>
            <button
              onClick={() => setGreetingNotification(null)}
              className="text-slate-400 hover:text-white text-xs px-1.5 py-0.5 shrink-0"
            >
              ✕
            </button>
          </div>
        )}

        {/* C2 Personality Greeting Tag */}
        <div className="text-center mb-1 select-none">
          <h1 className="text-2xl sm:text-3xl font-bold tracking-tight text-white/95 drop-shadow-md">
            C2
          </h1>
          <p className="text-xs sm:text-sm text-slate-300 font-light mt-0.5 tracking-wide">
            Real-Time Voice Assistant & Companion
          </p>
        </div>

        {/* Animated Avatar Character Video & Touch Boundary System */}
        <div className="w-full flex flex-col items-center my-1.5">
          <AvatarVideoPlayer
            theme={state.atmosphere}
            onOpenSettings={() => setIsAvatarSettingsOpen(true)}
          />
        </div>

        {/* Central Voice Core: Orb + Central Power/Mic Button */}
        <VoiceCore
          connectionState={state.connectionState}
          inputLevel={state.inputLevel}
          outputLevel={state.outputLevel}
          isMuted={state.isMuted}
          theme={state.atmosphere}
          micPermission={state.micPermission}
          onToggleConnection={handleToggleConnection}
          onToggleMute={handleToggleMute}
          onInterrupt={handleInterrupt}
          onRequestMic={handleRequestMic}
        />

        {/* Real-time Dynamic Waveform Visualizer */}
        <WaveformVisualizer
          connectionState={state.connectionState}
          inputLevel={state.inputLevel}
          outputLevel={state.outputLevel}
          theme={state.atmosphere}
        />

        {/* Tool Execution Telemetry HUD */}
        <ToolActivityHud
          activeTool={state.activeTool}
          toolHistory={state.toolHistory}
        />

        {/* Spoken Response Display from C2 */}
        {lastResponse && (
          <div className="w-full max-w-lg mx-auto my-3 p-3.5 rounded-2xl bg-white/[0.04] border border-white/10 backdrop-blur-xl text-center space-y-2 animate-in fade-in shadow-xl">
            <div className="flex items-center justify-between text-[11px] text-slate-400 font-mono">
              <span className="flex items-center gap-1.5 text-violet-300 font-semibold">
                <Sparkles className="w-3.5 h-3.5 text-violet-400" />
                C2 Response ({lastResponse.language})
              </span>
              <button
                id="c2-replay-voice-btn"
                onClick={() => speakResponse(lastResponse.text, lastResponse.language)}
                className="flex items-center gap-1.5 text-slate-300 hover:text-white px-2 py-1 rounded-md bg-white/10 hover:bg-white/15 cursor-pointer text-xs transition-colors"
                title="Replay C2 voice"
              >
                <Volume2 className="w-3.5 h-3.5 text-violet-400" />
                {isSpeakingResponse ? 'Speaking...' : 'Replay Voice'}
              </button>
            </div>
            <p className="text-sm text-slate-100 font-light leading-relaxed">
              "{lastResponse.text}"
            </p>
          </div>
        )}

        {/* Voice Prompts Suggestions & Quick Command Input */}
        {state.connectionState === 'disconnected' && (
          <div className="w-full space-y-3">
            <VoicePrompts onSelectPrompt={handlePromptSubmit} />

            {/* Quick Command / Query Input */}
            <form
              onSubmit={(e) => {
                e.preventDefault();
                handlePromptSubmit(typedMessage);
              }}
              className="w-full max-w-md mx-auto flex items-center gap-2 px-3 py-1.5 rounded-full bg-white/[0.03] border border-white/10 backdrop-blur-md focus-within:border-violet-500/50 transition-colors"
            >
              <input
                id="c2-quick-prompt-input"
                type="text"
                value={typedMessage}
                onChange={(e) => setTypedMessage(e.target.value)}
                placeholder={`Ask or tell C2 anything (e.g. "Call me Master Vivek")...`}
                className="flex-1 bg-transparent text-xs text-white placeholder-slate-400 focus:outline-hidden px-2 py-1"
              />
              <button
                id="c2-send-prompt-btn"
                type="submit"
                disabled={!typedMessage.trim() || isSendingChat}
                className="p-1.5 rounded-full bg-violet-600 hover:bg-violet-500 disabled:opacity-40 text-white transition-all cursor-pointer shrink-0"
                title="Send to C2"
              >
                <Send className="w-3.5 h-3.5" />
              </button>
            </form>
          </div>
        )}

        {/* Active Conversation Live Cue */}
        {state.connectionState !== 'disconnected' && (
          <div className="text-center text-xs text-slate-400 font-light animate-pulse mt-3 flex items-center justify-center gap-1.5">
            <span className="w-1.5 h-1.5 rounded-full bg-violet-400" />
            <span>
              {state.connectionState === 'listening'
                ? `Speak naturally — C2 is listening to ${state.currentUser?.preferredName || 'Master'}`
                : state.connectionState === 'speaking'
                ? 'C2 is speaking — tap core or speak to interrupt'
                : state.connectionState === 'thinking'
                ? 'C2 is thinking...'
                : state.connectionState === 'error'
                ? 'Voice session paused — tap Reconnect above'
                : 'Connecting to Gemini Live...'}
            </span>
          </div>
        )}
      </main>

      {/* Identity & Memory Modal */}
      <IdentityMemoryModal
        isOpen={isIdentityModalOpen}
        onClose={() => setIsIdentityModalOpen(false)}
        currentUser={state.currentUser}
        memories={state.memories}
        allUsers={allUsers}
        onSwitchUser={handleSwitchUser}
        onCreateUser={handleCreateUser}
        onUpdatePreferredName={handleUpdatePreferredName}
        onAddMemory={handleAddMemory}
        onDeleteMemory={handleDeleteMemory}
        onClearMemories={handleClearMemories}
      />

      {/* Gemini Free-Tier Diagnostic Modal */}
      <GeminiDiagnosticModal
        isOpen={isGeminiDiagnosticOpen}
        onClose={() => setIsGeminiDiagnosticOpen(false)}
        onOpenKeyManager={() => {
          setKeyModalMode('settings');
          setIsKeyModalOpen(true);
        }}
      />

      {/* Gemini Key Manager & Onboarding Modal */}
      <GeminiKeyManagerModal
        isOpen={isKeyModalOpen}
        mode={keyModalMode}
        onClose={() => setIsKeyModalOpen(false)}
        onKeySaved={(newStatus) => {
          setKeyStatus(newStatus);
          fetchKeyStatus();
        }}
      />

      {/* Avatar Settings & Touch Zones Modal */}
      <AvatarSettingsModal
        isOpen={isAvatarSettingsOpen}
        onClose={() => setIsAvatarSettingsOpen(false)}
      />

      {/* Footer HUD & System Metadata */}
      <footer className="w-full max-w-4xl mx-auto px-4 py-3 flex flex-wrap items-center justify-between text-[11px] text-slate-300/80 border-t border-white/5 backdrop-blur-md z-20">
        <div className="flex items-center gap-2">
          <span className="font-mono text-white/60">gemini-3.1-flash-live-preview</span>
          <span className="text-white/20">|</span>
          <span>Ultra-low latency audio-to-audio</span>
        </div>

        <div className="flex items-center gap-3">
          <span className="text-white/60">
            {state.currentUser ? `User: ${state.currentUser.preferredName}` : 'Companion'}
          </span>
          <span className="text-white/20">|</span>
          <span className="font-mono text-emerald-400/90">PCM16/24kHz Ready</span>
        </div>
      </footer>
    </div>
  );
}
