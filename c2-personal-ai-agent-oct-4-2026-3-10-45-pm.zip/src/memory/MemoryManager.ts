import { LanguageCode, MemoryCategory, MemoryItem, UserProfile } from '../types';

export interface DatabaseSchema {
  users: UserProfile[];
  memories: MemoryItem[];
  memoryEnabled: boolean;
}

export class MemoryManager {
  private users: UserProfile[] = [
    {
      id: 'usr_master_vivek',
      email: 'master.vivek@c2.ai',
      displayName: 'Master Vivek',
      preferredName: 'Master Vivek',
      preferredLanguage: 'English',
      isFirstLogin: false,
      lastLoginAt: '2026-09-08T18:00:00.000Z',
      createdAt: '2026-09-01T10:00:00.000Z',
    },
    {
      id: 'usr_master_default',
      email: 'master@c2.ai',
      displayName: 'Master',
      preferredName: 'Master',
      preferredLanguage: 'English',
      isFirstLogin: false,
      lastLoginAt: '2026-09-08T12:00:00.000Z',
      createdAt: '2026-09-01T12:00:00.000Z',
    },
  ];

  private memories: MemoryItem[] = [
    {
      id: 'mem_1',
      userId: 'usr_master_vivek',
      category: 'profile',
      key: 'preferred_name',
      value: 'Master Vivek',
      createdAt: '2026-09-01T10:05:00.000Z',
      updatedAt: '2026-09-01T10:05:00.000Z',
    },
    {
      id: 'mem_2',
      userId: 'usr_master_vivek',
      category: 'preference',
      key: 'preferred_title',
      value: 'Master',
      createdAt: '2026-09-01T10:05:00.000Z',
      updatedAt: '2026-09-01T10:05:00.000Z',
    },
    {
      id: 'mem_3',
      userId: 'usr_master_vivek',
      category: 'preference',
      key: 'browser',
      value: 'Chrome',
      createdAt: '2026-09-02T14:10:00.000Z',
      updatedAt: '2026-09-02T14:10:00.000Z',
    },
    {
      id: 'mem_4',
      userId: 'usr_master_vivek',
      category: 'preference',
      key: 'music_app',
      value: 'Spotify',
      createdAt: '2026-09-03T09:20:00.000Z',
      updatedAt: '2026-09-03T09:20:00.000Z',
    },
    {
      id: 'mem_5',
      userId: 'usr_master_vivek',
      category: 'long_term',
      key: 'interests',
      value: 'Artificial Intelligence, software engineering, and clean design',
      createdAt: '2026-09-04T16:45:00.000Z',
      updatedAt: '2026-09-04T16:45:00.000Z',
    },
    {
      id: 'mem_6',
      userId: 'usr_master_default',
      category: 'profile',
      key: 'preferred_name',
      value: 'Master',
      createdAt: '2026-09-01T12:05:00.000Z',
      updatedAt: '2026-09-01T12:05:00.000Z',
    },
  ];

  private memoryEnabled: boolean = true;
  private currentUserId: string = 'usr_master_vivek';
  private conversationContext: {
    lastSelectedFileId?: string;
    lastSelectedFilename?: string;
    lastAppOpened?: string;
    lastSearchQuery?: string;
  } = {};

  constructor(initialData?: Partial<DatabaseSchema>) {
    if (initialData?.users && initialData.users.length > 0) {
      this.users = initialData.users.map((u) => ({
        ...u,
        preferredName: u.preferredName || (u.displayName?.includes('Master') ? u.displayName : 'Master'),
        isFirstLogin: u.isFirstLogin ?? false,
        lastLoginAt: u.lastLoginAt || new Date().toISOString(),
      }));
    }
    if (initialData?.memories) this.memories = initialData.memories;
    if (initialData?.memoryEnabled !== undefined) this.memoryEnabled = initialData.memoryEnabled;
  }

  public getCurrentUser(): UserProfile {
    const user = this.users.find((u) => u.id === this.currentUserId);
    if (!user) {
      return this.users[0];
    }
    return user;
  }

  public getUsers(): UserProfile[] {
    return [...this.users];
  }

  public getUserById(userId: string): UserProfile | null {
    return this.users.find((u) => u.id === userId) || null;
  }

  public switchUser(userId: string): UserProfile {
    const found = this.users.find((u) => u.id === userId);
    if (found) {
      this.currentUserId = userId;
      found.lastLoginAt = new Date().toISOString();
      this.conversationContext = {};
      return found;
    }
    throw new Error(`User ID ${userId} does not exist in database.`);
  }

  /**
   * Authenticates an existing user by identifier (userId, email, or displayName).
   * Updates lastLoginAt and returns returning greeting.
   */
  public authenticateUser(identifier: string): {
    user: UserProfile;
    memories: MemoryItem[];
    greeting: string;
    isFirstLogin: boolean;
  } {
    const cleanId = identifier.trim().toLowerCase();
    const existing = this.users.find(
      (u) =>
        u.id.toLowerCase() === cleanId ||
        u.email?.toLowerCase() === cleanId ||
        u.displayName.toLowerCase() === cleanId
    );

    if (!existing) {
      throw new Error(`User "${identifier}" not found in database.`);
    }

    this.currentUserId = existing.id;
    existing.lastLoginAt = new Date().toISOString();
    const isFirstLogin = existing.isFirstLogin ?? false;

    const greeting = this.generateGreeting(existing, isFirstLogin);
    const memories = this.getMemoriesForUser(existing.id);

    return {
      user: existing,
      memories,
      greeting,
      isFirstLogin,
    };
  }

  /**
   * First Login / Registration: Creates a new user account with a unique User ID.
   * C2 introduces herself naturally:
   * "Hey! I'm C2. Nice to meet you. You can call me whenever you need me. What should I call you?"
   */
  public registerUser(
    emailOrUsername: string,
    displayName?: string,
    preferredName?: string,
    language: LanguageCode = 'English'
  ): {
    user: UserProfile;
    memories: MemoryItem[];
    greeting: string;
    isFirstLogin: boolean;
  } {
    const cleanEmail = emailOrUsername.trim();
    // Check if user already exists
    const existing = this.users.find(
      (u) =>
        u.email?.toLowerCase() === cleanEmail.toLowerCase() ||
        u.id.toLowerCase() === cleanEmail.toLowerCase()
    );

    if (existing) {
      return this.authenticateUser(existing.id);
    }

    const uniqueId = 'usr_' + Date.now().toString(36) + '_' + Math.random().toString(36).substring(2, 6);
    const dName = displayName?.trim() || cleanEmail.split('@')[0] || 'Master';
    const prefName = preferredName?.trim() || (dName.includes('Master') ? dName : 'Master');

    const newUser: UserProfile = {
      id: uniqueId,
      email: cleanEmail.includes('@') ? cleanEmail : `${cleanEmail}@c2.ai`,
      displayName: dName,
      preferredName: prefName,
      preferredLanguage: language,
      isFirstLogin: true,
      lastLoginAt: new Date().toISOString(),
      createdAt: new Date().toISOString(),
    };

    this.users.push(newUser);
    this.currentUserId = newUser.id;

    // Save initial profile memories in persistent database
    this.setMemory(newUser.id, 'profile', 'preferred_name', newUser.preferredName);
    this.setMemory(newUser.id, 'profile', 'preferred_language', newUser.preferredLanguage);

    const greeting = "Hey! I'm C2. Nice to meet you. You can call me whenever you need me. What should I call you?";
    const memories = this.getMemoriesForUser(newUser.id);

    return {
      user: newUser,
      memories,
      greeting,
      isFirstLogin: true,
    };
  }

  public createUser(displayName: string, language: LanguageCode = 'English'): UserProfile {
    const res = this.registerUser(displayName, displayName, 'Master', language);
    return res.user;
  }

  /**
   * Marks first login onboarding completed
   */
  public completeFirstLogin(userId: string): void {
    const user = this.getUserById(userId);
    if (user) {
      user.isFirstLogin = false;
    }
  }

  /**
   * Updates preferred name (e.g. "Call me Master Vivek" -> saves preferred_name: "Master Vivek")
   */
  public setPreferredName(userId: string, preferredName: string): UserProfile {
    const user = this.getUserById(userId);
    if (!user) {
      throw new Error(`User ID ${userId} not found.`);
    }

    const cleanName = preferredName.trim();
    user.preferredName = cleanName;
    user.displayName = cleanName;
    user.isFirstLogin = false;

    // Persist to memory record
    this.setMemory(user.id, 'profile', 'preferred_name', cleanName);
    return user;
  }

  /**
   * Generates natural, human-like greetings for first login or returning user.
   */
  public generateGreeting(user: UserProfile, isFirstLogin: boolean = false): string {
    if (isFirstLogin) {
      return "Hey! I'm C2. Nice to meet you. You can call me whenever you need me. What should I call you?";
    }

    const title = user.preferredName || 'Master';
    const greetings = [
      `Hey ${title}, good to see you again.`,
      `Welcome back, ${title}.`,
      `Hey ${title}, ready when you are.`,
      `Good to have you back, ${title}.`,
    ];

    // Select natural variation
    const index = Math.floor(Math.random() * greetings.length);
    return greetings[index];
  }

  public isMemoryEnabled(): boolean {
    return this.memoryEnabled;
  }

  public setMemoryEnabled(enabled: boolean): void {
    this.memoryEnabled = enabled;
  }

  public getMemoriesForUser(userId?: string): MemoryItem[] {
    const uid = userId || this.currentUserId;
    return this.memories.filter((m) => m.userId === uid);
  }

  public setMemory(
    userId: string,
    category: MemoryCategory,
    key: string,
    value: string
  ): MemoryItem {
    const now = new Date().toISOString();
    const existingIndex = this.memories.findIndex(
      (m) => m.userId === userId && m.key.toLowerCase() === key.toLowerCase()
    );

    if (existingIndex >= 0) {
      const updated: MemoryItem = {
        ...this.memories[existingIndex],
        category,
        value,
        updatedAt: now,
      };
      this.memories[existingIndex] = updated;
      return updated;
    }

    const newItem: MemoryItem = {
      id: 'mem_' + Date.now().toString(36) + Math.random().toString(36).substring(2, 6),
      userId,
      category,
      key,
      value,
      createdAt: now,
      updatedAt: now,
    };
    this.memories.push(newItem);
    return newItem;
  }

  public deleteMemory(memoryId: string): boolean {
    const initialLen = this.memories.length;
    this.memories = this.memories.filter(
      (m) => !(m.id === memoryId && m.userId === this.currentUserId)
    );
    return this.memories.length < initialLen;
  }

  public forgetByKey(key: string, userId?: string): boolean {
    const uid = userId || this.currentUserId;
    const initialLen = this.memories.length;
    this.memories = this.memories.filter(
      (m) => !(m.userId === uid && m.key.toLowerCase().includes(key.toLowerCase()))
    );
    return this.memories.length < initialLen;
  }

  public clearAllMemories(userId?: string): void {
    const uid = userId || this.currentUserId;
    this.memories = this.memories.filter((m) => m.userId !== uid);
    this.conversationContext = {};
  }

  public retrieveRelevantMemories(query: string, userId?: string): MemoryItem[] {
    if (!this.memoryEnabled) return [];

    const uid = userId || this.currentUserId;
    const userMemories = this.memories.filter((m) => m.userId === uid);
    const q = query.toLowerCase();

    // Always include profile details (preferred_name, language)
    const profileMemories = userMemories.filter((m) => m.category === 'profile');

    const relevantOthers = userMemories.filter((m) => {
      if (m.category === 'profile') return false;
      const keyMatch = q.includes(m.key.toLowerCase()) || m.key.toLowerCase().split('_').some((k) => q.includes(k));
      const valMatch = q.includes(m.value.toLowerCase());
      return keyMatch || valMatch;
    });

    return [...profileMemories, ...relevantOthers];
  }

  public updateConversationContext(update: Partial<{
    lastSelectedFileId?: string;
    lastSelectedFilename?: string;
    lastAppOpened?: string;
    lastSearchQuery?: string;
  }>) {
    this.conversationContext = { ...this.conversationContext, ...update };
  }

  public getConversationContext() {
    return { ...this.conversationContext };
  }

  public toDatabaseJson(): DatabaseSchema {
    return {
      users: this.users,
      memories: this.memories,
      memoryEnabled: this.memoryEnabled,
    };
  }
}
