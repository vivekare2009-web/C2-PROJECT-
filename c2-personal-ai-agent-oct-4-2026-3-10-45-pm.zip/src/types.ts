export type AgentStatus =
  | 'idle'
  | 'listening'
  | 'thinking'
  | 'executing'
  | 'waiting_confirmation'
  | 'completed'
  | 'failed';

export type LiveConnectionState =
  | 'disconnected'
  | 'connecting'
  | 'listening'
  | 'thinking'
  | 'speaking'
  | 'error';

export type AtmosphereTheme = 'nebula' | 'cyberpunk' | 'aurora' | 'midnight';

export interface ToolExecutionEvent {
  id: string;
  name: string;
  args: Record<string, any>;
  result: any;
  timestamp: number;
  status: 'running' | 'completed' | 'failed';
}

export interface AudioMetrics {
  inputLevel: number;
  outputLevel: number;
  latencyMs: number;
  sessionDuration: number;
}

export type EmotionalState =
  | 'neutral'
  | 'happy'
  | 'excited'
  | 'curious'
  | 'concerned'
  | 'surprised'
  | 'focused'
  | 'calm'
  | 'confident'
  | 'frustrated'
  | 'relief'
  | 'amused'
  | 'empathetic';

export type LanguageCode = 'English' | 'Hindi' | 'Hinglish';

export type RiskLevel = 'LOW' | 'MEDIUM' | 'HIGH';

export type MemoryCategory =
  | 'profile'
  | 'preference'
  | 'conversation'
  | 'task'
  | 'long_term';

export interface MemoryItem {
  id: string;
  userId: string;
  category: MemoryCategory;
  key: string;
  value: string;
  createdAt: string;
  updatedAt: string;
}

export interface UserProfile {
  id: string;
  email?: string;
  displayName: string;
  preferredName: string; // e.g. "Master" or "Master Vivek"
  preferredLanguage: LanguageCode;
  isFirstLogin: boolean;
  lastLoginAt: string;
  createdAt: string;
}

export interface AuthResponse {
  success: boolean;
  user: UserProfile;
  memories: MemoryItem[];
  greeting: string;
  isFirstLogin: boolean;
}

export interface ToolDefinition {
  name: string;
  description: string;
  parameters: Record<string, any>;
  risk: RiskLevel;
  requiresConfirmation: boolean;
  category: 'app' | 'files' | 'media' | 'settings' | 'accessibility' | 'system';
  permissions: string[];
  executionMethod: string;
}

export interface ToolCallResult {
  success: boolean;
  message?: string;
  error?: string;
  data?: any;
}

export interface ToolCall {
  id: string;
  tool: string;
  arguments: Record<string, any>;
  risk: RiskLevel;
  requiresConfirmation: boolean;
  status: 'pending' | 'executing' | 'completed' | 'failed' | 'cancelled';
  result?: ToolCallResult;
}

export interface ChatMessage {
  id: string;
  sender: 'user' | 'c2' | 'system';
  text: string;
  timestamp: string;
  emotionalState?: EmotionalState;
  language?: LanguageCode;
  toolCalls?: ToolCall[];
  pendingConfirmation?: ToolCall;
}

export interface AndroidFile {
  file_id: string;
  filename: string;
  location: string;
  size: string;
  modified_date: string;
}

export interface AndroidMediaState {
  isPlaying: boolean;
  trackTitle: string;
  artist: string;
  album: string;
  trackIndex: number;
}

export interface AndroidSettingsState {
  wifi: boolean;
  bluetooth: boolean;
  soundVolume: number;
  currentSection?: string;
  accessibilityGranted: boolean;
  storagePermissionGranted: boolean;
}

export interface AndroidAccessibilityLog {
  id: string;
  timestamp: string;
  action: 'click' | 'scroll' | 'swipe' | 'type' | 'back';
  target: string;
  success: boolean;
}

export interface AndroidDeviceState {
  currentApp: string; // 'Home' | 'YouTube' | 'Chrome' | 'Files' | 'Settings' | 'Spotify'
  currentScreenTitle: string;
  activeInputQuery?: string;
  mediaState: AndroidMediaState;
  settings: AndroidSettingsState;
  files: AndroidFile[];
  recentScreenshot?: string;
  accessibilityLogs: AndroidAccessibilityLog[];
}

export interface ApiKeyStatus {
  hasKey: boolean;
  activeKeyType: 'primary' | 'backup';
  hasBackupKey: boolean;
  quotaExhausted: boolean;
  primaryKeyMasked: string | null;
  backupKeyMasked: string | null;
  tier: string;
  liveVoiceReady: boolean;
}
